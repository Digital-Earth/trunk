JULY 18th, 2007


This folder contains some code which implements progressive rendering in WorldView. This
code is being stored here, as it will not be used because of our migration to OpenGL. Only the 
modified files are included in the zip archive, not the complete application.


Progressive rendering involves two main tasks:
	1) Drawing Tiles, as soon as they have been created, in a spiral pattern, from
	   the center of the screen, outward

	2) Updating a tiles resolution from TRI 1 to TRI N, that is, from a coarse grain
	   to a fine grain.

The directory SpiralRendering contains just the code that draws the tiles in a spiral
pattern

The directory SpiralProgressiveRendering implements both tasks described above. Some minor
adjustments would need to be made if it were to actually be used: checking if the goal TRI
is 1, and not performing the second update; making the tile update process more than 2 stage, 
if desired; the threading could be modified; perhaps also the actual rendering updates could
be moved to only occur when the user releases the left mouse button: this would improve the 
user's visual experience.

Just some thoughts... drop me a line if anyone has any questions.

~Jeff
