/******************************************************************************
begin		: 2006-10-16
copyright	: (C) 2006 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/
namespace PYXGlobe
{
    /// <summary>
    /// This form provides a visual 3D surface model that can be 
    /// interacted with by users.
    /// </summary>
    partial class GlobeControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GlobeControl));
            this.m_tileSelectionThread = new System.ComponentModel.BackgroundWorker();
            this.m_tileGenerationThread = new System.ComponentModel.BackgroundWorker();
            this.m_cameraMoveTimer = new System.Windows.Forms.Timer(this.components);
            this.m_tileUpdatingThread = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // m_tileSelectionThread
            // 
            this.m_tileSelectionThread.WorkerSupportsCancellation = true;
            this.m_tileSelectionThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.TileSelectionThread_DoWork);
            this.m_tileSelectionThread.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.TileSelectionThread_RunWorkerCompleted);
            // 
            // m_tileGenerationThread
            // 
            this.m_tileGenerationThread.WorkerReportsProgress = true;
            this.m_tileGenerationThread.WorkerSupportsCancellation = true;
            this.m_tileGenerationThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.TileGenerationThread_DoWork);
            this.m_tileGenerationThread.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.TileGenerationThread_RunWorkerCompleted);
            this.m_tileGenerationThread.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.TileGenerationThread_ProgressChanged);
            // 
            // m_cameraMoveTimer
            // 
            this.m_cameraMoveTimer.Tick += new System.EventHandler(this.CameraMoveTimer_Tick);
            // 
            // m_tileUpdatingThread
            // 
            this.m_tileUpdatingThread.WorkerReportsProgress = true;
            this.m_tileUpdatingThread.WorkerSupportsCancellation = true;
            // 
            // GlobeControl
            // 
            this.Name = "GlobeForm";
            resources.ApplyResources(this, "$this");
            this.VisibleChanged += new System.EventHandler(this.ControlVisibleChanged);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GlobeControl_KeyPress);
            this.SizeChanged += new System.EventHandler(this.GlobeControl_SizeChanged);
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker m_tileSelectionThread;
        private System.ComponentModel.BackgroundWorker m_tileGenerationThread;
        private System.Windows.Forms.Timer m_cameraMoveTimer;
        private System.ComponentModel.BackgroundWorker m_tileUpdatingThread;
    }
}

