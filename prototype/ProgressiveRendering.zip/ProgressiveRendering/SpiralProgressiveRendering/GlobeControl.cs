/******************************************************************************
begin		: 2006-10-13
copyright	: (C) 2006 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using vtk;

namespace PYXGlobe
{
    /// <summary>
    /// This Widget allows a user visualize and interact with a PYXIS globe.
    /// </summary>
    public partial class GlobeControl : vtk.vtkFormsWindowControl
    {
        /// <summary>
        /// Constructor for the form containing the 3d rendering.
        /// </summary>
        public GlobeControl() 
        {
            /*
             * AppServices are needed for the design view. initialize them if
             * they are not initialized already.
             */
            PYXLibInstance.initialize(Properties.Resources.ApplicationName);
            Trace.ui("New GlobeForm being created");

            m_enableAdvancedKeys = false;
            m_noClipping = false;
            m_tileRootLabels = false;
            m_autoGrid = true;

            InitializeComponent();

            m_renderer = new vtk.vtkRenderer();
            m_screenManager = new ScreenManager();
            m_displayTileActors = new vtk.vtkActorCollection();

            // Create a cursor
            m_cursor = new Cursor(new PYXIcosIndex("A-0000"), PYXMath.eHexDirection.knDirectionOne);
            m_cursorActor = new vtk.vtkActorCollection();

            // extract the background colour from the settings
            System.Drawing.Color bgColour =
                Properties.Settings.Default.BackgroundColour;

            m_renderer.SetBackground(
                bgColour.R / 255.0,
                bgColour.G / 255.0,
                bgColour.B / 255.0);
            GetRenderWindow().AddRenderer(m_renderer);

            m_cameraMoveTimer.Interval = 10;

            // Create and initialize the user interpreter
            m_interpreter = new PYXGlobe.UserInterfaceInterpreter();
            m_interpreter.Globe = this;

            // Create and initialize the camera observer
            m_cameraObserver = new ApplicationUtility.ObjectObserver();
            m_cameraObserver.SetNotificationCallback(CameraNotificationCallback);
        }

        /// <summary>
        /// Clean up any allocated resources.
        /// </summary>
        ~GlobeControl()
        {
            // release the pyxlib instance
            PYXLibInstance.uninitialize();
        }

        /// <summary>
        /// The command manager that is associated with the globe control. All
        /// navigation operations are recorded on this command manager.
        /// </summary>
        public CommandManager CommandMgr
        {
            set { m_interpreter.CommandMgr = value; }
        }

        /// <summary>
        /// Dissasociate the render window from the application. This mehtod must be
        /// called at the beginning of the shutdown procedure or else a garbage 
        /// collector may not destroy in the correct order and error dialogs
        /// will be displayed.
        /// The method also disconnects from observed objects so that no further
        /// renders are performed.
        /// </summary>
        public void Clean()
        {
            // release observed objects
            m_cameraObserver.ReleaseObject();
            m_dataManagementObserver.ReleaseObject();

            // clean up the renderer
            vtkWin32OpenGLRenderWindow win32Win =
                vtkWin32OpenGLRenderWindow.SafeDownCast(m_renderer.GetRenderWindow());
            win32Win.Clean();
        }

        #region Tile Management

        /// <summary>
        /// The information that defines how data is displayed on the screen.
        /// </summary>
        private ScreenManager m_screenManager;

        /// <summary>
        /// The current data resolution (mesh cell vertex res).
        /// </summary>
        private int m_currentDataRes;

        /// <summary>
        /// Accessor Properties for m_currentDataRes.
        /// </summary>
        public int CurrentDataRes
        {
            get
            {
                return m_currentDataRes;
            }
            set
            {
                m_currentDataRes = value;
            }
        }

        /// <summary>
        /// The vtk screen area that performs rendering of vtk objects.
        /// </summary>
        private vtk.vtkRenderer m_renderer;

        /// <summary>
        /// Accessor Properties for m_renderer.
        /// </summary>
        public vtk.vtkRenderer VTKRenderer
        {
            get
            {
                return m_renderer;
            }
            set
            {
                m_renderer = value;
            }
        }

        /// <summary>
        /// The list of display tiles that are displayed in the control. The list must
        /// be maintained to keep the correct reference count. The tiles in this list
        /// are shared resources between controls and the manager.
        /// </summary>
        //private Vector_DisplayTile m_displayTiles;

        /// <summary>
        /// The list of tiles that to be rendered on the screen.
        /// </summary>
        private vtk.vtkActorCollection m_displayTileActors;

        /// <summary>
        /// Recalculate the tiles that are required to cover the screen and then
        /// render and display those tiles.
        /// </summary>
        void RecalculateScreenTiles()
        {
            ResetTileSelectionThread();

            if (m_autoGrid)
            {
                // create a test to determine the tiles that cover the screen                    
                double[] frustumPlanes = new double[24];
                double[] aspect = m_renderer.GetAspect();

                m_renderer.GetActiveCamera().GetFrustumPlanes(
                    aspect[0],
                    frustumPlanes);

                // place each value in a vector to send to the library
                Vector_Double doubleVector = new Vector_Double();
                foreach (double value in frustumPlanes)
                {
                    doubleVector.Add(value);
                }
                ScreenTileTest screenTest = new ScreenTileTest(
                    doubleVector,
                    SnyderProjection.getInstance());

                // calculate the default display resolution for the camera position
                m_currentDataRes = m_cameraPtr.calcDisplayResolution();
                m_currentDataRes = m_screenManager.applyResolutionModifiers(m_currentDataRes);
                screenTest.setDataResolution(m_currentDataRes);

                int tileRes = m_screenManager.calcTileResolution(m_currentDataRes);
                screenTest.setTargetResolution(
                    m_screenManager.calcTileResolution(m_currentDataRes));
                System.Diagnostics.Debug.Assert(screenTest != null);
                m_tileSelectionThread.RunWorkerAsync(screenTest);
            }
            else
            {
                // not calculating new screen geometry, re-create current tile set.
                GenerateTiles();
            }
        }
        #endregion

        #region Camera Navigation

        /// <summary>
        /// The navigation model camera associated with the globe control.
        /// </summary>
        private PYXCamera_SPtr m_cameraPtr;

        /// <summary>
        /// The object that observes the the navigation model for changes.
        /// </summary>
        private ApplicationUtility.ObjectObserver m_cameraObserver;

        /// <summary>
        /// Set the navigation model that the GlobeForm should visualize
        /// and interact with.  The globe is immediately updated with the 
        /// navigation state.
        /// </summary>
        /// <param name="cameraPtr">
        /// The navigation model object to associate with the globe widget. The view
        /// of the camera is updated to reflect the camera position.
        /// </param>
        public void SetCamera(PYXCamera_SPtr cameraPtr)
        {
            Trace.ui("Setting navigation model in GlobeForm");
            if (cameraPtr == null)
            {
                throw new System.NullReferenceException();
            }

            // store a copy of the camera pointer.
            m_cameraPtr = cameraPtr;
            m_interpreter.Camera = cameraPtr;

            m_cameraObserver.SetObject(cameraPtr.__deref__());
            ApplyModelCamera();
        }

        /// <summary>
        /// Set the camera of the vtk renderer equivalent to that in
        /// the navigation model.
        /// </summary>
        private void ApplyModelCamera()
        {
            if (m_renderer != null)
            {
                PYXCameraState camState = m_cameraPtr.getState();
                vtk.vtkCamera vtkCam = m_renderer.GetActiveCamera();

                double[] pos = new double[3];
                pos = vtkCam.GetPosition();
                PYXCoord3DDouble coord = camState.getPosition();

                vtkCam.SetPosition(coord.x(), coord.y(), coord.z());

                coord = camState.getFocalPoint();
                vtkCam.SetFocalPoint(coord.x(), coord.y(), coord.z());

                coord = camState.getViewUpVector();
                vtkCam.SetViewUp(coord.x(), coord.y(), coord.z());

                vtkCam.SetViewAngle(camState.getViewAngle());

                if (m_noClipping)
                {
                    vtkCam.SetClippingRange(0.1, 10);
                }
                else
                {
                    vtkCam.SetClippingRange(
                        camState.getNearClippingPlane(),
                        camState.getFarClippingPlane());
                }
            }
        }

        #endregion

        #region Data Management

        /// <summary>
        ///  The object that controls the data that is active in the application.
        /// </summary>
        private DataVisualizationManager_SPtr m_dataManager = null;

        /// <summary>
        /// The object that observes the the navigation model for changes.
        /// </summary>
        private ApplicationUtility.ObjectObserver m_dataManagementObserver;

        /// <summary>
        /// Associate the data manager with the globe control. Observe the
        /// data manager for 
        /// </summary>
        /// <param name="dataManager">
        /// The data management object to associate with this control
        /// </param>
        public void SetDataManager(DataVisualizationManager_SPtr dataManager)
        {
            if (m_dataManagementObserver == null)
            {
                m_dataManagementObserver = new ApplicationUtility.ObjectObserver();
                m_dataManagementObserver.SetNotificationCallback(DataManagementCallback);
            }
            
            // start observing the data manager.
            m_dataManagementObserver.SetObject(dataManager.get());
            m_dataManager = dataManager;
        }

        /// <summary>
        /// The Globe Control delegates the observer behavior to the UI 
        /// interpreter. The UI interpreter passes all notifications back up
        /// to this callback method.
        /// </summary>
        /// <param name="spEvent">
        /// The observed camera event.
        /// </param>
        void DataManagementCallback(NotifierEvent_SPtr spEvent)
        {
            try
            {
                // Manually dereference smart pointer proxy and manually downcast underlying object.
                DataVisualizationEvent dataEvent = DataVisualizationEvent.dynamic_cast(spEvent.__deref__());
                System.Diagnostics.Debug.Assert(dataEvent != null);

                Trace.info("Data Management event occurred. Recalculating screen.");
                RecalculateScreenTiles();
            }
            catch (InvalidCastException e)
            {
                Trace.trace("Invalid event type for DataManagementCallback: " + e.Message);
            }
        }
        
        #endregion

        #region Interaction

        /// <summary>
        /// Indication if the form is being displayed for the first time
        /// </summary>
        bool m_firstVisible = true;

        /// <summary>
        /// The form visibility is changing.
        /// </summary>
        private void ControlVisibleChanged(object sender, EventArgs e)
        {
            if (Visible && m_firstVisible)
            {
                RecalculateScreenTiles();
                m_firstVisible = false;
            }
        }

        /// <summary>
        /// The object that interprets mouse and keyboard input and
        /// interacts with the navigation model.
        /// </summary>
        private PYXGlobe.UserInterfaceInterpreter m_interpreter;

        /// <summary>
        /// After the vtk control has processed the key press event the 
        /// notification can be processed by the globe widget. This call
        /// deals with modifying the contents of the vtk control rather than
        /// interacting with the existing items. When the dashboard is 
        /// enabled the individual items can be added and removed from here.
        /// </summary>
        /// <remarks>
        /// CTRL + a = Toggle the dashboard functionality.
        /// 1 - 9 = Toggle a PYXIS resolution on or off
        /// a,A = Toggle axes on and off
        /// s = Toggle reference sphere on and off
        /// S = Toggle the representation of the reference sphere
        /// f,F = Toggle FPS meter on and off
        /// 0,i = Toggle icosahedron on and off
        /// I = Toggle the representation of the icosahedron
        /// c,C = Toggle clipping planes on and off
        /// g = Toggle automatic grid generation on and off
        /// G = Turn off the automatic updating of grids, freeze the current screen.
        /// l, L = Turn on or labels for the roots of all tiles.
        /// r, R = Toggle random camera movements.
        /// k, K = Cursor forward
        /// ,, 'less than'  = Cursor backward
        /// m, M =  Cursor turn left
        /// ., > = Cursor turn right
        /// {, [ = Cursor zoom out
        /// }, ] = Cursor zoom in
        /// 
        /// </remarks>
        /// <param name="sender">The origin of the event</param>
        /// <param name="e">The argements for the event</param>
        private void GlobeControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            Trace.uiDebug(string.Format("GlobeForm caught winddows key press '{0}'", e.KeyChar));

            /* 
             * determine if the user is attempting to change the dashboard 
             * with CTRL + 'a'
             */
            if (e.KeyChar == 1)
            {
                m_enableAdvancedKeys = !m_enableAdvancedKeys;
                Trace.ui( string.Format("GlobeWidget advanced keys set to '{0}'.", m_enableAdvancedKeys));
            }            
            else if (m_enableAdvancedKeys)
            {
                switch (e.KeyChar)
                {
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        {
                            ToggleResolution((int)e.KeyChar - (int)'0');
                            Invalidate();
                            break;
                        }

                    case 'a':
                    case 'A':
                        {
                            ToggleAxis();
                            Invalidate();
                            break;
                        }
                    case 's':
                        {
                            ToggleReferenceSphere();
                            Invalidate();
                            break;
                        }
                    case 'S':
                        {
                            if (m_referenceSphere == null)
                            {
                                ToggleReferenceSphere();
                            }
                            Trace.ui("Toggling Reference Sphere representation.");
                            DrawingObjects.ToggleActorRepresentation(m_referenceSphere);
                            Invalidate();
                            break;
                        }

                    case 'f':
                    case 'F':
                        {
                            ToggleFPSMeter();
                            Invalidate();
                            break;
                        }
                    case 'g':
                        {
                            ToggleAutoGrid(false);
                            break;
                        }
                    case 'G':
                        {
                            ToggleAutoGrid(true);
                            break;
                        }

                    case 'c':
                    case 'C':
                        {
                            Trace.ui("Toggling clipping planes on and off.");
                            m_noClipping = !m_noClipping;
                            ApplyModelCamera();
                            Invalidate();
                            break;
                        }

                    case '0':
                    case 'i':
                        {
                            ToggleIcosahedron();
                            Invalidate();
                            break;
                        }

                    case 'I':
                        {
                            if (m_icosahedron == null)
                            {
                                ToggleIcosahedron();
                            }
                            Trace.ui("Toggling icosahedron representation.");
                            DrawingObjects.ToggleActorRepresentation(m_icosahedron);
                            Invalidate();
                            break;
                        }

                    case 'l':
                    case 'L':
                        {
                            Trace.ui("Toggling tile root labels");
                            m_tileRootLabels = !m_tileRootLabels;
                            RecalculateScreenTiles();
                            Invalidate();
                            break;
                        }

                    case 'R':
                    case 'r':
                        {
                            ToggleRandomCameraMove();
                            break;
                        }
                    case 'K':
                    case 'k':
                        {
                            m_cursor.forward();
                            DrawCursor();
                            break;
                        }
                    case '<':
                    case ',':
                        {
                            m_cursor.backward();
                            DrawCursor();
                            break;
                        }
                    case 'M':
                    case 'm':
                        {
                            m_cursor.left();
                            DrawCursor();
                            break;
                        }
                    case '>':
                    case '.':
                        {
                            m_cursor.right();
                            DrawCursor();
                            break;
                        }
                    case '{':
                    case '[':
                        {
                            m_cursor.zoomOut();
                            DrawCursor();
                            break;
                        }
                    case '}':
                    case ']':
                        {
                            m_cursor.zoomIn();
                            DrawCursor();
                            break;
                        }

                    default:
                        {
                            // no special key handling
                            break;
                        }
                }
            }
        }

        /// <summary>
        /// The Globe Control delegates the observer behavior to the UI 
        /// interpreter. The UI interpreter passes all notifications back up
        /// to this callback method.
        /// </summary>
        /// <param name="spEvent">
        /// The observed camera event.
        /// </param>
        void CameraNotificationCallback(NotifierEvent_SPtr spEvent)
        {
            try
            {
                // Manually dereference smart pointer proxy and manually downcast underlying object.
                PYXCameraEvent camEvent = PYXCameraEvent.dynamic_cast(spEvent.__deref__());
                if (camEvent != null)
                {
                    PYXCameraEvent.eType eventType = camEvent.getType();
                    if (eventType == PYXCameraEvent.eType.knInterim ||
                            eventType == PYXCameraEvent.eType.knComplete)
                    {
                        ApplyModelCamera();
                        if (Visible == true)
                        {
                            Invalidate();
                            RecalculateScreenTiles();
                        }
                    }
                    else if (eventType == PYXCameraEvent.eType.knEnd)
                    {
                        Trace.uiDebug("Navigation Operation Completed.");
                        RecalculateScreenTiles();
                    }
                }
            }
            catch (InvalidCastException e)
            {
                Trace.trace("Invalid event for CameraNotificationCallback: " + e.Message);
            }
        }

        /// <summary>
        /// Redraw the contents of the control every time the size of
        /// the control is changed.
        /// </summary>
        private void GlobeControl_SizeChanged(object sender, EventArgs e)
        {
            Invalidate();
        }

        #endregion

        #region Dashboard Tools

        /// <summary>
        /// A unit sphere that can be placed within the scene
        /// </summary>
        private vtk.vtkActor m_referenceSphere;

        /// <summary>
        /// A unit icosahedron aligned with the PYXIS indexing.
        /// </summary>
        private vtk.vtkActor m_icosahedron;

        /// <summary>
        /// A cursor.
        /// </summary>
        private Cursor m_cursor;

        /// <summary>
        /// X (red), Y (green) and Z (blue) axes.
        /// </summary>
        private vtk.vtkPropAssembly m_axes;

        /// <summary>
        /// Text output of the number of frames being rendered each
        /// second.
        /// </summary>
        private vtk.vtkTextActor m_FPSDisplay;

        /// <summary>
        /// The observer identifier on rendering events for the fps meter.
        /// </summary>
        private uint m_FPSObserverTag;

        /// <summary>
        /// An indication if the user should have the ability to use the
        /// advanced dashboard functions such as fps meter, reference
        /// sphere etc.
        /// </summary>
        private bool m_enableAdvancedKeys;

        /// <summary>
        /// The collection of vtk actors that each represent a resolution of 
        /// PYXIS cells.
        /// </summary>
        private System.Collections.Generic.List<vtk.vtkActor> m_resolutionList;

        /// <summary>
        /// When set to true, the clipping planes are turned off. When false
        /// the clipping planes are taken from the validator.
        /// </summary>
        private bool m_noClipping;

        /// <summary>
        /// Indicate if grids should be automatically generated during navigation.
        /// </summary>
        private bool m_autoGrid;

        /// <summary>
        /// Indication if the root indices of the display tiles should be
        /// displayed as text.
        /// </summary>
        private bool m_tileRootLabels;

        /// <summary>
        /// Turn on or off the automated generation of pyxis grids to fill the screen.
        /// </summary>
        /// <param name="freezeOldTiles">
        /// When the autogrid feature is being disabled, the tiles that are currently on
        /// the screen will remain when this variable is true. When this variable is 
        /// false the tiles will be removed from the screen when autogrid is disabled.
        /// </param>
        private void ToggleAutoGrid(bool freezeOldTiles)
        {
            Trace.ui("Toggle automated grid generation.");
            m_autoGrid = !m_autoGrid;

            if (!m_autoGrid && !freezeOldTiles)
            {
                DrawingObjects.RemoveCollectionFromRenderer(m_renderer, m_displayTileActors);
            }

            RecalculateScreenTiles();
        }

        /// <summary>
        /// Show or hide the colour coded X, Y and Z axis.
        /// </summary>
        public void ToggleAxis()
        {
            Trace.ui("Toggle X, Y, Z Axes Visibility");
            if (m_axes == null)
            {
                m_axes = DrawingObjects.CreateXYZAxes();
                m_renderer.AddActor(m_axes);
            }
            else
            {
                m_renderer.RemoveActor(m_axes);
                m_axes = null;
            }
        }

        /// <summary>
        /// Turn the visualization on or off for a particular PYXIS resoluiton of cells
        /// slightly above the reference sphere.
        /// </summary>
        public void ToggleResolution(int resolution)
        {
            Trace.ui(string.Format("Toggle PYXIS resolution {0} visibility.", resolution));

            // initialize the list if it has never been used.
            if (m_resolutionList == null)
            {
                m_resolutionList = new List<vtk.vtkActor>();
                while (m_resolutionList.Count < 10)
                {
                    m_resolutionList.Add(null);
                }
            }

            if (m_resolutionList[resolution] == null)
            {
                m_resolutionList[resolution] = 
                    DrawingObjects.CreatePYXISResolution(resolution, 1.01);
                m_renderer.AddActor(m_resolutionList[resolution]);
            }
            else
            {
                m_renderer.RemoveActor(m_resolutionList[resolution]);
                m_resolutionList[resolution] = null;
            }
        }

        /// <summary>
        /// Toggle the Frames Per Second meter on and off.
        /// </summary>
        public void ToggleFPSMeter()
        {
            Trace.ui("Toggle FPS Meter Visibility");
            if (m_FPSDisplay == null)
            {
                m_FPSDisplay = new vtk.vtkTextActor();

                vtk.vtkTextProperty textProperty = m_FPSDisplay.GetTextProperty();
                textProperty.SetFontSize(20);
                textProperty.ShadowOn();
                textProperty.BoldOn();
                textProperty.SetFontFamilyToTimes();
                textProperty.SetOpacity(0.45);

                m_FPSDisplay.SetDisplayPosition(10, 10);
                m_FPSDisplay.SetInput("FPS: Unknown");
                m_renderer.AddActor(m_FPSDisplay);

                // observe the interactor for rendering events
                m_FPSObserverTag = m_renderer.AddObserver(
                    (uint)vtk.EventIds.StartEvent,
                    new vtk.vtkDotNetCallback(RenderEventCallback));                
            }
            else
            {
                // stop observing the rendering events and 
                m_renderer.RemoveObserver(m_FPSObserverTag);
                m_renderer.RemoveActor(m_FPSDisplay);
                m_FPSDisplay = null;
            }
        }

        /// <summary>
        /// This callback is made when the renderer performs a render operation.
        /// </summary>
        private void RenderEventCallback(
            vtk.vtkObject caller,
            uint eventId,
            object clientData,
            IntPtr callData)
        {
            // update the frames per second
            if (m_FPSDisplay != null && m_renderer != null)
            {
                int frameRate = (int)(1.0 / m_renderer.GetLastRenderTimeInSeconds());
                if (frameRate < 200)
                {                    
                    m_FPSDisplay.SetInput(string.Format("FPS: {0}", frameRate));            
                }
            }                            
        }

        /// <summary>
        /// Moves ownership of the C++ VTK actor from the SWIG C# proxy to a VTK C# proxy.
        /// </summary>
        private vtk.vtkActor ConvertActor(SWIGTYPE_p_vtkActor swigActor)
        {
            // Right now in C++ this has reference count of 1 and nobody holds it
            // The opaque swig proxy object does not have ownership!
            // must get it into a vtk.vtkActor quickly
            System.Runtime.InteropServices.HandleRef r = SWIGTYPE_p_vtkActor.getCPtr(swigActor);
            vtk.vtkActor actor = new vtk.vtkActor();
            actor.SetNativePointer(r.Handle);
            return actor;
        }

        /// <summary>
        /// A cursor actor.
        /// </summary>
        private vtk.vtkActorCollection m_cursorActor;

        /// <summary>
        /// Draws the cursor.
        /// </summary>
        private void DrawCursor()
        {
            Trace.info("cursor: " + m_cursor.toString());

            DrawingObjects.RemoveCollectionFromRenderer(m_renderer, m_cursorActor);
            m_cursorActor.RemoveAllItems();

            PYXRGB cursorColour = new PYXRGB(255, 255, 0);
            cursorColour.setAlphaAsDouble(0.75);

            m_cursorActor.AddItem(ConvertActor(PYXVTKDraw.createSphere(
                m_cursor.getIndex(),
                SnyderProjection.getInstance(),
                cursorColour)));

            // TODO during development, don't reuse cursor to go forward/backward
            // as bugs may remain, so instead work on a copy of the cursor.
            Cursor cursorNext = new Cursor(m_cursor);
            cursorNext.forward();
            cursorNext.zoomIn();
            cursorNext.zoomIn();
            m_cursorActor.AddItem(ConvertActor(PYXVTKDraw.createSphere(
                cursorNext.getIndex(),
                SnyderProjection.getInstance(),
                cursorColour)));

            DrawingObjects.AddCollectionToRenderer(m_renderer, m_cursorActor);
            Invalidate();
        }

        /// <summary>
        /// Show or hide the unit sphere. If no reference sphere exists it
        /// is created.
        /// </summary>
        public void ToggleReferenceSphere()
        {
            Trace.ui("Toggle Reference Sphere visibility.");
            if (m_referenceSphere == null)
            {
                m_referenceSphere = DrawingObjects.CreateReferenceSphere();
                m_renderer.AddActor(m_referenceSphere);
            }
            else
            {
                if (m_referenceSphere.GetVisibility() == 0)
                {
                    m_referenceSphere.VisibilityOn();
                }
                else
                {
                    m_renderer.RemoveActor(m_referenceSphere);
                    m_referenceSphere = null;
                }
            }
        }

        /// <summary>
        /// Show or hide the icosahedron. If no icosahedron exists it
        /// is created.
        /// </summary>
        public void ToggleIcosahedron()
        {
            Trace.ui("Toggle Icosahedron visibility.");
            if (m_icosahedron == null)
            {
                m_icosahedron = DrawingObjects.CreateIcosahedron();
                m_renderer.AddActor(m_icosahedron);
            }
            else
            {
                if (m_icosahedron.GetVisibility() == 0)
                {
                    m_icosahedron.VisibilityOn();
                }
                else
                {
                    m_renderer.RemoveActor(m_icosahedron);
                    m_icosahedron = null;
                }
            }
        }

        /// <summary>
        /// Toggle the ramdom changing of the camera position for the control.
        /// </summary>
        private void ToggleRandomCameraMove()
        {
            m_cameraMoveTimer.Enabled = !m_cameraMoveTimer.Enabled;
        }

        /// <summary>
        /// Random member for the class.
        /// </summary>
        Random m_random = new Random();

        /// <summary>
        /// Perform a weighted camera navigation operations of a random amount every time
        /// the timer fires. Used for automated testing to simulate a very erratic user.
        /// </summary>
        private void CameraMoveTimer_Tick(object sender, EventArgs e)
        {
            int n = m_random.Next(100);

            if (n < 50)
            {
                // move
                m_cameraPtr.rotate(m_random.Next(10) - 5, m_random.Next(10) - 5);
            }
            else if (n < 60)
            {
                // tilt
                m_cameraPtr.tilt(m_random.Next(20) - 10);
            }
            else if (n < 70)
            {
                // spin
                m_cameraPtr.spin(m_random.Next(20) - 10);
            }
            else if (n < 95)
            {
                // zoom
                if (m_random.Next(2) == 0)
                {
                    m_cameraPtr.setZoom(
                        m_cameraPtr.getState().getViewAngle() *
                        (1.0 + Properties.Settings.Default.KeyboardZoom));
                }
                else
                {
                    m_cameraPtr.setZoom(
                        m_cameraPtr.getState().getViewAngle() *
                        (1.0 - Properties.Settings.Default.KeyboardZoom));
                }
            }
        }

#endregion

        #region Tile Threads

        /// <summary>
        /// Cancel any pending tile selection thread operations and create a 
        /// new tile selection thread member when needed. 
        /// Any running thread will no longer be accessable but will 
        /// still be associated with the event handlers. 
        /// </summary>
        private void ResetTileSelectionThread()
        {
            System.Diagnostics.Debug.Assert(m_tileSelectionThread != null);

            m_tileSelectionThread.CancelAsync();

            // create a new thread object and initialize the handlers
            m_tileSelectionThread = new BackgroundWorker();
            m_tileSelectionThread.WorkerSupportsCancellation = true;
            m_tileSelectionThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.TileSelectionThread_DoWork);
            m_tileSelectionThread.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.TileSelectionThread_RunWorkerCompleted);
        }

        /// <summary>
        /// Perform the time consuming action of selecting the tiles that cover the
        /// current screen in the background thread.
        /// </summary>
        /// <param name="sender">
        /// The instance of the background thread.
        /// </param>
        /// <param name="e">
        /// The data about the thread shared between the worker and the calling
        /// thread.
        /// </param>
        private void TileSelectionThread_DoWork(object sender, DoWorkEventArgs e)
        {
            // Do not access the form's BackgroundWorker reference directly.
            // Instead, use the reference provided by the sender parameter.
            BackgroundWorker bw = sender as BackgroundWorker;
            ScreenTileTest screenTest = e.Argument as ScreenTileTest;
            System.Diagnostics.Debug.Assert(screenTest != null);

            PYXIcosTestTraverser traverser = new PYXIcosTestTraverser();
            traverser.setTest(screenTest);
            traverser.traverse(PYXIcosIndex.knMinSubRes,
                                screenTest.getTargetResolution());

            // If the operation was canceled by the user, 
            // set the DoWorkEventArgs.Cancel property to true.
            if (bw.CancellationPending)
            {
                e.Cancel = true;
            }
            else
            {
                e.Result = traverser.getTileCollection();
            }
        }

        /// <summary>
        /// The information used to generate the screen of tile data during
        /// the autogridding process.
        /// </summary>
        private TileGenerationInformation m_tileGenInfo;

        /// <summary>
        /// This method 
        /// </summary>
        /// <remarks>This method is executed in the same thread as the call to 
        /// RunWorkerAsync(). The asynchronous event handling is performed 
        /// by the framework behind the scenes.
        /// </remarks>
        /// <param name="sender">
        /// The source of the call (the background worker thread).
        /// </param>
        /// <param name="e">
        /// A reference to the arguments shared by the worker thread.
        /// </param>
        private void TileSelectionThread_RunWorkerCompleted(
            object sender, 
            RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                Trace.error(string.Format(
                    "Tile selection thread return with an error code:\n {0}",
                    e.Error.Message));
            }
            else if (e.Cancelled)
            {
                Trace.thread("Tile selection thread returned with a cancel code.");
            }
            else
            {
                Trace.thread("The tile selection thread completed. Spawning tile generation thread.");

                // Create an object to store the parameters for the display tiles
                m_tileGenInfo = new TileGenerationInformation();
                PYXTileCollection_SPtr collectionPtr = e.Result as PYXTileCollection_SPtr;
                System.Diagnostics.Debug.Assert(collectionPtr != null);
                m_tileGenInfo.TileCollection = collectionPtr;

                m_tileGenInfo.ViewPoint = m_cameraPtr.getState().getPosition();
                m_tileGenInfo.FocalPoint = m_cameraPtr.getState().getFocalPoint();

                // start the generation thread
                GenerateTiles();
            }
        }

        /// <summary>
        /// Geterate new tiles for the current screen of data.
        /// </summary>
        private void GenerateTiles()
        {
            if (m_tileGenInfo != null)
            {
                ResetTileGenerationThread();
                m_tileGenerationThread.RunWorkerAsync(m_tileGenInfo);
            }
        }

        /// <summary>
        /// Cancel any pending tile generation thread operations and create a 
        /// new tile generation thread member when needed. 
        /// Any running thread will no longer be accessable but will
        /// still be associated with the event handlers. 
        /// </summary>
        private void ResetTileGenerationThread()
        {
            System.Diagnostics.Debug.Assert(m_tileGenerationThread != null);

            // if the thread is not busy it is ready to be re-used
            m_tileGenerationThread.CancelAsync();

            // create a new thread object and initialize the handlers
            m_tileGenerationThread = new BackgroundWorker();
            m_tileGenerationThread.WorkerReportsProgress = true;
            m_tileGenerationThread.WorkerSupportsCancellation = true;
            m_tileGenerationThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.TileGenerationThread_DoWork);
            m_tileGenerationThread.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.TileGenerationThread_RunWorkerCompleted);
            m_tileGenerationThread.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.TileGenerationThread_ProgressChanged);
        }

        /// <summary>
        /// Perform the time consuming task of generating all of the display tiles in
        /// a background worker thread.
        /// </summary>
        /// <param name="sender">
        /// The background worker thread object.
        /// </param>
        /// <param name="e">
        /// The shared data between the background worker thread and the 
        /// calling thread.
        /// </param>
        private void TileGenerationThread_DoWork(object sender, DoWorkEventArgs e)
        {
            // Do not access the form's BackgroundWorker reference directly.
            // Instead, use the reference provided by the sender parameter.
            BackgroundWorker bw = sender as BackgroundWorker;

            // acquire the tiles and add them to the rendering pipeline
            TileGenerationInformation tileGenInfo = 
                e.Argument as TileGenerationInformation;
            System.Diagnostics.Debug.Assert(tileGenInfo != null);
            System.Diagnostics.Debug.Assert(tileGenInfo.TileCollection != null);

            Vector_DisplayTile displayTiles = new Vector_DisplayTile();
            PYXTileCollectionIterator_SPtr tileIterator = 
                tileGenInfo.TileCollection.getTileIterator();

            for (; !tileIterator.end(); tileIterator.next())
            {
                if (bw.CancellationPending)
                {
                    break;
                }
                PYXDisplayTile_SPtr tile = null;

                System.Diagnostics.Debug.Assert(m_dataManager != null);
                if (m_dataManager.hasData())
                {
                    tile = m_screenManager.getDataTile(
                            tileIterator.getTile().get(), 
                            m_dataManager.getProcRef());
                }
                else
                {
                    tile = m_screenManager.getGridTile(tileIterator.getTile().get());
                }

                displayTiles.Add(tile);
                bw.ReportProgress(
                    97 * 
                    displayTiles.Count / 
                    tileGenInfo.TileCollection.getGeometryCount());
            }

            // sort the tiles according to which are closest to centre of the screen
            if (!bw.CancellationPending)
            {
                ScreenManager.sortTiles(
                    tileGenInfo.ViewPoint,
                    tileGenInfo.FocalPoint,
                    displayTiles);
            }

            // set the return status of the thread
            if (bw.CancellationPending)
            {
                e.Cancel = true;
            }
            else
            {
                e.Result = displayTiles;
            }
        }

        /// <summary>
        /// This method handles progress messages sent asyncronously from the 
        /// tile generation thread. The method updates the ui with a progress
        /// indicator.
        /// </summary>
        /// <param name="sender">
        /// The calling thread.
        /// </param>
        /// <param name="e">
        /// The progress data
        /// </param>
        private void TileGenerationThread_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
           //Trace.info(string.Format(
           //     "Tile generation thread {0}% complete.", 
           //     e.ProgressPercentage));
        }

        /// <summary>
        /// The event handler for when the tile generation thread has completed 
        /// running. the method runs in the main thread and populates the
        /// renderer with the newly created visual tiles.
        /// </summary>
        /// <param name="sender">
        /// The thread that has completed.
        /// </param>
        /// <param name="e">
        /// The data about the completed thread operation.
        /// </param>
        private void TileGenerationThread_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                Trace.error(string.Format(
                    "Tile generation thread return with an error code:\n {0}",
                    e.Error.Message));
            }
            else if (e.Cancelled)
            {
                Trace.thread("Tile generation thread returned with a cancel code.");
            }
            else
            {
                Trace.thread("The tile generation thread completed, loading tiles.");

                // remove all the existing tiles from the renderer
                DrawingObjects.RemoveCollectionFromRenderer(m_renderer, m_displayTileActors);
                m_displayTileActors.RemoveAllItems();

                // TODO: Remove the need to set tile origins
                // Set the origin of all of the tiles and add them to the renderer
                //m_displayTiles = e.Result as Vector_DisplayTile;


                Vector_DisplayTile resultTiles = e.Result as Vector_DisplayTile;


                //m_displayTiles.Clear();
                //System.Diagnostics.Debug.Assert(m_displayTiles != null);


                PYXDisplayTile_SPtr firstTile = null;

                int count = 0;

                // add each tile to the display
                foreach (PYXDisplayTile_SPtr tilePtr in resultTiles)
                {
                    if (firstTile == null)
                    {
                        firstTile = tilePtr;
                    }
                    tilePtr.setOrigin(firstTile.getCentrePoint());

                    vtk.vtkActor tileActor =
                        DrawingObjects.PYXISToVTKActor(tilePtr.getActor());
                    System.Diagnostics.Debug.Assert(tileActor != null);
                    m_renderer.AddViewProp(tileActor);
                    m_displayTileActors.AddItem(tileActor);

                    // add labels for the tiles
                    if (m_tileRootLabels)
                    {
                        vtk.vtkCaptionActor2D textActor =
                            DrawingObjects.CreateIndexAnnotation(tilePtr.getTile().getRootIndex());
                        m_renderer.AddViewProp(textActor);
                        m_displayTileActors.AddItem(textActor);
                    }
                    count++;
                }
                Invalidate();

                UpdateTiles(resultTiles);
            }            
        }

        private void UpdateTiles(Vector_DisplayTile tiles)
        {
            // if the thread is not busy it is ready to be re-used
            m_tileUpdatingThread.CancelAsync();

            // create a new thread object and initialize the handlers
            m_tileUpdatingThread = new BackgroundWorker();
            m_tileUpdatingThread.WorkerReportsProgress = true;
            m_tileUpdatingThread.WorkerSupportsCancellation = true;
            m_tileUpdatingThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.TileUpdatingThread_DoWork);
            m_tileUpdatingThread.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.TileUpdatingThread_RunWorkerCompleted);
            m_tileUpdatingThread.ProgressChanged += new ProgressChangedEventHandler(this.TileUpdatingThread_ProgressChanged);

            m_tileUpdatingThread.RunWorkerAsync(tiles);
        }

        private void TileUpdatingThread_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bw = sender as BackgroundWorker;
            Vector_DisplayTile tiles = e.Argument as Vector_DisplayTile;

            foreach (PYXDisplayTile_SPtr tilePtr in tiles)
            {
                if (bw.CancellationPending)
                {
                    break;
                }
                tilePtr.updateTile();
                bw.ReportProgress(5);
            }

            foreach (PYXDisplayTile_SPtr tilePtr in tiles)
            {
                if (bw.CancellationPending)
                {
                    break;
                }
                tilePtr.updateTile();
                bw.ReportProgress(5);
            }


        }

        private void TileUpdatingThread_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Invalidate();
        }

        private void TileUpdatingThread_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //BackgroundWorker bw = sender as BackgroundWorker;
            //bw.ReportProgress(5);


        }



        #endregion

    }
}
