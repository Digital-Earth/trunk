#ifndef PYX_DATA_DISPLAY_TILE_H
#define PYX_DATA_DISPLAY_TILE_H
/******************************************************************************
data_display_tile.h

begin		: 2005-02-21
copyright	: (C) 2005 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/
#include "visualization_model.h"

// local includes
#include "display_tile_info.h"
#include "display_tile.h"

#include "pyxis/data/coverage.h"
#include "pyxis/derm/progressive_iterator.h"
#include "pyxis/pipe/process.h"

// standard includes
#include <vector>

// local forward declarations
class ColourConverter;
class PYXTile;
class PYXValue;
class ThreadState;

// vtk forward declarations
class vtkBMPWriter;
class vtkDoubleArray;
class vtkImageData;
class vtkTexture;
class vtkUnsignedCharArray;

/*!
The description that uniquely identifies a data display tile.
*/
//! Collection of parameters used to define a unique data tile
class VISUALIZATION_MODEL_DECL DataDisplayTileSpec : public DisplayTileSpec
{
public: 

	/*
	Constructor parameters: guid is the global unique identifier for a tile.
	TRI is the default texture resolution increment, used when drawing the
	texture image for the tile.
	*/
	//! The constructor
	DataDisplayTileSpec(
		const ProcRef& procref,
		int nTRI = PYXDisplayTileInfo::knTextureResIncrement) : 
	  m_procref(procref),
	  m_nGoalTextureResolutionIncrement(nTRI){;}

	//! The destructor
	~DataDisplayTileSpec() {;}

	//! Equality operator provided to allow ordering in containers.
	bool operator==(const DisplayTileSpec& spec) const;

	//! Return the process reference to the visualization process.
	const ProcRef& getProcRef() const {return m_procref;}

	//! Return the spec's TRI.
	int getTRI() const {return m_nTextureResolutionIncrement;}

	void setTRI(int nTRI) {m_nTextureResolutionIncrement = nTRI;}

	int getFinalTRI() const {return m_nGoalTextureResolutionIncrement;}


private:

	//! The process reference of the single visualizable process
	ProcRef m_procref;

	//! The texture resolution increment.
	int m_nTextureResolutionIncrement;

	int m_nGoalTextureResolutionIncrement;
};

/*!
Represents a single tile of PYXIS data rendered using VTK. The tile can include
a single or multiple data sets.  The root index of a display tile must always
be a centroid child index. This object is reference counted using the vtkObject 
reference counting facility and should always be managed using 
boost::intrusive_ptr smart pointer objects. The object is also an asynchronous 
notifier meaning that notifications coming from this tile are placed in a 
global message queue rather than calling observers directly. This means that the 
display tile can safely notify across threads but that timing of notification 
processing can not be assumed.
*/
//! The VTK representation of an individual tile of data.
class VISUALIZATION_MODEL_DECL PYXDataDisplayTile : public PYXDisplayTile, private Observer
{
public:

	static const double kfMaxElevationFactor;
	static const double kfMinElevationFactor;
	static const int knInterpolationCorrection;

	// properties strings
	static const std::string kstrScope;
	static const std::string kstrTagLightAmbient;
	static const std::string kstrTagDescLightAmbient;
	static const std::string kstrTagLightDiffuse;
	static const std::string kstrTagDescLightDiffuse;
	static const std::string kstrTagLightSpecular;
	static const std::string kstrTagDescLightSpecular;
	static const std::string kstrTagVectorOpacity;
	static const std::string kstrTagDescVectorOpacity;

	//! Unit test method
	static void test();

	//! Creator.
	static PYXPointer<PYXDataDisplayTile> create()
	{
		return PYXNEW(PYXDataDisplayTile);
	}

	//! Constructor.
	PYXDataDisplayTile();

	//! Default destructor.
	virtual ~PYXDataDisplayTile();

	//! Return the class name of this observer class.
	virtual std::string getObserverDescription() const {return kstrScope;}

	//! Return the name of the notification class.
	virtual std::string getNotifierDescription() const {return kstrScope;}

	// Create a data tile using the passed information.
	void initializeTile(DisplayTileSpec* pSpec);
  
	void updateTile();

	//! Update the data displayed on the texture image.
	void updateData();
	
	//! Set a multiplication factor for any elevation data.
	void setElevationFactor(double fElevationFactor);

	//! Get the elevation factor.
	double getElevationFactor() const {return m_fElevationFactor;}

	//! Return the symbols to the caller.
//	PYXVTKSymbolLibrary::SymbolVector* getSymbols() {return &m_vecSymbols;}
	
protected:

	//! Define the connectivity for the tile
	virtual void setGrid();

private:

	//! Process events from observed objects
	virtual void updateObserverImpl(PYXPointer< NotifierEvent > spEvent);

	//! Associate the appropriate data sources from the library with the tile.
	void setData();

	//! Process and apply elevation for the tile.
	void updateElevation(boost::intrusive_ptr<ICoverage> spCov);

	//! Apply an elevation value to an existing x, y, z point in the array.
	void applyElevation(	const double& fElevation, 
							int nOffset	);
	
	//! Given a PYXIS index, return RGB colour.
	bool getColour(	const PYXIcosIndex& pyxIndex,
					unsigned char pcColour[3]	) const;
	
	//! Look up RGB colour to represent an elevation.
	void getColourFromElevation( const double& fElevation,
								 unsigned char pcColour[3]	) const;

	////! Given a value, return RGB colour.
	bool getColourFromValue(	const PYXValue& value,
								unsigned char pcColour[3]	) const;

	//! Free the data sources
	void freeDataSources();

	//! Set values for vector data
//	bool setVectorData(boost::shared_ptr<ThreadState> spState);

	//! Create and store an icon for a feature.
	//bool addSymbolFeature(	PYXDataItem::CSPtr spDataItem,
	//						FeatureStyle::FeatureStyleConstPtr spStyle, 
	//						boost::shared_ptr<const PYXFeature> spFeature	);

	//! Initialize the default elevation colour tables
	static void initStaticData();

	//! Free static data.
	static void freeStaticData();

	//! Get the offset into the vtk point array for a particular index
	int calcIndexOffset(	const PYXIcosIndex& pyxIndex,
							PYXEdgeIterator* pEdgeIterator = 0	);

	//! Update tile texture image
	void updateTexture();

private:

	//! EXPERIMENTAL: true when texture image has been populated once.
	bool m_bTextureDone;

	bool m_bFirstUpdateComplete;

	//! This tile's progressive update level.
	int m_nUpdateLevel;

	//! An indication that one level of knitting has occurred
	bool m_bProgressiveKnittingComplete;

	//! The progressive iterator for the update process.
	PYXProgressiveIterator m_itProgressive;

	//! The colour converter for elevation data.
	static std::auto_ptr<ColourConverter> m_spElevationColours;

	//! Default ambient light characteristic.
	static double m_fDefaultAmbient;

	//! Default ambient light characteristic.
	static double m_fDefaultDiffuse;

	//! Default specular light characteristic.
	static double m_fDefaultSpecular;

	//! The opacity of vector data.
	static double m_fVectorOpacity;

	//! The multiplication factor to apply to any elevation data.
	double m_fElevationFactor;

	//! The unique process the defines the coverage data
	boost::intrusive_ptr<IProcess> m_spCoverageProc;

	//! The array of texture coordinate pairs
	boost::intrusive_ptr<vtkDoubleArray> m_spTextureCoords;

	//! The texture object itself
	boost::intrusive_ptr<vtkTexture> m_spTexture;

	//! The image object containing the texture pixels (texels)
	boost::intrusive_ptr<vtkImageData> m_spTextureImage;

	//! A buffer value to avoid repeated construction of values.
	mutable PYXRGB m_rgbBuffer;

	//! A mutex for data specific access of the tile (from the cache).
	mutable boost::recursive_mutex m_dataTileMutex;

	mutable boost::mutex m_mutex;

	//! Allows PYXLibVisualization to initialize the static data.
	friend class VisualizationModelInitializer;
};

//! This class is only used for testing and can not be rendered.
class PYXTestDataDisplayTile : public PYXDataDisplayTile
{
public:

	//! Constructor
	PYXTestDataDisplayTile() {;}

	//! Default destructor.
	virtual ~PYXTestDataDisplayTile() {;}

	//! Return the class name of a vtk derived class.
	virtual const char* GetClassName() {return "PYXTestDataDisplayTile";};

	////! Create a data tile using the passed information.
	//void initializeTile(	
	//			const PYXTile& pyxTile,
	//			const PYXLibrary::PYXDataItemList& lstDataItem	);

protected:
	
	//! Stub out the set data method
	virtual void setGrid() {;}
};

/*!
This class defines events that originate from display tiles.  Currently view
classes are the only observers of display tiles.  This means that no state
is required since it is merely a visual update.
*/
//! Events that originate from display tiles.
class PYXDataDisplayTileEvent : public NotifierEvent
{
public:
	
	//! The types of different PYXDataDisplayTileEvents
	enum eEventType
	{
		knData,			//!< The data of this tile has changed.
		knSymbolData	//!< The data and symbol information has changed.
	};

	//! Default constructor sets the type to knDataChanged.
	PYXDataDisplayTileEvent(PYXDataDisplayTile* pTile) :
		m_pTile(pTile),
		m_nType(knData) {;}

	//! Destructor.
	virtual ~PYXDataDisplayTileEvent() {;}

	//! Set the specific event type.
	void setEventType(eEventType nType) {m_nType = nType;}

	//! Get the specific event type.
	eEventType getEventType() {return m_nType;}

	//! Get the tile source of the event message.
	PYXDataDisplayTile* getTile() {return m_pTile;}

protected:

	//! Disable copy constructor
	PYXDataDisplayTileEvent(const PYXDataDisplayTileEvent&);

	//! Disable copy assignment
	void operator =(const PYXDataDisplayTileEvent&);

private:

	//! The type of event being transmitted.
	eEventType m_nType;

	//! The source tile for the event.
	PYXDataDisplayTile* m_pTile;
};

#endif	// PYX_DATA_DISPLAY_TILE_H
