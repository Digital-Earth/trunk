#ifndef PYX_DISPLAY_TILE_H
#define PYX_DISPLAY_TILE_H
/******************************************************************************
display_tile.h

begin		: 2004-09-20
copyright	: (C) 2004 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/
#include "visualization_model.h"

// local includes

// pyxlib includes
#include "pyxis/derm/index.h"
#include "pyxis/derm/snyder_projection.h"
#include "pyxis/geometry/tile.h"
#include "pyxis/utility/cache_status.h"
#include "pyxis/utility/coord_3d.h"
#include "pyxis/utility/memory_manager.h"
#include "pyxis/utility/notifier.h"
#include "pyxis/utility/rgb.h"

// local forward declarations
class ProjectionMethod;
class PYXEdgeIterator;
class ThreadState;

// vtk include 
#include "vtkActor.h"	// needed as include for swig.

// vtk forward declarations
class vtkCellArray;
class vtkIdTypeArray;
class vtkPoints;
class vtkPolyData;
class vtkPolyDataMapper;
class vtkUnsignedCharArray;

/*!
This interface defines a set of parameters that is used to uniquely define
a display tile of any type. The class is meant to be specialized for each
different type of display tile.
*/
//! Parameters used to define a unique tile
class VISUALIZATION_MODEL_DECL DisplayTileSpec
{
public: 

	//! The default destructor
	~DisplayTileSpec() {;}

	//! Get the specified geometry for the tile
	const PYXTile& getTile() const {return m_tile;}

	//! Set the geometry for the specification
	void setTile(const PYXTile& tile) 
	{
		assert(!tile.getRootIndex().isNull() && "Invalid tile for specification");
		m_tile = tile;
	}

	/*!
	Return the projection that converts from PYXIS coordinates to xyz 
	coordinates. 

	\return the SnyderProjection.
	*/
	//! Return the projection for rendering this tile.
	const ProjectionMethod* getProjection() const {return SnyderProjection::getInstance();}
	

	//! Equality operator provided to allow ordering in containers.
	virtual bool operator==(const DisplayTileSpec& spec) const = 0;

protected:

	//! Default constructor
	DisplayTileSpec() {;}

private:

	//! The geometry for the display tile described by this class.
	PYXTile m_tile;
};

/*!
This base class is used to create custom tile visualization classes.  The
class (and any derived class) is cachable in a PYXDisplayTileCache.
*/
//! The VTK representation of an individual visual tile.
class VISUALIZATION_MODEL_DECL PYXDisplayTile : public Notifier, public PYXObject
{
public:

	// PYXIS constants
	static const int knInvalidOffset;

	//! Initialize a display tile to represent a unique display tile specification.
	virtual void initializeTile(DisplayTileSpec* pSpec) = 0;

	virtual void updateTile() = 0;

	//! Get the tile.
	const PYXTile& getTile() const { return m_spSpec->getTile(); }

	//! Get the actor associated with this tile
	inline boost::intrusive_ptr<vtkActor> getActor() {return m_spActor;}
	
	//! Determine if the passed geometry intersects with the tile geometry.
	bool intersects(const PYXGeometry& geometry);

	//! Determine if a tile conforms to a specification.
	bool matchesSpec(const DisplayTileSpec& spec) 
	{
		assert(m_spSpec.get() != 0 && "Invalid specification for tile.");
		return *(m_spSpec.get()) == spec;
	}

	//! Set the lighting properties of the tile.
	void setLightProperties(	double fAmbient,
								double fDiffuse,
								double fSpecular	);

	//! Return the timer object for the tile
	CacheStatus* getCacheStatus() {return &m_cacheStatus;}

	//! Set the origin point for the tile.
	void setOrigin(const PYXCoord3DDouble& coordOrigin);

	/*!
	Return the centre point of the tile as it would exist on the reference
	sphere.

	\return The centre point of the tile.
	*/
	//! Get the centre point of the tile.
	const PYXCoord3DDouble& getCentrePoint() {return m_centrePoint;}

#if 0 // removed until threading is added.
	/*!
	This method does nothing in the default implementation. Derived classes
	can use this method to perform slow or CPU intensive tasks for the 
	creation of tiles (such as extracting data) since it is generally called
	from a child thread of the application. It is the responsibility of the
	tile to notify any observers of changes.

	\param spState	The state of the thread that is calling the method.

	\return true if some update was made or false if the tile is complete.
	*/
	//! Called from a thread to complete the work begun during initialization.
	virtual bool updateTile(boost::shared_ptr<ThreadState> spState) 
	{
		return false;
	}
#endif 

protected:

	//! Hide default constructor from all but derived classes.
	PYXDisplayTile();

	//! Default destructor.
	virtual ~PYXDisplayTile();

	//! Initialize the tile geometry and points
	void initializeTileGeometry(	const PYXTile& pyxTile,
									const ProjectionMethod* pProjection	);

	//! Define the connectivity for the tile.
	virtual void setGrid() = 0;

	//! Convert an index to a point.
	void calcCoordinate(	const PYXIcosIndex& pyxIndex,
							PYXCoord3DDouble* pPoint	);

	//! The total number of individual points in the tile.
	int m_nMaxCount;

	//! The offset to the start of the edge iterator (knInvalidOffset if contained).
	int m_nKnitOffset;

	//! The vtk actor
	boost::intrusive_ptr<vtkActor> m_spActor;

	//! The mapper for visualizing the data tile.
	boost::intrusive_ptr<vtkPolyDataMapper> m_spMapper;

	//! The collection of visualization data for this actor.
	boost::intrusive_ptr<vtkPolyData> m_spPolyData;

	//! The collection of point data for this actor.
	boost::intrusive_ptr<vtkPoints> m_spPoints;

	//! The collection of cell (connectivity) data for this actor.
	boost::intrusive_ptr<vtkCellArray> m_spCells;

	//! The x, y, z world coordinate location of the origin.
	PYXCoord3DDouble m_coordOrigin;

	//! Acquire the mutex for the class
	boost::recursive_mutex& getDisplayTileMutex() const {return m_displayTileMutex;}

	//! The specification that uniquely identifies this display tile.
	std::auto_ptr<DisplayTileSpec> m_spSpec;
	
private:

	//! Disable copy constructor.
	PYXDisplayTile(const PYXDisplayTile&);

	//! Disable copy assignment.
	void operator=(const PYXDisplayTile&);

	//! Disable the equality operator.
	bool operator==(const PYXDisplayTile& rhs) const;

	//! Initialize the points of the tile to be on the reference sphere.
	void initializePoints();

	//! Protection from other threads.
	mutable boost::recursive_mutex m_displayTileMutex;

	//! The centre point of the tile.
	PYXCoord3DDouble m_centrePoint;

	//! The timer object for the tile
	CacheStatus m_cacheStatus;

	//! The memory token for the tile.
	std::auto_ptr<MemoryToken> m_spMemoryToken;

	//! The number of bytes of storage required for each data point.
	static const int m_nBytesPerPoint;

	//! Number of bytes of overhead (estimate) required by the class.
	static const int m_nByteOverhead;

	//! Allows PYXLibVisualization to initialize the static data.
	friend class PYXLibVisualization;
};

#endif	// PYX_DISPLAY_TILE_H
