/******************************************************************************
display_tile_info.cpp

begin		: 2006-03-23
copyright	: (C) 2006 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/

#define VISUALIZATION_MODEL_SOURCE
#include "display_tile_info.h"

// local includes
#include "exceptions.h"
#include "vtk_utils.h"

// pyxlib includes
#include "pyxis/derm/edge_iterator.h"
#include "pyxis/derm/exhaustive_iterator.h"
#include "pyxis/derm/hexagon.h"
#include "pyxis/derm/index.h"
#include "pyxis/derm/index_math.h"
#include "pyxis/derm/spiral_iterator.h"
#include "pyxis/derm/sub_index_math.h"
#include "pyxis/derm/vertex_iterator.h"
#include "pyxis/utility/app_services.h"
#include "pyxis/geometry/tile.h"

// vtk includes
#include "vtkCellArray.h"
#include "vtkDoubleArray.h"
#include "vtkTriangleStrip.h"

// boost includes
#include <boost/filesystem/operations.hpp>

// standard includes
#include <fstream>
#include <limits>

// properties strings
const std::string PYXDisplayTileInfo::kstrScope = "PYXDisplayTileInfo";
const std::string PYXDisplayTileInfo::kstrTagProgressiveDepth = "ProgressiveDepth";
const std::string PYXDisplayTileInfo::kstrTagDescProgressiveDepth = "The number of resolutions of data to update progressively.";
const std::string PYXDisplayTileInfo::kstrTagDefaultTileColour = "DefaultTileColour";
const std::string PYXDisplayTileInfo::kstrTagDescDefaultColour = "The default colour for uninitialized display tiles.";

//! The default background colour (opaque black)
static const PYXRGB kDefaultColour;

//! The offset value for a pyxis index that does not exist in the tile
const int PYXDisplayTileInfo::knInvalidOffset = -1;

//! The largest depth value for a Display Tile (must be <= PYXTile value)
const int PYXDisplayTileInfo::knMaxDisplayTileDepth = 6;

//! The smallest depth value for a Display Tile (must be >= PYXTile value)
const int PYXDisplayTileInfo::knMinDisplayTileDepth = 2;

//! The default depth value for a Display Tile.
const int PYXDisplayTileInfo::knDefaultDisplayTileDepth = 6;

//! The maximum TRI to calculate texture data for. Currently, the max is 6.
const int PYXDisplayTileInfo::knMaxTextureResIncrement = 4;

//! The minimum TRI to calculate texture data for.
// This must start at 1. TODO: Add handling to start at non-1, later, as required.
const int PYXDisplayTileInfo::knMinTextureResIncrement = 1;

//! The current setting for TRI. Just needs to be changed in this location.
const int PYXDisplayTileInfo::knTextureResIncrement = 4;

//! The number of extra spirals to draw when using the SpiralIterator.
const int PYXDisplayTileInfo::knInterpolationCorrection = 1;

//! String constants for writing section headers to file.
// Must be less than 20 characters.
static const std::string strTriId = "TRIID";
static const std::string strHexId = "HEXID";
static const std::string strTextureWidth = "TEXTUREWIDTH";
static const std::string strTextureCoordinates = "TEXTURECOORDINATES";
static const std::string strTexelOffsets = "TEXELOFFSETS";

//! The current version number of Connectivity.bin.
const int PYXDisplayTileInfo::knConnectivityBinVersion = 10;

//! The name of the tile connectivity file
static const std::string kstrConnectivityFile = "connectivity.bin";

//! The default number of resolutions to update progressively.
static const int knProgressiveDepth = 0;

//! The number of resolutions to update progressively.
int PYXDisplayTileInfo::m_nProgressiveDepth;

//! The configuration defined default background colour.
PYXRGB PYXDisplayTileInfo::m_rgbDefault;

/*! 
The three dimensional array that indicates the connectivity of the cells that
make up the tesselation for a tile.  The connectivity is made by cutting each
hexagon into six triangles.  The connectivity is listed as connection between 
offset values in the order dictated by a PYXIcosIterator and PYXEdgeIterator.  

The array has the following properties:
  Dimension 0:	The class (PYXMath::eHexClass) of the root index of the tile.
  Dimension 1:	The type of tesselation as defined by eTileType.
  Dimension 2:	The tesselation depth for the tile.
*/
PYXDisplayTileInfo::IdArrayTripleVector PYXDisplayTileInfo::m_vecTriIds;

/*! 
The three dimensional array that indicates the connectivity of the cells that
make up the tesselation for a tile.  The connectivity is made by defining each
of the hexagons for the resolution.  The connectivity is listed as connection 
between offset values in the order dictated by a PYXIcosIterator and 
PYXEdgeIterator.  

The array has the following properties:
  Dimension 0:	The class (PYXMath::eHexClass) of the root index of the tile.
  Dimension 1:	The type of tesselation as defined by eTileType.
  Dimension 2:	The tesselation depth for the tile.
*/
PYXDisplayTileInfo::IdArrayTripleVector PYXDisplayTileInfo::m_vecHexIds;

/*! 
The three dimensional array that stores the Texture Coordinate Bases for
the actual texture image. Currently we only "really" need the width
attribute. This should be refactored later, when time permits.

The array has the following properties:
  Dimension 0:	The class (PYXMath::eHexClass) of the root index of the tile.
  Dimension 1:	The type of tesselation as defined by eTileType.
  Dimension 2:	The tesselation depth for the tile.
*/
PYXDisplayTileInfo::TextureWidthTable4 PYXDisplayTileInfo::m_vecTextureWidths;

/*! 
The three dimensional array that stores the Texture Coordinates  for
the actual texture image.

The array has the following properties:
  Dimension 0:	The class (PYXMath::eHexClass) of the root index of the tile.
  Dimension 1:	The type of tesselation as defined by eTileType.
  Dimension 2:	The tesselation depth for the tile.
  Dimension 3:  The texture resolution increment
*/
PYXDisplayTileInfo::TextureCoordTable4 PYXDisplayTileInfo::m_vecTextureCoords;

/*! 
The three dimensional array that stores the Texel Offsets for
the actual texture image.

The array has the following properties:
  Dimension 0:	The class (PYXMath::eHexClass) of the root index of the tile.
  Dimension 1:	The type of tesselation as defined by eTileType.
  Dimension 2:	The tesselation depth for the tile.
  Dimension 3:  The texture resolution increment
*/
PYXDisplayTileInfo::TexelOffsetTable4 PYXDisplayTileInfo::m_vecTexelOffsets;

/*!
This method initializes grid connectivity vector which contains a 
connectivity set for each of the different styles of tesselation.  Each item 
in the vector is composed of a list of polygons defined by offsets that
correspond to the ordering of the associated iterators.
*/
void PYXDisplayTileInfo::initStaticData()
{
	// store configured values
	m_nProgressiveDepth = getAppProperty(	kstrScope,
											kstrTagProgressiveDepth,
											knProgressiveDepth,
											kstrTagDescProgressiveDepth	);

	m_rgbDefault = getAppProperty(	kstrScope,
									kstrTagDefaultTileColour,
									kDefaultColour,
									kstrTagDescDefaultColour	);


	// attempt to read the information from the file first.
	if (readFromFile())
	{
		// information was cached in a file, do not calculate
		return;
	}


	TRACE_TIME("Starting tile connectivity generation.");

	// create a full set of information for both class I and class II hexagons
	for (	int nClass = PYXMath::knClassI;
			nClass <= PYXMath::knClassII;
			++nClass	)
	{
		// push a new double array onto the triple array
		m_vecTriIds.push_back(IdArrayDoubleVector());
		m_vecHexIds.push_back(IdArrayDoubleVector());
		m_vecTextureWidths.push_back(TextureWidthTable3());
		m_vecTextureCoords.push_back(TextureCoordTable3());
		m_vecTexelOffsets.push_back(TexelOffsetTable3());

		
		// cycle through each of the different types of tesselations
		PYXIcosIndex rootIndex;
		for (	int nType = knStandard; 
				nType <= knPole12; 
				++nType	)
		{
			// assign the second dimension arrays
			m_vecTriIds[nClass].push_back(IdArrayVector());
			m_vecHexIds[nClass].push_back(IdArrayVector());
			m_vecTextureWidths[nClass].push_back(TextureWidthTable2());
			m_vecTextureCoords[nClass].push_back(TextureCoordTable2());
			m_vecTexelOffsets[nClass].push_back(TexelOffsetTable2());


			// Determine a valid class I root index for each type.
			switch (nType)
			{
			case knStandard:
				rootIndex = "A-000";
				break;

			case knPole1:
				rootIndex = "1-000";
				break;

			case knPole12:
				rootIndex = "12-000";
				break;

			default:
				assert(false && "Invalid tile type.");
				break;
			}

			// if this is class II increment the root resolution to alter class
			if (nClass == PYXMath::knClassII)
			{
				rootIndex.incrementResolution();
			}
			
			// iterate over the valid resolution depths
			int nRootResolution = rootIndex.getResolution();

			for (	int nDepth = 0; 
					nDepth <= knMaxDisplayTileDepth; 
					++nDepth	)
			{
				m_vecTriIds[nClass][nType].push_back(0);
				m_vecHexIds[nClass][nType].push_back(0);
				m_vecTextureWidths[nClass][nType].push_back(TextureWidthTable1());
				m_vecTextureCoords[nClass][nType].push_back(TextureCoordTable1());
				m_vecTexelOffsets[nClass][nType].push_back(TexelOffsetTable1());

				if (nDepth < knMinDisplayTileDepth)
				{
					// just a place holder, continue
					continue;
				}

				int nMeshCellVertexRes = nDepth + nRootResolution;
				TRACE_INFO("Processing tile: '" << rootIndex << "' at depth: " << nDepth);
				//TRACE_INFO("Calculating:  Hex" << nClass << " Geo" << nType << " Depth" << nDepth);

				// create new connectivity arrays
				boost::intrusive_ptr<vtkCellArray> spTriCellArray(vtkCellArray::New(), false);
				boost::intrusive_ptr<vtkCellArray> spHexCellArray(vtkCellArray::New(), false);

				generateGrid(	spTriCellArray,
								spHexCellArray,
								rootIndex,
								nMeshCellVertexRes	);

				// place the connectivity arrays in static vectors
				m_vecTriIds[nClass][nType][nDepth] = spTriCellArray;
				m_vecHexIds[nClass][nType][nDepth] = spHexCellArray;				

				// compute texture widths
				// place holder for TRI[0]
				m_vecTextureWidths[nClass][nType][nDepth].push_back(0);		
				m_vecTextureWidths[nClass][nType][nDepth][0] = 0;
				
				for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
				{
					//TRACE_INFO("TW: " << nTRI);
					m_vecTextureWidths[nClass][nType][nDepth].push_back(0);
					int nTextureWidth = generateTextureWidths(	rootIndex,
																nMeshCellVertexRes,
																nTRI);
					m_vecTextureWidths[nClass][nType][nDepth][nTRI] = nTextureWidth;
				}

				// create new Texture-coordinates array
				// place holder for TRI[0]
				m_vecTextureCoords[nClass][nType][nDepth].push_back(TextureCoordList());
				m_vecTextureCoords[nClass][nType][nDepth][0] = 0;

				for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
				{
					//TRACE_INFO("TC: " << nTRI);
					m_vecTextureCoords[nClass][nType][nDepth].push_back(TextureCoordList());

					boost::intrusive_ptr<vtkDoubleArray> spTextureCoordArray(vtkDoubleArray::New(), false);
					spTextureCoordArray->SetNumberOfComponents(2);
					spTextureCoordArray->CreateDefaultLookupTable();

					// calculate number of mesh cell vertices in tile
					int nMeshCellVertexCount = PYXIcosMath::getCellCount(rootIndex, nMeshCellVertexRes);
					if (!PYXIcosMath::isDataContained(rootIndex, nDepth))
					{
						nMeshCellVertexCount += PYXEdgeIterator::calcCellCount(rootIndex, nMeshCellVertexRes);
					}
					spTextureCoordArray->SetNumberOfTuples(nMeshCellVertexCount);
					
					generateTextureCoords(	spTextureCoordArray,
											rootIndex,
											nMeshCellVertexRes,
											m_vecTextureWidths[nClass][nType][nDepth][nTRI],
											nTRI);
					m_vecTextureCoords[nClass][nType][nDepth][nTRI] = spTextureCoordArray;
				}

				// create new texel offsets list
				// place holder for TRI[0]
				m_vecTexelOffsets[nClass][nType][nDepth].push_back(TexelOffsetList());
				m_vecTexelOffsets[nClass][nType][nDepth][0].push_back(0);

				for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
				{
					//TRACE_INFO("TO: " << nTRI);
					m_vecTexelOffsets[nClass][nType][nDepth].push_back(TexelOffsetList());

					generateTexelOffsets(	m_vecTexelOffsets[nClass][nType][nDepth][nTRI],
											rootIndex,
											nMeshCellVertexRes,
											m_vecTextureWidths[nClass][nType][nDepth][nTRI],
											nTRI);
				}
			}
		}
	}
	TRACE_TIME("Connectivity generation complete.");

	// write the connectivity charts out to file
	writeToFile();
}

/*! 
Free the static data that was created at startup.  iterators are used here
so that malformed arrays (read in from files) can still be deleted.
*/
void PYXDisplayTileInfo::freeStaticData()
{
	TRACE_INFO("Cleaning up visualization connectivity arrays.");
	m_vecTriIds.clear();
	m_vecHexIds.clear();
	m_vecTextureWidths.clear();
	m_vecTextureCoords.clear();
	m_vecTexelOffsets.clear();
}

/*!
Create the array of vtk cells that represents a tile with a specific root
at a particular depth.  A particular grid may or may not require knitting
into adjacent tiles.

\param spTriCellArray	The array to be appended with triangular connectivity.
\param spHexCellArray	The array to be appended with hexagonal connectivity.
\param rootIndex		The root index of the tile.
\param nDataRes			The absolute resolution of the data.
*/
void PYXDisplayTileInfo::generateGrid(	boost::intrusive_ptr<vtkCellArray> spTriCellArray,
										boost::intrusive_ptr<vtkCellArray> spHexCellArray,
										const PYXIcosIndex& rootIndex,
										int nDataRes	)
{
	// place holder for all vertex points
	vtkIdType pnVertex[6];
	PYXVertexIterator itVertex(rootIndex);
	int nVertexCounter;

	// create an edge iterator if necessary
	PYXPointer<PYXEdgeIterator> spItEdge;
	int nItEdgeOffset = 0;
	if (!PYXIcosMath::isDataContained(	rootIndex, 
										nDataRes - rootIndex.getResolution())	)
	{
		nItEdgeOffset = PYXIcosMath::getCellCount(rootIndex, nDataRes);
		spItEdge = PYXEdgeIterator::create(rootIndex, nDataRes);
	}

	// cycle over every point at the data resolution
	PYXExhaustiveIterator rootIterator(rootIndex, nDataRes);
	for (; !rootIterator.end(); rootIterator.next())
	{
		// get the next index value
		const PYXIcosIndex& pyxIndex = rootIterator.getIndex();

		if (pyxIndex.hasVertexChildren())
		{
			// only need parent because we are gridding at res - 1
			itVertex.reset(PYXIcosMath::getParent(pyxIndex));

			// create the offset array for the hexagon/pentagon
			nVertexCounter = 0;
			for (; !itVertex.end(); itVertex.next())
			{
				const PYXIcosIndex& childIndex = itVertex.getIndex();
			
				if (!rootIndex.isAncestorOf(childIndex))
				{
					// get the offset of the knitted index
					assert(spItEdge.get() != 0);
					if (!spItEdge->setIteratorIndex(childIndex))
					{
						// the index is not a decendant and not a neighbour
						assert(false);
					}
					pnVertex[nVertexCounter] =	spItEdge->calcCurrentOffset() +
												nItEdgeOffset;
				}
				else
				{
					// get the offset of the standard contained index
					pnVertex[nVertexCounter] = 
						PYXIcosMath::calcCellPosition(	rootIndex, 
														childIndex	);
				}
				++nVertexCounter;
			}

			// insert the hexagon cell into the hex array
			spHexCellArray->InsertNextCell(nVertexCounter, pnVertex);
			
			// Create 2 triangle strips to render hexes in the tri array
			int nOriginOffset = PYXIcosMath::calcCellPosition(	
										rootIndex, 
										itVertex.getCentroidChild()	);

	/*
	Developer Note on Triangle Strips:
	Definition: "The connectivity of a triangle strip is three points defining
	an initial triangle, then for each additional triangle, a single point 
	that, combined with the previous two points, defines the next triangle"

	The ordering of the points in this triangle strip implementation goes
	against the definition and yet draws correctly for some unknown reason.
	*/
			// Create a strip for the first half of the hexagon (3 triangles)
			int nPointCount;
			nPointCount = (nVertexCounter != Hexagon::knNumSides ? 4 : 5);
			vtkTriangleStrip* pStrip = vtkTriangleStrip::New();
			pStrip->GetPointIds()->SetNumberOfIds(5);
			pStrip->GetPointIds()->SetId(0, nOriginOffset);
			pStrip->GetPointIds()->SetId(1, pnVertex[2]);
			pStrip->GetPointIds()->SetId(2, pnVertex[1]);
			pStrip->GetPointIds()->SetId(3, pnVertex[0]);
			pStrip->GetPointIds()->SetId(4, pnVertex[nPointCount]);
			spTriCellArray->InsertNextCell(pStrip);
			pStrip->Delete();

			// 2 triangles (4 points) for a pentagon and 3 (5 points for a hex)
			pStrip = vtkTriangleStrip::New();
			pStrip->GetPointIds()->SetNumberOfIds(nPointCount);
			pStrip->GetPointIds()->SetId(0, nOriginOffset);
			int nIDOffset = 1;
			int nVertexOffset = nVertexCounter;
			while (nIDOffset < nPointCount)
			{
				pStrip->GetPointIds()->SetId(	nIDOffset++, 
												pnVertex[--nVertexOffset]	);
			}
			spTriCellArray->InsertNextCell(pStrip);
			pStrip->Delete();
		}
	}

	// remove any excess array entries
	spTriCellArray->Squeeze();
	spHexCellArray->Squeeze();
}

/*! 
Read the connectivity charts in from a file.

\return true if the charts were sucessfully initialized.
*/
bool PYXDisplayTileInfo::readFromFile()
{
	boost::filesystem::path filePath(kstrConnectivityFile, boost::filesystem::native);
	if (!boost::filesystem::exists(filePath))
	{
		TRACE_INFO("Connectivity file '" << kstrConnectivityFile << "' does not exist.");
	}
	else
	{
		TRACE_TIME(	"Beginning tile connectivity read from file '" <<
					kstrConnectivityFile << "'."	);
		try
		{
			// determine a cell count for a typical tile
			PYXIcosIndex sampleIndex("A-0");
			PYXTile sampleTile(	sampleIndex, 
								sampleIndex.getResolution() +
								knMaxDisplayTileDepth	);
			int nMaxValueCount =	
				PYXIcosMath::getCellCount(	sampleTile.getRootIndex(), 
											sampleTile.getCellResolution() ) * 
				Hexagon::knNumSides;

			// open the file
			std::ifstream in(kstrConnectivityFile.c_str(), std::ios_base::binary);				

			// verify the version number of Connectivity.bin
			int nVersion = readIntegerValue(in);

			if(nVersion != knConnectivityBinVersion)
			{
				TRACE_INFO("Incompatible version of '" << kstrConnectivityFile << "' available. Re-creating file...");
				return false;
			}

			// for each class
			for (int nClass = PYXMath::knClassI; nClass <= PYXMath::knClassII; ++nClass)
			{
				// push a new double array onto the triple array
				m_vecTriIds.push_back(IdArrayDoubleVector());
				m_vecHexIds.push_back(IdArrayDoubleVector());
				m_vecTextureWidths.push_back(TextureWidthTable3());
				m_vecTextureCoords.push_back(TextureCoordTable3());
				m_vecTexelOffsets.push_back(TexelOffsetTable3());

				// for each type
				for (int nType = knStandard; nType <= knPole12; ++nType)
				{
					// assign the second dimension arrays
					m_vecTriIds[nClass].push_back(IdArrayVector());
					m_vecHexIds[nClass].push_back(IdArrayVector());
					m_vecTextureWidths[nClass].push_back(TextureWidthTable2());
					m_vecTextureCoords[nClass].push_back(TextureCoordTable2());
					m_vecTexelOffsets[nClass].push_back(TexelOffsetTable2());

					// for each depth
					for (int nDepth = 0; nDepth <= knMaxDisplayTileDepth; ++nDepth)
					{
						// put a placeholder in the arrays
						m_vecTriIds[nClass][nType].push_back(0);
						m_vecHexIds[nClass][nType].push_back(0);
						m_vecTextureWidths[nClass][nType].push_back(TextureWidthTable1());
						m_vecTextureCoords[nClass][nType].push_back(TextureCoordTable1());
						m_vecTexelOffsets[nClass][nType].push_back(TexelOffsetTable1());

						if (nDepth < knMinDisplayTileDepth)
						{
							// just a place holder, continue
							continue;
						}						
						
						// Verify the check value
						char pnCheck[20];
						readStringValue(in, pnCheck);
						if(strcmp(pnCheck, strTriId.c_str()))
						{
							TRACE_INFO("Error reading in data from '" << kstrConnectivityFile
								<< "' (Tri Id check failed). Recreating file...");
							return false;
						}

						// read in the count in this array
						vtkIdType nSize = readIntegerValue(in);

						// validate the size
						if (nMaxValueCount < nSize)
						{
							// the file is not valid.
							break;
						}

						if (nSize == 0)
						{
							m_vecTriIds[nClass][nType][nDepth] = 0;
						}
						else
						{			
							m_vecTriIds[nClass][nType][nDepth] = 
								boost::intrusive_ptr<vtkCellArray>(vtkCellArray::New(), false);

							for (; 0 < nSize; --nSize)
							{
								m_vecTriIds[nClass][nType][nDepth]->GetData()->InsertNextValue(
									readIntegerValue(in)	);
							}

							// read in the cell count for this array
							m_vecTriIds[nClass][nType][nDepth]->SetNumberOfCells(
								readIntegerValue(in)	);

							m_vecTriIds[nClass][nType][nDepth]->Squeeze();
						}

						// Verify the check value
						readStringValue(in, pnCheck);
						if(strcmp(pnCheck, strHexId.c_str()))
						{
							TRACE_INFO("Error reading in data from '" << kstrConnectivityFile
								<< "' (Hex Id check failed). Recreating file...");
							return false;
						}

						// read in the count of the hex id array
						nSize = 0;
						in.read(reinterpret_cast<char*>(&nSize), sizeof(vtkIdType));
						
						if (nSize == 0)
						{
							m_vecHexIds[nClass][nType][nDepth] = 0;
						}
						else
						{
							m_vecHexIds[nClass][nType][nDepth] = 
								boost::intrusive_ptr<vtkCellArray>(vtkCellArray::New(), false);
							for (; 0 < nSize; --nSize)
							{
								m_vecHexIds[nClass][nType][nDepth]->GetData()->InsertNextValue(
									readIntegerValue(in)	);
							}

							// read in the cell count
							m_vecHexIds[nClass][nType][nDepth]->SetNumberOfCells(
								readIntegerValue(in)	);

							// remove excess allocations
							m_vecHexIds[nClass][nType][nDepth]->Squeeze();
						}

						// read in the texture width values from file
						// place holder for TRI[0]
						m_vecTextureWidths[nClass][nType][nDepth].push_back(0);
						m_vecTextureWidths[nClass][nType][nDepth][0] = 0;
						
						for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
						{
							m_vecTextureWidths[nClass][nType][nDepth].push_back(0);

							// Verify the check value
							char pnCheck[20];
							readStringValue(in, pnCheck);
							if(strcmp(pnCheck, strTextureWidth.c_str()))
							{
								TRACE_INFO("Error reading in data from '" << kstrConnectivityFile
									<< "' (Texture width check failed). Recreating file...");
								return false;
							}
							
							int nTextureWidth = readIntegerValue(in);
							m_vecTextureWidths[nClass][nType][nDepth][nTRI] = nTextureWidth;
						}

						// read in Texture Coordinates
						// place holder for TRI[0]
						m_vecTextureCoords[nClass][nType][nDepth].push_back(TextureCoordList());
						m_vecTextureCoords[nClass][nType][nDepth][0] = 0;
						
						for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
						{
							// Verify the check value
							char pnCheck[20];
							readStringValue(in, pnCheck);
							if(strcmp(pnCheck, strTextureCoordinates.c_str()))
							{
								TRACE_INFO("Error reading in data from '" << kstrConnectivityFile
									<< "' (Texture Coordinates check failed). Recreating file...");
								return false;
							}
							
							nSize = 0; // This is # of tuples: (actual elements * 2)
							in.read(reinterpret_cast<char*>(&nSize), sizeof(vtkIdType));								

							m_vecTextureCoords[nClass][nType][nDepth].push_back(TextureCoordList());

							if (nSize == 0)
							{
								m_vecTextureCoords[nClass][nType][nDepth][nTRI] = 0;
							}
							else
							{
								m_vecTextureCoords[nClass][nType][nDepth][nTRI] =
									boost::intrusive_ptr<vtkDoubleArray>(vtkDoubleArray::New(), false);
								m_vecTextureCoords[nClass][nType][nDepth][nTRI]->SetNumberOfComponents(2);
								m_vecTextureCoords[nClass][nType][nDepth][nTRI]->CreateDefaultLookupTable();
								m_vecTextureCoords[nClass][nType][nDepth][nTRI]->SetNumberOfTuples(nSize);

								for(int nIndex=0 ; nIndex<nSize ; nIndex++)
								{
									double xCoord = (double)readDoubleValue(in);
									double yCoord = (double)readDoubleValue(in);										
									m_vecTextureCoords[nClass][nType][nDepth][nTRI]->SetTuple2(nIndex, xCoord, yCoord);
								}
							}
						}

						// read in texel offsets
						// place holder for TRI[0]
						m_vecTexelOffsets[nClass][nType][nDepth].push_back(TexelOffsetList());
						m_vecTexelOffsets[nClass][nType][nDepth][0].push_back(0);
						
						for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
						{
							// Verify the check value
							char pnCheck[20];
							readStringValue(in, pnCheck);
							if(strcmp(pnCheck, strTexelOffsets.c_str()))
							{
								TRACE_INFO("Error reading in data from '" << kstrConnectivityFile
									<< "' (Texel offsets check failed). Recreating file...");
								return false;
							}

							nSize = 0;
							in.read(reinterpret_cast<char*>(&nSize), sizeof(vtkIdType));								

							m_vecTexelOffsets[nClass][nType][nDepth].push_back(TexelOffsetList());

							if (nSize == 0)
							{
								m_vecTexelOffsets[nClass][nType][nDepth][nTRI].push_back(0);
							}
							else
							{
								for(int nIndex=0 ; nIndex<nSize ; nIndex++)
								{
									int value = readIntegerValue(in);
									m_vecTexelOffsets[nClass][nType][nDepth][nTRI].push_back(value);
								}
							}
						}
					}
				}
			}
			in.close();
			return true;

		}
		catch (...)
		{
			// a file error probably occurred, fall through and return false
			TRACE_ERROR("An error occurred reading the connectivity tables.");
			return false;
		}
	}

	// the file does not exist or an error occurred.
	freeStaticData();
	TRACE_INFO("Could not load connectivity table from file. Recreating File...");
	return false;
}

/*!
Write the connectivity charts out to file.
*/
void PYXDisplayTileInfo::writeToFile()
{
	// remove any malformed connectivity files
	remove(kstrConnectivityFile.c_str());

	TRACE_TIME(	"Starting to write connectivity arrays to file '" <<
				kstrConnectivityFile << "'."	);

	try
	{
		// create the new writable file
		std::ofstream out(kstrConnectivityFile.c_str(), std::ios_base::binary);

		// write out the current connectivity.bin version number as a header
		writeIntegerValue(out, knConnectivityBinVersion);

		// for each class
		for (int nClass = PYXMath::knClassI; nClass <= PYXMath::knClassII; ++nClass)
		{
			// for each type
			for (int nType = knStandard; nType <= knPole12; ++nType)
			{
				// for each depth
				for (int nDepth = 0; nDepth <= knMaxDisplayTileDepth; ++nDepth)
				{
					// Don't process an invalid depth
					if (nDepth < knMinDisplayTileDepth)
					{
						// just a place holder, continue
						continue;
					}
					
					// write header
					char pnCheck[20];
					strcpy(pnCheck, strTriId.c_str());
					writeStringValue(out, pnCheck);

					// write out the count of the tri id array
					vtkIdTypeArray* pArray = 0;
					if (m_vecTriIds[nClass][nType][nDepth] == 0)
					{
						writeIntegerValue(out, 0);
					}
					else
					{
						pArray = m_vecTriIds[nClass][nType][nDepth]->GetData();
						assert(pArray != 0);

						// write out the size of the array
						writeIntegerValue(out, pArray->GetSize());

						// write out each array value
						for (vtkIdType nOffset = 0; nOffset < pArray->GetSize(); ++nOffset)
						{
							writeIntegerValue(out, pArray->GetValue(nOffset));
						}

						// write out the cell count
						writeIntegerValue(	out, 
									m_vecTriIds[nClass][nType][nDepth]->GetNumberOfCells()	);
					}


					// write header					
					strcpy(pnCheck, strHexId.c_str());
					writeStringValue(out, pnCheck);

					// write out the count of the hex id array
					if (m_vecHexIds[nClass][nType][nDepth] == 0)
					{
						writeIntegerValue(out, 0);
  					}
					else
					{
						pArray = m_vecHexIds[nClass][nType][nDepth]->GetData();
						assert(pArray != 0);

						// write out the size of the array
						writeIntegerValue(out, pArray->GetSize());

						// write out each array value
						for (	vtkIdType nOffset = 0; 
								nOffset < pArray->GetSize(); 
								++nOffset	)
						{
							writeIntegerValue(out, pArray->GetValue(nOffset));
						}

						// write out the cell count
						writeIntegerValue(	out, 
									m_vecHexIds[nClass][nType][nDepth]->GetNumberOfCells()	);
					}

					// Write out the Texture Widths
					for(int nTRI = knMinTextureResIncrement ; nTRI <= knMaxTextureResIncrement ; nTRI++)
					{
						// write header
						char pnCheck[20];
						strcpy(pnCheck, strTextureWidth.c_str());
						writeStringValue(out, pnCheck);

						// write texture width
						writeIntegerValue(out, m_vecTextureWidths[nClass][nType][nDepth][nTRI]);
					}
					
					// Write out Texture Coordinates
					for(int nTRI = knMinTextureResIncrement; nTRI <= knMaxTextureResIncrement; nTRI++)
					{
						//write header
						char pnCheck[20];
						strcpy(pnCheck, strTextureCoordinates.c_str());
						writeStringValue(out, pnCheck);

						// write texture coords
						if (m_vecTextureCoords[nClass][nType][nDepth][nTRI]->GetNumberOfTuples() == 0)
						{
							writeIntegerValue(out, 0);
						}
						else
						{
							// write out the size of the vector of tuples
							writeIntegerValue(out, m_vecTextureCoords[nClass][nType][nDepth][nTRI]->GetNumberOfTuples());

							// write out each array value
							for (	vtkIdType nOffset = 0; 
									nOffset < m_vecTextureCoords[nClass][nType][nDepth][nTRI]->GetNumberOfTuples(); 
									++nOffset	)
							{
								double* pTuple;
								pTuple = m_vecTextureCoords[nClass][nType][nDepth][nTRI]->GetTuple2(nOffset);
								writeDoubleValue(out, *pTuple);
								pTuple++;
								writeDoubleValue(out, *pTuple);
							}
						}
					}

					// Write out Texel Offsets
					for(int nTRI = knMinTextureResIncrement; nTRI <= knMaxTextureResIncrement; nTRI++)
					{
						// write header
						char pnCheck[20];
						strcpy(pnCheck, strTexelOffsets.c_str());
						writeStringValue(out, pnCheck);

						// write texel offsets
						if (static_cast<signed int>(m_vecTexelOffsets[nClass][nType][nDepth][nTRI].size()) == 0)
						{
							writeIntegerValue(out, 0);
						}
						else
						{
							std::vector <int> vecTexelOffsets = m_vecTexelOffsets[nClass][nType][nDepth][nTRI];

							// write out the size of the vector
							writeIntegerValue(out, static_cast<signed int>(m_vecTexelOffsets[nClass][nType][nDepth][nTRI].size()));

							// write out each array value
							for (	vtkIdType nOffset = 0; 
									nOffset < static_cast<signed int>(vecTexelOffsets.size());
									++nOffset	)
							{
								writeIntegerValue(out, vecTexelOffsets[nOffset]);								
							}
						}
					}					
				}
			}
		}
		out.close();
		TRACE_TIME("Finished Writing File.");
	}
	catch(...)
	{
		TRACE_ERROR("Error occurred writing connectivity file to disk.");
	}
}

/*!
Given a tile, find its indices into the 3-dimensional structure. Used
to get TCoords and TOffsets

\param	tile			The tile we are finding the indices for.
\param	pnHexClass		The class of hexagon for the tile.
\param	pnGeometryType	The Geometry type of the tile.
\param  pnDepth			The depth of the tile.
*/
void PYXDisplayTileInfo::computeArrayIndices (
									const PYXTile& tile,
									PYXMath::eHexClass* pnHexClass,
									eTileGeometryType* pnGeometryType,
									int* pnDepth	)
{
	// determine the the hex class
	*pnHexClass = PYXMath::getHexClass(
								tile.getRootIndex().getResolution()	);

	// determine the geometry type of the hexagon
	if (tile.getRootIndex().isPentagon())
	{
		// set the type based on the missing direction
		PYXMath::eHexDirection nDirection;
		PYXIcosMath::getCellGap(tile.getRootIndex(), &nDirection);

		// verify the constant has not changed.
		assert(	nDirection == PYXMath::knDirectionOne ||
				nDirection == PYXMath::knDirectionFour	);

		if (nDirection == PYXMath::knDirectionOne)
		{
			*pnGeometryType = knPole1;
		}
		else
		{
			*pnGeometryType = knPole12;
		}
	}
	else
	{
		*pnGeometryType = knStandard;
	}

	// get tile depth
	*pnDepth = tile.getDepth();
}


/*!
Return an appropriate connectivity array for the passed parameters.  In the case
of a eTileDisplayType::knTestTile a 0 is returned.  The method throws a 
PYXVisualizationException if the connectivity array can not be found.

\param nType	The type of hexagon grid to return (hexagon, triangulated...)
\param tile		The geometry of the connectivity array.

\return An intrusive pointer to the connectivity array for the requested tile.
*/
boost::intrusive_ptr<vtkCellArray> PYXDisplayTileInfo::getConnectivity(
													eGridType nType, 
													const PYXTile& tile	)
{
	PYXMath::eHexClass nHexClass;
	eTileGeometryType nGeometryType;
	int nDepth;
	computeArrayIndices(tile, &nHexClass, &nGeometryType, &nDepth);

	// validate the tile depth
	if (nDepth < knMinDisplayTileDepth || knMaxDisplayTileDepth < nDepth)
	{
		PYXTHROW(	PYXVisualizationException,
					"Invalid tile depth of '" << nDepth << 
					"'. No tile connectivity data available."	);
	}

	// extract and return the connectivity array
	if (nType == knHexagonalTile)
	{
		return m_vecHexIds[nHexClass][nGeometryType][nDepth];
	}
	else if (nType == knTriangularTile)
	{
		return m_vecTriIds[nHexClass][nGeometryType][nDepth];
	}

	PYXTHROW(	PYXVisualizationException, "Invalid connectivity type '" << 
				nType << "'."	);
}



/*!
Write a single id value out to an open stream.

\param out		The file writing stream. Must be open for binary write before calling.
\param nID		The value to write to the file.
*/
void PYXDisplayTileInfo::writeIntegerValue(std::ofstream& out, vtkIdType nID)
{
	out.write(	reinterpret_cast<const char*>(&nID), 
				sizeof(vtkIdType)	);
}

/*!
Write a single double value to an open stream.

\param out		The file writing stream. Must be open for binary write before calling.
\param nID		The value to write to the file.
*/
void PYXDisplayTileInfo::writeDoubleValue(std::ofstream& out, double fID)
{
	out.write(	reinterpret_cast<const char*>(&fID),
				sizeof(double)		);
}

/*!
Write a character array of size twenty to an open stream.

\param out		The file writing stream. Must be open for binary write before calling.
\param cID		The character array we are writing to file.
*/
void PYXDisplayTileInfo::writeStringValue(std::ofstream& out, char pnID[])
{
	// write out each char at a time.
	int nCharsWritten = 0;
	for(int nCount = 0;
		nCount < 20;
		nCount++)
	{
		out.write(	reinterpret_cast<const char*>(&pnID[nCount]),
					sizeof(pnID[nCount]));
	}
}

/*!
Read a single id value from an open stream.

\param in		The file reading stream. Must be open for binary read before calling.

return the value that is read from the stream.
*/
vtkIdType PYXDisplayTileInfo::readIntegerValue(std::ifstream& in)
{
	vtkIdType nID;
	in.read(reinterpret_cast<char*>(&nID), sizeof(vtkIdType));
	return nID;
}

/*!
Read a single double value from an open stream.

\param in		The file reading stream. Must be open for binary read before calling.

return the value that is read from the stream.
*/
double PYXDisplayTileInfo::readDoubleValue(std::ifstream& in)
{
	double fID;
	in.read(reinterpret_cast<char*>(&fID), sizeof(double));
	return fID;
}

/*!
Read a character array of size twenty from an open stream.

\param in		The file reading stream. Must be open for binary read before calling.
\param cCheck	The character array the string is read into.
*/
void PYXDisplayTileInfo::readStringValue(std::ifstream& in, char pnCheck[])
{
	for(int nCount = 0;
		nCount < 20;
		nCount++)
	{
		in.read(reinterpret_cast<char*>(&pnCheck[nCount]), sizeof(pnCheck[nCount]));
	}
}

/*!
Calculate the TextureWidth used in sizing the actual texture image.

\param rootIndex	The root index of the tile.
\param nDataRes		The data resolution of the tile.
\param nTRI			The texture resolution increment.
*/

int PYXDisplayTileInfo::generateTextureWidths (	const PYXIcosIndex& rootIndex,
												int nDataRes,
												int nTRI	)
{
	PYXTile meshTile(rootIndex, nDataRes);
	
	/*
	The (-1) is so that the TRI is relative to mesh
	cell resolution
	*/	
	PYXTile texTile(rootIndex, nDataRes + nTRI - 1);

	int nMaxMove2 = 0;
	int nMaxMove6 = 0;

	for (	PYXPointer<PYXIterator> spIt(texTile.getIterator());
			!spIt->end();
			spIt->next()	)
	{
		int nMove2, nMove6;
		nMove2 = nMove6 = 0;
		PYXMath::factor(spIt->getIndex().getSubIndex(), &nMove2, &nMove6);

		// Track the largest move value
		if (nMove2 > nMaxMove2) nMaxMove2 = nMove2;
		if (nMove6 > nMaxMove6) nMaxMove6 = nMove6;
	}

	int nWidth = std::max(nMaxMove2, nMaxMove6);

	// Moves to both sides, from centre
	nWidth *= 2;

	// Add one for center cell
	nWidth++;

	// move to nearest power of 2 size
	int nPowerTwoSize = 1;

	while (nPowerTwoSize < nWidth)
	{
		nPowerTwoSize *= 2;
	}

	return nPowerTwoSize;
}

/*!
Generate the texture coordinates for the tile being processed.

\param spTCoordsArray	The data structure which holds the texture coordinates (stored in Iterator order).
\param rootIndex		The root index of the tile.
\param nDataRes			The data resolution of the tile.
\param nTextureWidth	The TexelCoordinateBasis of the Tile. We only need Width (we could refactor out the whole structure)
\param nTRI				The texture resolution increment.
*/
void PYXDisplayTileInfo::generateTextureCoords(	boost::intrusive_ptr<vtkDoubleArray> spTCoordsArray,
												const PYXIcosIndex& rootIndex,
												int nDataRes,
												int nTextureWidth,
												int nTRI	)
{
	PYXTile meshTile(rootIndex, nDataRes); //(data res is really mesh + 1)

	if(!rootIndex.isPentagon())
	{
		int nOffset = 0;
		for (	PYXPointer<PYXIterator> spIt(meshTile.getIterator());
				!spIt->end();
				spIt->next()	)
		{
			PYXIcosIndex index = spIt->getIndex();
			/*
			The (-1) is so that the TRI is relative to mesh
			cell resolution
			*/
			index.setResolution(nDataRes + nTRI - 1);
			int nMove2, nMove6;
			nMove2 = nMove6 = 0;
			PYXMath::factor(index.getSubIndex(), &nMove2, &nMove6);
			double ftx = (static_cast<double>(nMove6 + nTextureWidth / 2) + 0.5) / nTextureWidth;
			double fty = (static_cast<double>(nMove2 + nTextureWidth / 2) + 0.5) / nTextureWidth;			
			spTCoordsArray->SetTuple2( nOffset, ftx, fty);
			++nOffset;			
		}

		if (!PYXIcosMath::isDataContained(rootIndex, meshTile.getDepth()))
		{
			PYXEdgeIterator itEdge(rootIndex, nDataRes);
			for (; !itEdge.end(); ++itEdge)
			{
				PYXIcosIndex index = itEdge.getIndex();
				index.setResolution(nDataRes + nTRI - 1);
				int nMove2, nMove6;
				nMove2 = nMove6 = 0;
				PYXMath::factor(index.getSubIndex(), &nMove2, &nMove6);
				double ftx = (static_cast<double>(nMove6 + nTextureWidth / 2) + 0.5) / nTextureWidth;
				double fty = (static_cast<double>(nMove2 + nTextureWidth / 2) + 0.5) / nTextureWidth;
				spTCoordsArray->SetTuple2( nOffset, ftx, fty);
				++nOffset;
			}
		}
	}

	// Tile is Pentagonal; special processing:
	else
	{
		int nIterationResolution = meshTile.getCellResolution() + nTRI - 1;
		PYXSpiralIterator itSpiral(rootIndex, nIterationResolution - rootIndex.getResolution(), nTextureWidth / 3);

		// Make a lookup Map which contains cell-2offset-6offset
		std::map < PYXIcosIndex, std::pair<int, int> > mapCoords;
		for(; !itSpiral.end(); ++itSpiral)
		{
			mapCoords[itSpiral.getIndex()] = std::make_pair(itSpiral.getTwoDirectionFactor(), itSpiral.getSixDirectionFactor());
		}

		// Use the above Map to populate the array of texture coordinates, preserving proper Iterator sequence
		int nOffset = 0;
		for (	PYXPointer<PYXIterator> spIt(meshTile.getIterator());
				!spIt->end();
				spIt->next()	)
		{
			PYXIcosIndex index = spIt->getIndex();
			index.setResolution(nDataRes + nTRI - 1);

			double ftx = -1;
			double fty = -1;

			// Get the offsets for our current index
			assert( mapCoords.find(index) != mapCoords.end() );
			ftx = (static_cast<double>(mapCoords[index].second + nTextureWidth / 2) + 0.5) / nTextureWidth;
			fty = (static_cast<double>(mapCoords[index].first + nTextureWidth / 2) + 0.5) / nTextureWidth;

			spTCoordsArray->SetTuple2( nOffset, ftx, fty);
			++nOffset;			
		}

		// Perform edge iteration if tile is uncontained (at mesh resolution)
		if (!PYXIcosMath::isDataContained(rootIndex, meshTile.getDepth()))
		{
			PYXEdgeIterator itEdge(rootIndex, nDataRes);
			for (; !itEdge.end(); ++itEdge)
			{
				PYXIcosIndex index = itEdge.getIndex();
				index.setResolution(nDataRes + nTRI - 1);

				double ftx = -1;
				double fty = -1;
				
				// Get the offsets for our current index
				if( mapCoords.find(index) != mapCoords.end() )
				{
					ftx = (static_cast<double>(mapCoords[index].second + nTextureWidth / 2) + 0.5) / nTextureWidth;
					fty = (static_cast<double>(mapCoords[index].first + nTextureWidth / 2) + 0.5) / nTextureWidth;
				}
				
				spTCoordsArray->SetTuple2( nOffset, ftx, fty);
				++nOffset; 
			}
		}
	}
}

/*!
Generate the offsets for each texel(pixel) in a tile's texture image.

\param vecOffsets		A vector of the offets for each texel (in Iterator order).
\param rootIndex		The root index of the tile.
\param nDataRes			The data resolution of the tile.
\param nTextureWidth	The texture width.
\param nTRI				The texture resolution increment.
*/
void PYXDisplayTileInfo::generateTexelOffsets(	std::vector<int>& vecOffsets,
												const PYXIcosIndex& rootIndex,
												int nDataRes,
												int nTextureWidth,
												int nTRI	)
{	
	PYXTile meshTile(rootIndex, nDataRes);
	/*
	The (-1) is so that the TRI is relative to mesh
	cell resolution
	*/	
	PYXTile texTile(rootIndex, nDataRes + nTRI - 1);

	int nIterationResolution = meshTile.getCellResolution() + nTRI - 1;

	if(!rootIndex.isPentagon())
	{
		// Calculate Factoring Offset: ensures tile is centered in texture image.
		PYXIcosIndex factoringCenterCellIndex = meshTile.getRootIndex();
		factoringCenterCellIndex.setResolution(nIterationResolution);
		int nFactor2Offset, nFactor6Offset;
		nFactor2Offset = nFactor6Offset = 0;
		PYXMath::factor(factoringCenterCellIndex.getSubIndex(), &nFactor2Offset, &nFactor6Offset);
		if((nFactor2Offset != 0) || (nFactor6Offset != 0))
		{
			nFactor2Offset = nFactor2Offset * -1;
			nFactor6Offset = nFactor6Offset * -1;
		}
		
		// Go to the mesh resolution for drawing
		meshTile.setCellResolution( meshTile.getCellResolution() - 1);

		int nCellOffset = 0;
		for (	PYXPointer<PYXIterator> spIt(meshTile.getIterator());
				!spIt->end();
				spIt->next()	)
		{
			// Get offset to mesh cell index, at texeling resolution
			int n2Offset, n6Offset;
			n2Offset = n6Offset = 0;
			PYXIcosIndex centerCellIndex;
			centerCellIndex = spIt->getIndex();
			centerCellIndex.setResolution(nIterationResolution);
			PYXMath::factor(centerCellIndex.getSubIndex(), &n2Offset, &n6Offset);
			n2Offset += nFactor2Offset;
			n6Offset += nFactor6Offset;

			// Start Spiral Iterating here:
			PYXSpiralIterator itSpiral(spIt->getIndex(), nTRI, knInterpolationCorrection ); //iterate 2 res' below mesh cell
			for (; !itSpiral.end(); ++itSpiral)
			{
				PYXIcosIndex index = itSpiral.getIndex();
				int n2Moves = n2Offset + itSpiral.getTwoDirectionFactor();
				int n6Moves = n6Offset + itSpiral.getSixDirectionFactor();				

				n2Moves += nTextureWidth / 2;
				n6Moves += nTextureWidth / 2;
				
				int nTexelOffset = 3 * ((n2Moves * nTextureWidth) + n6Moves);

				if (nTexelOffset >= nTextureWidth * nTextureWidth * 3 ||
					nTexelOffset < 0	)
				{
					vecOffsets.push_back(-1);
				}
				else
				{
					vecOffsets.push_back(nTexelOffset);
				}
			}	
		}
	}

	// Tile is Pentagonal: special processing.
	else
	{
		PYXSpiralIterator itSpiral(rootIndex, nIterationResolution - rootIndex.getResolution(), nTextureWidth / 3);
		std::map < PYXIcosIndex, std::pair<int, int> > mapOffsets;

		for(; !itSpiral.end(); ++itSpiral)
		{
			mapOffsets[itSpiral.getIndex()] = std::make_pair(itSpiral.getTwoDirectionFactor(), itSpiral.getSixDirectionFactor());
		}		
		
		// Go to the mesh resolution for drawing
		meshTile.setCellResolution( meshTile.getCellResolution() - 1);

		// Make the table of texel offsets in ExhaustiveIterator:SpiralIterator order
		int nCellOffset = 0;
		for (	PYXPointer<PYXIterator> spIt(meshTile.getIterator());
				!spIt->end();
				spIt->next()	)
		{				
			PYXSpiralIterator itSpiral(spIt->getIndex(), (nTRI), 1 ); //iterate 2 res' below mesh cell	
			for (; !itSpiral.end(); ++itSpiral)
			{				
				assert( mapOffsets.find(itSpiral.getIndex()) != mapOffsets.end() );
				int n2Moves = mapOffsets[itSpiral.getIndex()].first + nTextureWidth / 2;
				int n6Moves = mapOffsets[itSpiral.getIndex()].second + nTextureWidth / 2;
				int	nTexelOffset = 3 * ((n2Moves * nTextureWidth) + n6Moves);

				if (nTexelOffset >= nTextureWidth * nTextureWidth * 3 ||
					nTexelOffset < 0	)
				{
					vecOffsets.push_back(-1);
				}
				else
				{
					vecOffsets.push_back(nTexelOffset);
				}
			}
		}
	}
}

/*! Get the texture coordinates for a tile.

\param tile		The tile we are retrieving texture coordinates for.

\return	an intrusive pointer to the list of texture coordinates for the tile.
*/
boost::intrusive_ptr< vtkDoubleArray > PYXDisplayTileInfo::getTextureCoordList(const PYXTile& tile, int nTRI)
{
	PYXMath::eHexClass nHexClass;
	eTileGeometryType nGeometryType;
	int nDepth = tile.getDepth();
	computeArrayIndices(tile, &nHexClass, &nGeometryType, &nDepth);

	return m_vecTextureCoords[nHexClass][nGeometryType][nDepth][nTRI];
}

/*! Get the dimensions of a tile's texture image.

\param tile		The tile we are retreiving dimensions for.
\param pWidth	The pointer which holds the width retrieved.
\param pHeight	The pointer which holds the height retrieved.
*/
void PYXDisplayTileInfo::getTextureDimensions(	const PYXTile& tile,
												int* pWidth,
												int* pHeight,
												int nTRI	)
{
	PYXMath::eHexClass nHexClass;
	eTileGeometryType nGeometryType;
	int nDepth = tile.getDepth();
	
	computeArrayIndices(tile, &nHexClass, &nGeometryType, &nDepth);
	*pWidth = m_vecTextureWidths[nHexClass][nGeometryType][nDepth][nTRI];
	*pHeight = m_vecTextureWidths[nHexClass][nGeometryType][nDepth][nTRI];
}

/*! 
Get the texel offsets for the texture for the tile.

\param tile		The tile we are retrieving texel offsets for.
*/
const std::vector<int>& PYXDisplayTileInfo::getTexelOffsetList(const PYXTile& tile, int nTRI)
{
	PYXMath::eHexClass nHexClass;
	eTileGeometryType nGeometryType;
	int nDepth = tile.getDepth();
	computeArrayIndices(tile, &nHexClass, &nGeometryType, &nDepth);

	return m_vecTexelOffsets[nHexClass][nGeometryType][nDepth][nTRI];
}