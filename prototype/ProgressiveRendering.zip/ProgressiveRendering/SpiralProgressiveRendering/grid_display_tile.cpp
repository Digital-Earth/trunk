/******************************************************************************
pyx_grid_display_tile.cpp

begin		: 2005-02-21
copyright	: (C) 2005 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/

#define VISUALIZATION_MODEL_SOURCE
#include "grid_display_tile.h"

// local includes
#include "display_tile_info.h"
#include "exceptions.h"
#include "vtk_utils.h"

// vtk inlcudes
#include "vtkActor.h"
#include "vtkPolyData.h"
#include "vtkProperty.h"
#include "vtkCellArray.h"

// standard includes
#include <cassert>

// constants

//! The class name
const std::string PYXGridDisplayTile::kstrScope = "PYXGridDisplayTile";

//! Default ambient light characteristics
static const double kfDefaultAmbientGrid = 0.2;

//! Default ambient light characteristics
static const double kfDefaultDiffuseGrid = 0.3;

//! Default specular light characteristic
static const double kfDefaultSpecularGrid = 0.1;

/*!
Default constructor.
*/
PYXGridDisplayTile::PYXGridDisplayTile()
{
}

/*! 
Default destructor.
*/
PYXGridDisplayTile::~PYXGridDisplayTile()
{
}

/*! 
Initialize a grid tile with a new instance of a GridDisplayTileSpec.

\param pSpec	Pointer to a new instance of a specification that uniquely
				defines this tile.
*/
void PYXGridDisplayTile::initializeTile(DisplayTileSpec* pSpec)
{
	// verify and assign the spec
	m_spSpec.reset(pSpec);
	if (dynamic_cast<GridDisplayTileSpec*>(pSpec) == 0)
	{
		PYXTHROW(PYXDisplayTileException, "Spec is not a grid tile specification.");
	}

	// rely on the base class to do the parameter checking
	try
	{
		// call the base initialization method
		PYXDisplayTile::initializeTileGeometry(
			m_spSpec->getTile(), 
			m_spSpec->getProjection()	);
	}
	catch (PYXException& e)
	{
		PYXRETHROW(e, PYXDisplayTileException, "Unable to create grid display tile.");
	}

	// set the colour according to the data resolution
	setColour();

	// render the tile only as a wireframe grid
	getActor()->GetProperty()->SetRepresentationToWireframe();

	// set the lighting levels for the tile
	setLightProperties(	kfDefaultAmbientGrid,
						kfDefaultDiffuseGrid,
						kfDefaultSpecularGrid	);
}


void PYXGridDisplayTile::updateTile() {}


/*
Override of the connectivity assignment for the default tile. The connectivity
will follow the ordering of the pyxis iterator.
*/
void PYXGridDisplayTile::setGrid()
{
	boost::intrusive_ptr<vtkCellArray> spCells = 
		PYXDisplayTileInfo::getConnectivity(	PYXDisplayTileInfo::knHexagonalTile,
												getTile()	);
	m_spCells->SetCells(spCells->GetNumberOfCells(), spCells->GetData());
}

/*!
Set a new colour for the grid tile. The actor is marked as modified so that
the next time the screen is updated the actor is rendered.

\param rgb	The new colour for the tile.
*/
void PYXGridDisplayTile::setColour(const PYXRGB& rgb)
{
	getActor()->GetProperty()->SetColor(
		rgb.redAsDouble(),
		rgb.blueAsDouble(),
		rgb.greenAsDouble()	);
	getActor()->Modified();
}

/*!
Set the colour property on the tile according to the data resolution.  
*/
void PYXGridDisplayTile::setColour()
{
	// cycle through 8 pre-defined colours
	switch (getTile().getCellResolution() % 8)
	{
	case 0:
		// Red
		getActor()->GetProperty()->SetColor(1.0, 0.0, 0.0);
		break;

	case 1:
		// Green
		getActor()->GetProperty()->SetColor(0.0, 1.0, 0.0);
		break;

	case 2:
		//Blue
		getActor()->GetProperty()->SetColor(0.0, 0.0, 1.0);
		break;

	case 3:
		// Light Blue
		getActor()->GetProperty()->SetColor(0.0, 0.83, 0.83);
		break;

	case 4:
		// Purple
		getActor()->GetProperty()->SetColor(1.0, 0.0, 1.0);
		break;

	case 5:
		// Dark Red
		getActor()->GetProperty()->SetColor(0.49, 0.01, 0.01);
		break;

	case 6:
		// Teal
		getActor()->GetProperty()->SetColor(0.12, 0.36, 0.38);
		break;

	case 7:
		// Orange
		getActor()->GetProperty()->SetColor(0.85, 0.36, 0.15);
		break;

	default:
		assert(false);
		break;
	}
}

/*!
Determine if this grid display tile spec is equal to a display tile spec.

\param rhs	The generic display tile spec to test for equality against this one.

\return true if the specifications match.
*/
bool GridDisplayTileSpec::operator==(const DisplayTileSpec& rhs) const
{
	const GridDisplayTileSpec* pSpec = dynamic_cast<const GridDisplayTileSpec*>(&rhs);
	if (pSpec != 0)
	{
		return (getTile() == pSpec->getTile());
	}
	
	return false;
}