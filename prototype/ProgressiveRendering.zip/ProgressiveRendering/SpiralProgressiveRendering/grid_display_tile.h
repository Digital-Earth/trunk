#ifndef PYX_GRID_DISPLAY_TILE_H
#define PYX_GRID_DISPLAY_TILE_H
/******************************************************************************
pyx_grid_display_tile.h

begin		: 2005-02-21
copyright	: (C) 2005 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/
#include "visualization_model.h"

// local includes
#include "display_tile.h"

// vtk includes

// standard includes

// local forward declarations
class PYXTile;

/*!
The description that uniquely identifies a grid display tile.
*/
//! Collection of parameters used to define a unique grid tile
class VISUALIZATION_MODEL_DECL GridDisplayTileSpec : public DisplayTileSpec
{
public: 
	
	//! Default constructor
	GridDisplayTileSpec() {;}

	//! The default destructor
	~GridDisplayTileSpec() {;}

	//! Equality operator provided to allow ordering in containers.
	bool operator==(const DisplayTileSpec& spec) const;
};

/*!
Represents a single tile of a PYXIS grid rendered using VTK.  The colour of
the grid will be set automatically according to the data resolution being 
visualized.  The root index of a display tile must always be a centroid child
index.
*/
//! The VTK representation of an individual grid tile.
class VISUALIZATION_MODEL_DECL PYXGridDisplayTile	:	public PYXDisplayTile
{
public:

	// Constants
	static const std::string kstrScope;

	//! Creator.
	static PYXPointer<PYXGridDisplayTile> create()
	{
		return PYXNEW(PYXGridDisplayTile);
	}

	//! Constructor
	PYXGridDisplayTile();

	//! Default destructor.
	virtual ~PYXGridDisplayTile();

	//! Create a grid tile using the passed information.
	void initializeTile(DisplayTileSpec* pSpec);

	void updateTile();

	//! Return the name of the notification class.
	virtual std::string getNotifierDescription() const {return kstrScope;}

	//! Set a specific colour for the tile.
	void setColour(const PYXRGB& rgb);

protected:

	//! Define the connectivity for the tile.
	virtual void setGrid();

private:

	//! Set the colour of the grid according to the resolution.
	void setColour();
};

#endif	// PYX_GRID_DISPLAY_TILE_H
