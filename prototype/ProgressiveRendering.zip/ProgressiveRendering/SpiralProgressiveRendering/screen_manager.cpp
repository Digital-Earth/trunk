/******************************************************************************
pyx_screen_info.cpp

begin		: 2006-00-00
copyright	: (C) 2006 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/

#define VISUALIZATION_MODEL_SOURCE
#include "screen_manager.h"

// local includes
#include "data_display_tile.h"
#include "display_tile.h"
#include "display_tile_info.h"
#include "exceptions.h"
#include "grid_display_tile.h"
#include "vtk_utils.h"

// pyxlib includes
#include "pyxis/derm/index.h"
#include "pyxis/derm/snyder_projection.h"
#include "pyxis/derm/sub_index_math.h"

//! Default constructor.
ScreenManager::ScreenManager() :
	m_nDetailModifier(0),
	m_nTileDepth(PYXDisplayTileInfo::knDefaultDisplayTileDepth)
{
	
}

//! Default destructor.
ScreenManager::~ScreenManager()
{

}

/*!
Set the depth of visual tiles to be used on this screen. The depth of the tiles
must be between the minimum and maximum values stated in PYXDisplayTileInfo. This
call has no direct effect on the screen display. The information will be taken
into account the next time the screen is updated with new data.

\sa PYXDisplayTileInfo::knMinDisplayTileDepth
\sa PYXDisplayTileInfo::knMaxDisplayTileDepth

\param nDepth	The new tile depth for the visual tiles.
*/
void ScreenManager::setTileDepth(int nDepth)
{
	if (nDepth <= PYXDisplayTileInfo::knMaxDisplayTileDepth ||
		nDepth >= PYXDisplayTileInfo::knMinDisplayTileDepth	)
	{
		m_nTileDepth = nDepth;
	}
	else
	{
		PYXTHROW(	PYXVisualizationException, 
					"Invalid display tile depth of '" <<
					nDepth << "'."	);
	}
}

/*!
Users may prefer speed to quality or vice versa. The detail modifier will
allow a user to increase or decrease the data resolution for a screen of data.
The basic calculation of the detail must be determined by the camera and its
location. The modifier will be applied after that calculation takes place.

\param nDetail	The new detail modifier for the screen of data.
*/
void ScreenManager::setDetailModifier(int nDetail)
{
	m_nDetailModifier = nDetail;
}

/*!
Apply the user defined detail modifier and limit the resolution to display
tile minimum and maximum values.

\param nRawResolution	The resolution as calculated by the camera.

\return The resoltuion normalized according to user settings and system
		limitations.

\sa PYXDisplayTileInfo
*/
int ScreenManager::applyResolutionModifiers(int nRawResolution) const
{
	nRawResolution += m_nDetailModifier;
	
	nRawResolution = std::min(nRawResolution, PYXMath::knMaxAbsResolution);
	nRawResolution = std::max(nRawResolution, PYXIcosIndex::knMinSubRes);

	return nRawResolution;
}

/*!
Calculate the visual tile root resolution for a display (data) resolution.
The root resolution is constrained to visual limits.

\param nDisplayResolution	The un-modified display resolution.

\return The root resolution for display tiles with a given data resolution.
*/
int ScreenManager::calcTileResolution(int nDisplayResolution) const
{
	int nTileResolution = nDisplayResolution;
	nTileResolution -= m_nTileDepth;
	
	nTileResolution = std::min(nTileResolution, PYXMath::knMaxAbsResolution);
	nTileResolution = std::max(nTileResolution, PYXIcosIndex::knMinSubRes);

	assert (	PYXDisplayTileInfo::knMinDisplayTileDepth <=
				(nDisplayResolution - nTileResolution) &&
				"Invalid display resolution passed."	);

	return nTileResolution;
}

/*!
Return a shared copy of a grid display tile from the cache if it exists. If the 
tile does not exist in the cache it is created and placed in the cache.

\param tile		The geometry of the grid tile to create.

\return The a grid tile that matches the geometry and scale.
*/
PYXPointer<PYXDisplayTile> ScreenManager::getGridTile(
	const PYXTile& tile	)
{
	boost::mutex::scoped_lock lock(m_mutex);

	// insist that the tile has an origin child root index
	PYXTile originTile(tile);
	originTile.setOriginChildRoot();

	PYXPointer<PYXDisplayTile> spTile;

	std::auto_ptr<GridDisplayTileSpec> spSpec(new GridDisplayTileSpec);
	spSpec->setTile(originTile);

#ifdef ENABLE_BUG
	// attempt to find the tile in the cache
	spTile = m_tileCache.getDisplayTile(*spSpec);
	
	// if the tile did not exist in the cache, create and add it
	if (spTile.get() == 0)
	{
#endif
		spTile = PYXGridDisplayTile::create();
		spTile->initializeTile(spSpec.release());
#ifdef ENABLE_BUG
		m_tileCache.add(spTile);
	}
#endif
	return spTile;
}

/*!
Return a single tile that is populated with data from a specific process.

\param tile		The geometry of the tile to retrieve.
\param procref	The process reference of the data to visualize (must not be null)

\return The unique data tile.
*/
PYXPointer<PYXDisplayTile> ScreenManager::getDataTile(
	const PYXTile& tile,
	const ProcRef& procref	)
{
	boost::mutex::scoped_lock lock(m_mutex);

	// insist that the tile has an origin child root index
	PYXTile originTile(tile);
	originTile.setOriginChildRoot();

	assert(procref != ProcRef());
	std::auto_ptr<DataDisplayTileSpec> spSpec(new DataDisplayTileSpec(procref));
	spSpec->setTile(originTile);

	// attempt to find the tile in the cache
#ifdef ENABLE_BUG
	PYXPointer<PYXDisplayTile> spTile = m_tileCache.getDisplayTile(*spSpec);
#else
	PYXPointer<PYXDisplayTile> spTile; // = m_tileCache.getDisplayTile(*spSpec);
#endif

#ifdef ENABLE_BUG
	// if the tile did not exist in the cache, create and add it
	if (spTile.get() == 0)
	{
#endif
		spTile = PYXDataDisplayTile::create();
		spTile->initializeTile(spSpec.release());
		boost::dynamic_pointer_cast<PYXDataDisplayTile>(spTile);//->updateData();
		
#ifdef ENABLE_BUG
		m_tileCache.add(spTile);
	}
#endif
	return spTile;
}

/*!
This method sorts a vector of tiles so that the tiles closest to the focal point
and facing most towards the view point are placed first in the vector.

\param fViewPoint	The point that the screen is being viewed from.
\param fFocalPoint	The position that the view is focused on.
\param vecTiles		The list of tiles to sort, the vector will be re-ordered
					during the execution of the method. (in/out)
*/
void ScreenManager::sortTiles(	
	const PYXCoord3DDouble&  fViewPoint,
	const PYXCoord3DDouble& fFocalPoint,
	std::vector< PYXPointer<PYXDisplayTile> >* pvecTiles	)
{
	struct Comparator
	{
		Comparator(	const PYXCoord3DDouble& fViewPoint, 
					const PYXCoord3DDouble& fFocalPoint	) : 
			m_fViewPoint(fViewPoint),
			m_fFocalPoint(fFocalPoint) {}

		bool operator ()(
			const PYXPointer< PYXDisplayTile >& lhs,
			const PYXPointer< PYXDisplayTile >& rhs)
		{
			double lhsFactor = computeTileVisibilityFactor(lhs, m_fViewPoint, m_fFocalPoint);
			double rhsFactor = computeTileVisibilityFactor(rhs, m_fViewPoint, m_fFocalPoint);
			return lhsFactor < rhsFactor;
		}

		double computeTileVisibilityFactor(	PYXPointer< PYXDisplayTile > spTile,
											const PYXCoord3DDouble& fViewPoint,
											const PYXCoord3DDouble& fFocalPoint	)
		{
			// normalized vector indicating central camera view direction
			PYXCoord3DDouble viewVector = fFocalPoint;
			viewVector.subtract(fViewPoint);
			viewVector.normalize();
			
			// normalized vector from camera toward this tile
			PYXCoord3DDouble tileVector = spTile->getCentrePoint();
			tileVector.subtract(fViewPoint);
			tileVector.normalize();

			// Centrality factor: a fraction where 0 means this tile is right in the
			// centre of our view (i.e., the angle between view and tile vectors is
			// very small) and 1 means it's out in the periphery
			double centralityFactor = 0.5 * (1.0 - viewVector.dot(tileVector));

			// Perpendicularity factor: 0 means we're looking directly down onto the
			// tile (angle between tile normal and view vector is 180 degrees) and 1
			// means we see the tile tilted on-edge.  To compute this, we take advantage
			// of the fact that the tile's centre point is defined as a point on the
			// unit sphere, and can thus also be interpreted as a unit normal vector.
			PYXCoord3DDouble normalVector = spTile->getCentrePoint();
			double perpendicularityFactor = 0.5 * (1.0 + tileVector.dot(normalVector));

			return centralityFactor * perpendicularityFactor;
		}

		const PYXCoord3DDouble& m_fViewPoint;
		const PYXCoord3DDouble& m_fFocalPoint;
	};

	// perform the actual sort using the comparator
	std::sort(pvecTiles->begin(), pvecTiles->end(), Comparator(fViewPoint, fFocalPoint));
}
