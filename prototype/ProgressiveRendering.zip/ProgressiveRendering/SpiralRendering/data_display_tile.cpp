/******************************************************************************
data_display_tile.cpp

begin		: 2005-02-21
copyright	: (C) 2005 by the PYXIS innovation inc.
web			: www.pyxisinnovation.com
******************************************************************************/
#define VISUALIZATION_MODEL_SOURCE
#include "data_display_tile.h"

// local includes
#include "colour_converter.h"
#include "display_tile_info.h"
#include "exceptions.h"
#include "vtk_utils.h"

// pyxlib includes
#include "pyxis/data/coverage.h"
#include "pyxis/data/value_tile.h"
#include "pyxis/derm/edge_iterator.h"
#include "pyxis/derm/index_math.h"
#include "pyxis/derm/projection_method.h"
#include "pyxis/derm/reference_sphere.h"
#include "pyxis/derm/spiral_iterator.h"
#include "pyxis/pipe/pipe_manager.h"
#include "pyxis/utility/app_services.h"
#include "pyxis/utility/coord_lat_lon.h"
#include "pyxis/utility/sphere_math.h"
#include "pyxis/utility/tester.h"
#include "pyxis/utility/value.h"

// vtk includes
#include "vtkBMPWriter.h"
#include "vtkCellArray.h"
#include "vtkDoubleArray.h"
#include "vtkImageData.h"
#include "vtkLookupTable.h"
#include "vtkPointData.h"
#include "vtkPropCollection.h"
#include "vtkPolyData.h"
#include "vtkTexture.h"

// standard includes
#include <cassert>
#include <memory>

// properties strings
const std::string PYXDataDisplayTile::kstrScope = "PYXDataDisplayTile";
const std::string PYXDataDisplayTile::kstrTagLightAmbient = "AmbientLightLevel";
const std::string PYXDataDisplayTile::kstrTagDescLightAmbient = "The amount of light reflecting off of other objects hitting this one (0.0 - 1.0).";
const std::string PYXDataDisplayTile::kstrTagLightDiffuse = "DiffuseLightLevel";
const std::string PYXDataDisplayTile::kstrTagDescLightDiffuse = "The lighting change as the viewpoint moves away from the centre of an object (0.0 - 1.0).";
const std::string PYXDataDisplayTile::kstrTagLightSpecular = "SpecularLightLevel";
const std::string PYXDataDisplayTile::kstrTagDescLightSpecular = "The amount of reflection given off of an object (0.0 - 1.0).";
const std::string PYXDataDisplayTile::kstrTagVectorOpacity = "VectorOpacity";
const std::string PYXDataDisplayTile::kstrTagDescVectorOpacity = "The opacity value of vectors when averaging is turned on (0.0 - 1.0 with 1.0 being opaque)";

//! The default opacity of vector lines when averaged with raster data.
double kfDefaultVectorOpacity = 0.4;
double PYXDataDisplayTile::m_fVectorOpacity;

//! Default ambient light characteristics
static const double kfDefaultAmbientData = 0.2;
double PYXDataDisplayTile::m_fDefaultAmbient;

//! Default ambient light characteristics
static const double kfDefaultDiffuseData = 0.08;
double PYXDataDisplayTile::m_fDefaultDiffuse;

//! Default specular light characteristic
static const double kfDefaultSpecularData = 0.0;
double PYXDataDisplayTile::m_fDefaultSpecular;

//! Maximum elevation multiple
const double PYXDataDisplayTile::kfMaxElevationFactor = 50.0;

//! Minimum elevation multiple
const double PYXDataDisplayTile::kfMinElevationFactor = 1.0;

/*! 
The extra spiral that needs to be drawn to correct for the interpolation
bringing in part of the background colour on a texture image.
*/
const int PYXDataDisplayTile::knInterpolationCorrection = 1;

//! The fraction of values to sample on the first knitting pass
const int knKnitFraction = 10;

/*!
The elevation colour mapper for converting elevation values in metres into
PYXRGB values.
*/
std::auto_ptr<ColourConverter > PYXDataDisplayTile::m_spElevationColours;

//! Tester class
TesterUnit<PYXDataDisplayTile> gTester;

//! Unit Test method
void PYXDataDisplayTile::test()
{
// TODO Re-enable when test data sources are available
/*
	// create a tile for testing
	PYXDataDisplayTile* pDataActor = PYXDataDisplayTile::New();

	//! Add vector data source
	PYXDataItem* pDataItem = PYXDataItem::create();
	pDataItem->setDSType(PYXDataItem::knVector);
	pDataActor->addDataItem(pDataItem);
	TEST_ASSERT(1 == pDataActor->dataSourceCount());
	TEST_ASSERT(1 == pDataActor->dataSourceCount(PYXDataItem::knVector));
	TEST_ASSERT(pDataActor->usesData(*pDataItem));
	pDataItem->deleteObject();

	//! Add raster data source
	pDataItem = PYXDataItem::create();
	pDataItem->setDSType(PYXDataItem::knRaster);
	pDataActor->addDataItem(pDataItem);
	TEST_ASSERT(2 == pDataActor->dataSourceCount());
	TEST_ASSERT(1 == pDataActor->dataSourceCount(PYXDataItem::knRaster));
	TEST_ASSERT(pDataActor->usesData(*pDataItem));
	pDataItem->deleteObject();

	//! Add elevation data source
	pDataItem = PYXDataItem::create();
	pDataItem->setDSType(PYXDataItem::knDEM);
	pDataActor->addDataItem(pDataItem);
	TEST_ASSERT(3 == pDataActor->dataSourceCount());
	TEST_ASSERT(1 == pDataActor->dataSourceCount(PYXDataItem::knDEM));
	TEST_ASSERT(pDataActor->usesData(*pDataItem));
	pDataItem->deleteObject();

	pDataActor->Delete();

*/
}

/*!
Default constructor.
*/
PYXDataDisplayTile::PYXDataDisplayTile() :
		m_fElevationFactor(10.0),
		m_itProgressive(PYXIcosIndex("1"),0),
		m_bProgressiveKnittingComplete(false)
{
	m_spTextureImage = boost::intrusive_ptr<vtkImageData>(vtkImageData::New(),false);
	m_spTextureImage->SetScalarTypeToUnsignedChar();
	m_spTextureImage->SetNumberOfScalarComponents(3);
	m_spTexture = boost::intrusive_ptr<vtkTexture>(
								vtkTexture::New(),
								false	);
	m_spTexture->SetInput(m_spTextureImage.get());
	m_spTexture->InterpolateOn();
	m_spTexture->RepeatOff();
	
	// TODO: Remove this line in cleanup
	//m_spTexture->InterpolateOff();
	
	getActor()->SetTexture(m_spTexture.get());
	m_bTextureDone = false;
}

/*! 
Default destructor.
*/
PYXDataDisplayTile::~PYXDataDisplayTile()
{
	// free the data sources
	freeDataSources();
}

/*!
Stop observing all data sources and remove any association with them.
*/
void PYXDataDisplayTile::freeDataSources()
{
	// Detach from all data sources
}

/*! 
Initialize the default elevation colour tables by creating a table for land
values (green) and a table for sea values (blue).
*/
void PYXDataDisplayTile::initStaticData()
{
	// set the default light levels for data tiles
	m_fDefaultAmbient = getAppProperty(
							PYXDataDisplayTile::kstrScope, 
							PYXDataDisplayTile::kstrTagLightAmbient, 
							kfDefaultAmbientData,
							PYXDataDisplayTile::kstrTagDescLightAmbient	);
	m_fDefaultDiffuse = getAppProperty(	
							PYXDataDisplayTile::kstrScope, 
							PYXDataDisplayTile::kstrTagLightDiffuse, 
							kfDefaultDiffuseData,
							PYXDataDisplayTile::kstrTagDescLightDiffuse	);
	m_fDefaultSpecular = getAppProperty(	
							PYXDataDisplayTile::kstrScope, 
							PYXDataDisplayTile::kstrTagLightSpecular, 
							kfDefaultSpecularData,
							PYXDataDisplayTile::kstrTagDescLightSpecular	);
	m_fVectorOpacity = getAppProperty(	
							PYXDataDisplayTile::kstrScope, 
							PYXDataDisplayTile::kstrTagVectorOpacity, 
							kfDefaultVectorOpacity,
							PYXDataDisplayTile::kstrTagDescVectorOpacity	);
}

/*
The method will associate a connectivity with the actor.  The connectivity
will follow the ordering of the pyxis iterator.
*/
void PYXDataDisplayTile::setGrid()
{

	DataDisplayTileSpec* pSpec = dynamic_cast<DataDisplayTileSpec*>(m_spSpec.get());

	// establish connectivity
	boost::intrusive_ptr<vtkCellArray> spCells =
		PYXDisplayTileInfo::getConnectivity(	PYXDisplayTileInfo::knTriangularTile,
												getTile()	);
	m_spCells->SetCells(spCells->GetNumberOfCells(), spCells->GetData());

	// assign texture coordinates	
	m_spTextureCoords = PYXDisplayTileInfo::getTextureCoordList(getTile(), pSpec->getTRI());
	m_spPolyData->GetPointData()->SetTCoords(m_spTextureCoords.get());

	// set dimensions of the texture image
	int nHeight = 0;
	int nWidth = 0;
	PYXDisplayTileInfo::getTextureDimensions(getTile(), &nWidth, &nHeight, pSpec->getTRI());
	m_spTextureImage->SetDimensions(nWidth, nHeight, 1);
	m_spTextureImage->SetExtent(0, nWidth - 1, 0, nHeight - 1, 0, 0);
	m_spTextureImage->AllocateScalars();

	// paint the default background colour to each texture
	unsigned char* pTextureBackground = (unsigned char*)(m_spTextureImage->GetScalarPointer());
	for (int row=0; row<nHeight; row++)
	{
		for (int col=0; col<nWidth; col++)
		{
			*pTextureBackground++ = 1;
			*pTextureBackground++ = 2;
			*pTextureBackground++ = 3;
		}
	}
}

void PYXDataDisplayTile::updateTile()
{
	boost::mutex::scoped_lock lock(m_mutex);
	updateData();
}

/*
Update the data which needs to be drawn for a tile's texture image
*/
void PYXDataDisplayTile::updateData()
{
	// access the coverage data
	DataDisplayTileSpec* pSpec = dynamic_cast<DataDisplayTileSpec*>(m_spSpec.get());
	assert(pSpec != 0 && "No spec");

	// set dimensions of the texture image
	int nHeight = 0;
	int nWidth = 0;
	PYXDisplayTileInfo::getTextureDimensions(getTile(), &nWidth, &nHeight, pSpec->getTRI());

	// Assert that TRI is in valid range.
	assert(pSpec->getTRI() >= PYXDisplayTileInfo::knMinTextureResIncrement &&
		   pSpec->getTRI() <= PYXDisplayTileInfo::knMaxTextureResIncrement);

	// Assert that TRI between DataDisplayTile and DisplayTileInfo are the same.
	assert(pSpec->getTRI() == PYXDisplayTileInfo::knTextureResIncrement);

	// attempt to access the hard coded data source
	assert(pSpec->getProcRef() != ProcRef());
	m_spCoverageProc = PipeManager::getProcess(pSpec->getProcRef());

	if (m_spCoverageProc)
	{
		boost::intrusive_ptr<ICoverage> spCov;
		m_spCoverageProc->getOutput()->QueryInterface(ICoverage::iid, (void**) &spCov);
		assert(spCov);

		const std::vector<int>& vecTextureOffsets = PYXDisplayTileInfo::getTexelOffsetList(getTile(), pSpec->getTRI());
		unsigned char* pTexture = (unsigned char*)(m_spTextureImage->GetScalarPointer());

		/*
		Go to the mesh cell resolution:
		Currently, m_pyxTile.getCellResolution() returns the resolution at which
		vertices of the mesh cell exist. We subtract 1 from this resolution, from
		the tile we use for drawing, to get the actual mesh cells. These actual
		mesh cells are then spirally iterated over, and coloured in.
		*/
		PYXTile tile(getTile().getRootIndex(), getTile().getCellResolution() - 1);
		int nCellOffset = 0;

		/*
		The target background colour, used to check if a texel offset in the
		texture image has been painted to its data yet.
		*/
		unsigned char target[3];
		target[0] = 1;
		target[1] = 2;
		target[2] = 3;

		// Get each cell in the mesh for the tile one by one, and paint it		
		PYXValue value;
		unsigned char* pTexel;
		int nTexelOffset;
		PYXPointer<PYXValueTile> spValueTile = spCov->getFieldTile(
			tile.getRootIndex(), tile.getCellResolution() + pSpec->getTRI(), 0);

		for (	PYXPointer<PYXIterator> spIt(tile.getIterator());
				!spIt->end();
				spIt->next()	)
		{
			// Start Spiral Iterating to paint each mesh cell one by one
			PYXSpiralIterator itSpiral(spIt->getIndex(),
									   pSpec->getTRI(),
									   knInterpolationCorrection );

			for (; !itSpiral.end(); ++itSpiral)
			{
				const PYXIcosIndex& index = itSpiral.getIndex();
				nTexelOffset = vecTextureOffsets[nCellOffset];

				if(nTexelOffset != -1)
				{
					pTexel = pTexture + nTexelOffset;

					if (!memcmp(pTexel, target, 3))
					{
						if (spValueTile && index.isDescendantOf(tile.getRootIndex()))
						{						
							value = spValueTile->getValue(index, 0);
						}
						else
						{
							value = spCov->getCoverageValue(index, 0);
						}

						if (!getColourFromValue(value, pTexel))
						{
							// no raster value at all, use default colour
							pTexel[0] = PYXDisplayTileInfo::getDefaultTileColour().red();
							pTexel[1] = PYXDisplayTileInfo::getDefaultTileColour().green();
							pTexel[2] = PYXDisplayTileInfo::getDefaultTileColour().blue();
						}
					}					
				}
				++nCellOffset;
			}
		}

		if (spCov->getCoverageDefinition()->getFieldDefinition(1).getContext()
			== PYXFieldDefinition::knContextElevation)
		{
			updateElevation(spCov);
		}
	}
	else
	{
		// initialize texture to test pattern
		unsigned char* pTexture = (unsigned char*)(m_spTextureImage->GetScalarPointer());
		for (int row=0; row < nHeight; row++)
		{
			for (int col = 0; col < nWidth; col++)
			{
				// get the index for the offset
				if(getTile().getRootIndex().isPentagon())
				{
					*pTexture++ = 255;
					*pTexture++ = 0;
					*pTexture++ = 0;
				}
				else if (getTile().getRootIndex().isFace())
				{
					*pTexture++ = 0;
					*pTexture++ = 255;
					*pTexture++ = 0;
				}
				else
				{
					*pTexture++ = 0;
					*pTexture++ = 0;
					*pTexture++ = 255;
				}
			}
		}
	}

	// Update the texture image, and set the flag to indicate completion.
	m_spTextureImage->Update();
	m_spTexture->Modified();
	m_spPoints->Modified();

	m_bTextureDone = true;

	// TESTING ONLY: output texture as BMP
	if (false)
	{
		boost::filesystem::path texturePath("C:\\Textures", boost::filesystem::native);
		if (boost::filesystem::exists(texturePath))
		{
			texturePath /= (getTile().getRootIndex().toString() + ".bmp");
			vtkBMPWriter* pWriter = vtkBMPWriter::New();
			pWriter->SetInput(m_spTextureImage.get());
			pWriter->SetFileName(texturePath.native_file_string().c_str());
			pWriter->Write();
			pWriter->Delete();
		}
	}
}

/*
Process and apply the elevation for this tile.
*/
void PYXDataDisplayTile::updateElevation(boost::intrusive_ptr<ICoverage> spCov)
{
	const PYXIcosIndex& index = getTile().getRootIndex();
	int nRes = getTile().getCellResolution();

	// Get the tile's elevation data.
	PYXPointer<PYXValueTile> spValueTile = spCov->getFieldTile(index, nRes, 1);
	if (!spValueTile)
	{
		return;
	}

	// Iterator order, cell offset
	int nOffset = 0;
	int nBodyMeshCellVertexCount = m_nMaxCount;
			
	if (m_nKnitOffset != knInvalidOffset)
	{
		nBodyMeshCellVertexCount = m_nKnitOffset;
	}
	assert(nBodyMeshCellVertexCount == PYXIcosMath::getCellCount(index, nRes));
	
	// Apply elevation over contained body of tile
	for (int nIndex = 0; nIndex < nBodyMeshCellVertexCount; ++nIndex)
	{
		double fElevation = 0.0;
		PYXValue value = spValueTile->getValue(nOffset, 0);

		if (!value.isNull())
		{
			fElevation = value.getDouble();				
			applyElevation(fElevation, nOffset);
		}
		++nOffset;
	}

	// Apply elevation over non-contained area of tile
	if (m_nKnitOffset != knInvalidOffset)
	{
		PYXEdgeIterator itEdge(getTile().getRootIndex(), getTile().getCellResolution());
		for (; !itEdge.end(); ++itEdge)
		{
			double fElevation = 0.0;
			PYXValue value = spCov->getCoverageValue(itEdge.getIndex(), 1);

			if (!value.isNull())
			{
				fElevation = value.getDouble();
				applyElevation(fElevation, nOffset);
			}
			++nOffset;
		}
	}
}

/*! 
Set the elevation factor of the elevation data and reprocess all of the points
to reflect the new elevation multiple.  The elevation factor must fall between
PYXDrawUtils::kfMinElevationFactor and PYXDrawUtils::kfMaxElevationFactor.

\param fElevationFactor	The multiple to apply to any elevation data.
*/
void PYXDataDisplayTile::setElevationFactor(double fElevationFactor)
{
	boost::recursive_mutex::scoped_lock lock(getDisplayTileMutex());

	// verify the parameter is a valid elevation factor
	if (	(fElevationFactor > kfMaxElevationFactor) ||
			(fElevationFactor < kfMinElevationFactor)	)
	{
		PYXTHROW(	PYXVisualizationException,
					"Invalid elevation factor. Got: '" << fElevationFactor <<
					"' Min: '" << kfMinElevationFactor <<
					"' Max: '" << kfMaxElevationFactor << "'."	);
	}
	
	// TO IMPLEMENT: REPROCESS ALL CURRENT POINT LOCATIONS.

	m_fElevationFactor = fElevationFactor;
}

/*! 
Free the static data that was created at startup.
*/
void PYXDataDisplayTile::freeStaticData()
{
}

/*! 
Initialize a tile at a specific resolution using a root index and any
number of valid data sets.  This method must be called before the tile is
used and it can only be called once for each instance of a tile.

*/
void PYXDataDisplayTile::initializeTile(DisplayTileSpec* pSpec)
{
	boost::recursive_mutex::scoped_lock lock(getDisplayTileMutex());

	m_spSpec.reset(pSpec);
	if (dynamic_cast<DataDisplayTileSpec*>(pSpec) == 0)
	{
		PYXTHROW(PYXDisplayTileException, "Spec is not a data tile specification.");
	}

	// pass variable verification on to base class
	try
	{
		// free up any existing data
		freeDataSources();

		// call the base initialization method
		PYXDisplayTile::initializeTileGeometry(	m_spSpec->getTile(),
												m_spSpec->getProjection()	);

		// set the update level for the appropriate number of resolutions
		m_nUpdateLevel = std::max(
			0, getTile().getDepth() - PYXDisplayTileInfo::getProgressiveDepth()	);
		m_itProgressive.reset(	getTile().getRootIndex(), 
								getTile().getCellResolution()	);

		// apply the lighting characteristics for the tile
		setLightProperties(	1.0,//m_fDefaultAmbient, 
							1.0, //m_fDefaultDiffuse,
							1.0 );//m_fDefaultSpecular	);
	}
	catch (PYXException& e)
	{
		PYXRETHROW(e, PYXException, "Unable to create data display tile.");
	}
}

/*!
Query the library for all data sources associated with this tile.  All
associated data sources of all types (raster, vector, elevation) are 
stored within the tile and observed for any changes.

\param pLibrary	A pointer to the associated data source library (ownership
				retained by caller).
*/
void PYXDataDisplayTile::setData()
{
	// TOFIX: Apply data
}


/*!
Apply an elevation value to an existing point within the tile.  This x, y, z
value is adjusted for the relative origin, scaled back to the reference sphere
and then scaled out to the new elevation.  This procedure is subject to the 
limitations of floating point arithmetic.

\param fElevation	The new elevation value in metres to apply.
\param nOffset		The offset of the value within the tile structure.
*/
void PYXDataDisplayTile::applyElevation(	const double& fElevation,											
											int nOffset	)
{
	assert(nOffset < m_nMaxCount);

	if (fElevation != 0.0)
	{
		// Get x,y,z values for pt, from m_spPoints
		PYXCoord3DDouble pt;
		double* pf3D = m_spPoints->GetPoint(nOffset);
		pt.setX(*pf3D);
		pf3D++;
		pt.setY(*pf3D);
		pf3D++;
		pt.setZ(*pf3D);
		
		pt.setX(pt.x() + m_coordOrigin.x());
		pt.setY(pt.y() + m_coordOrigin.y());
		pt.setZ(pt.z() + m_coordOrigin.z());

		pt.scale(	(fElevation * m_fElevationFactor + ReferenceSphere::kfRadius)	/
					ReferenceSphere::kfRadius	);

		pt.setX(pt.x() - m_coordOrigin.x());
		pt.setY(pt.y() - m_coordOrigin.y());
		pt.setZ(pt.z() - m_coordOrigin.z());

		m_spPoints->SetPoint(nOffset, pt);
	}
}


#if 0
/*!
Iterate over any associated vector data and colour the appropriate cells or 
create a symbol to represent it. If this method is interrupted during execution
with the spState variable, the next time it is called ALL of the work will be
executed again.

\param spState	The state of the thread that is calling for the thread update.
				The tile periodically checks this value to verify that the 
				update process should continue.

\return true if the method completed execution or false if the execution of the
		thread was interrupted.
*/
bool PYXDataDisplayTile::setVectorData(boost::shared_ptr<ThreadState> spState)
{

	// clear out the vector of symbols in case this is re-entrant
	m_vecSymbols.clear();

	// iterate over each of the data sources
	DataVector::const_iterator itDataItem = m_vecDataItemVector.begin();
	for (	; 
			itDataItem != m_vecDataItemVector.end() && spState->isRunning(); 
			++itDataItem	)
	{
		// get the data source
		boost::shared_ptr<PYXFeatureDataSource> spFeatureDS((*itDataItem)->getDSAsFeatureDS());
		assert(spFeatureDS && "Dynamic cast failed, DS not available.");

		// Are we drawing the selection data source - it will be done using averaging so we can see what is below it.
		bool bIsSelectionDS = ((*itDataItem)->getURI() == "virtualds.PYXSelectionDataSource.selectionds");

		// make a tile for geometry comparison
		PYXPointer<PYXFeatureIterator> spItFeature(spFeatureDS->getFeatureIterator(m_pyxTile));

		// create an edge iterator if necessary
		PYXPointer<PYXEdgeIterator> spItEdge;
		if (m_nKnitOffset != knInvalidOffset)
		{
			spItEdge = PYXEdgeIterator::create(	m_pyxTile.getRootIndex(),
												m_pyxTile.getCellResolution()	);
		}

		// iterate over each feature in the source
		boost::shared_ptr<StyleMapper> spStyleMapper = spFeatureDS->getStyleMapper();
		assert(spStyleMapper.get() != 0 && "Invalid style mapper.");

		FeatureStyle::FeatureStylePtr spStyle;
		PYXRGB rgb;
		for (; !spItFeature->end(); spItFeature->next())
		{
			// break out of the loop when interrupted
			if (!spState->isRunning())
			{
				TRACE_THREAD(	"Tile update thread state '" <<
								spState->getState() << 
								"' exiting setVectorData()."	);
				break;
			}				

			// extract the style
			boost::shared_ptr<const PYXFeature> spFeature = spItFeature->getFeature();
			spStyle = spStyleMapper->mapFeature(spFeature);

			// extract the decorated geometry if available
			boost::shared_ptr<const PYXGeometry> spGeometry = 
				spStyle->getAlternateGeometry();
			if (!spGeometry)
			{
				spGeometry = spFeature->getGeometry();
			}
			
			if (spGeometry)
			{

				// Assign the symbol for the feature
				addSymbolFeature(*itDataItem, spStyle, spFeature);

				// short circuit the loop if the geometry is not rendered
				if (!spStyle->shouldRenderGeometry())
				{
					continue;
				}

				// TODO: enhance styles so that a colour can apply to a DS
				// get the vector line colour from the style
				StyleManager::getInstance()->getColour(
										*itDataItem,
										spStyle,
										FeatureStyle::knVectorColour,
										&rgb	);

				// iterate over each cell in the feature geometry
				for (	PYXPointer<PYXIterator> spItIndex(spGeometry->getIterator());
						!spItIndex->end();
						spItIndex->next()	)
				{
					if (!spState->isRunning())
					{
						TRACE_THREAD(	"Tile update thread state '" <<
										spState->getState() << 
										"' exiting setVectorData()."	);
						break;
					}			

					const PYXIcosIndex& index = spItIndex->getIndex();
					
					// get the offset into the point array for this index
					int nOffset = calcIndexOffset(index, spItEdge.get());

					// set the colour for the index 
					if (knInvalidOffset != nOffset)
					{
						if (m_nRasterFusion == PYXDataDisplayTile::knAverage)
						{
							double* pVals = m_spScalars->GetTuple3( nOffset );
							m_spScalars->SetTuple3(	
								nOffset,
								rgb.red() * m_fVectorOpacity + pVals[0] * (1.0 - m_fVectorOpacity),
								rgb.green() * m_fVectorOpacity + pVals[1] * (1.0 - m_fVectorOpacity),
								rgb.blue() * m_fVectorOpacity + pVals[2] * (1.0 - m_fVectorOpacity)	);
						}
						else
						{
							m_spScalars->SetTuple3(	nOffset,
													rgb.red(),
													rgb.green(),
													rgb.blue()	);
						}
					}
				}
			}
		}
	}
	return spState->isRunning();
}
#endif

#if 0
/*!
Examine a feature and associated information and create a symbol to
represent it if applicable.  Any created symbols are added to the internal
list of associated symbols.  Only point symbols are currently supported for 
symbol drawing.  Any non point features or features that do not lie within 
the tile will not be created.

\param spDataItem	The data source that the feature is a part of.
\param spStyle		The style for this feature.
\param spFeature		The feature to create an icon for.

\return true if an icon was created otherwise false.
*/
bool PYXDataDisplayTile::addSymbolFeature(	
								PYXDataItem::CSPtr spDataItem,
								FeatureStyle::FeatureStyleConstPtr spStyle, 
								boost::shared_ptr<const PYXFeature> spFeature	)
{
	// extract the location to place the symbol
	std::string strIndex;
	if (spStyle->getValue(FeatureStyle::knSymbolCell, &strIndex))
	{
		// verify the geometry is on this tile
		PYXIcosIndex cellIndex(strIndex);
		if (calcIndexOffset(strIndex) != knInvalidOffset)
		{
			// get the symbol from the style manager
			PYXVTKSymbolLibrary::PYXSymbolPtr spSymbol =
				StyleManager::getInstance()->getSymbol(	spDataItem,
														spFeature,
														spStyle	);

			// process the symbol that was generated.
			if (spSymbol.get() != 0)
			{
				// set the elevation for point symbols
				PYXVTKPointSymbol* pPointSymbol = 
					dynamic_cast<PYXVTKPointSymbol*>(spSymbol.get());
				if (pPointSymbol != 0)
				{
					assert(	!pPointSymbol->getCell()->getIndex().isNull() && 
							"Null geometry in symbol"	);
					double fElevation = 0.0;
					getElevation(pPointSymbol->getCell()->getIndex(), &fElevation);
					pPointSymbol->setSymbolElevation(	
									fElevation *
									getElevationFactor()	);
				}

				// add the symbol to the internal list of symbols
				m_vecSymbols.push_back(spSymbol);
				return true;
			}
		}
	}

	return false;
}
#endif 

/*! 
Determine an RGB value for a specific location that best represents the raster 
data sources associated with the cell.

\param pyxIndex			The index of the cell to retrieve data for.
\param pcColour			Receives the RGB colour data.

\return True if there is an RGB colour available for pyxIndex, false if not.
*/
bool PYXDataDisplayTile::getColour( const PYXIcosIndex& pyxIndex,
									unsigned char pcColour[3]	) const
{
	// TOFIX: get data from pipeline
#if 0
	if (m_nRasterFusion == PYXDataDisplayTile::knAverage)
	{
		// Apply the raster arithmetic mean algorithm
		unsigned char rgb[3];
		double red = 0.0;
		double green = 0.0;
		double blue = 0.0;
		double fCount = 0.0;

		DataVector::const_iterator it =
			m_vecDataItemRaster.begin();
		for (; it != m_vecDataItemRaster.end(); ++it)
		{
			boost::shared_ptr<const PYXCoverage> spCoverage((*it)->getDSAsCoverage());
			assert(spCoverage && "Data source not open or not a coverage?");

			PYXFieldDefinition::eContextType nContext =
				spCoverage->getCoverageDefinition()->getFieldDefinition(0).getContext();
			PYXValue value = spCoverage->getCoverageValue(pyxIndex);

			if (getColourFromValue(value, nContext, rgb))
			{
				red += static_cast<double>(rgb[0]);
				green += static_cast<double>(rgb[1]);
				blue += static_cast<double>(rgb[2]);
				fCount += 1.0;
			}
		}

		if (0 < fCount)
		{
			// Arithmetic mean; adding 0.5 makes it round (not truncate).
			pcColour[0] = static_cast<unsigned char>((red + 0.5) / fCount);
			pcColour[1] = static_cast<unsigned char>((green + 0.5) / fCount);
			pcColour[2] = static_cast<unsigned char>((blue + 0.5) / fCount);
			return true;
		}
	}
	else
	{
		// No averaging: first data source with a colour for pyxIndex wins
		DataVector::const_iterator it =
			m_vecDataItemRaster.begin();
		for (; it != m_vecDataItemRaster.end(); ++it)
		{
			boost::shared_ptr<const PYXCoverage> spCoverage((*it)->getDSAsCoverage());
			assert(spCoverage && "Data source not open or not a coverage.");

			PYXFieldDefinition::eContextType nContext =
				spCoverage->getCoverageDefinition()->getFieldDefinition(0).getContext();
			PYXValue value = spCoverage->getCoverageValue(pyxIndex);

			if (getColourFromValue(value, nContext, pcColour))
			{
				return true;
			}
		}
	}
#endif
	return false;
}

/*! 
Determine an RGB value from a value.

\param value	The field value.
\param pcColour	Receives the RGB colour data.

\return True if there is an RGB colour available for the value, false if not.
*/
bool PYXDataDisplayTile::getColourFromValue(	const PYXValue& value,
											    unsigned char pcColour[3]	) const
{
	// TOFIX: Get colour from pipeline
	if (!value.isNull() && value.getArraySize() == 3)
	{
		// Expecting an array of 3 uint8_t.
		assert(value.getType() == PYXValue::knArray);
		assert(value.getArrayType() == PYXValue::knUInt8);
		assert(3 <= value.getArraySize());
		pcColour[0] = value.getUChar(0);
		pcColour[1] = value.getUChar(1);
		pcColour[2] = value.getUChar(2);

		return true;
	}
	return false;
}

/*!
Maps an elevation value in metres through the default elevation colour table.

\param fElevation		The elevation value to map to a colour
\param pcColour			Receives the RGB colour data.
*/
void PYXDataDisplayTile::getColourFromElevation( const double& fElevation,
												 unsigned char pcColour[3]	) const
{
	m_spElevationColours->mapValue(fElevation, &m_rgbBuffer);
	pcColour[0] = m_rgbBuffer.red();
	pcColour[1] = m_rgbBuffer.green();
	pcColour[2] = m_rgbBuffer.blue();
}

#if 0
/*!
Add an additional data source to the list of data associated with this tile. The
data source is also observed by the tile for any changes or updates. Data sources
should not be added multiple times to the same tile.

\param spDataItem	The new source for the tile.
*/
void PYXDataDisplayTile::addDataItem(PYXDataItem::SPtr spDataItem)
{
	assert((spDataItem.get() != 0) && "Invalid argument.");
	assert(!usesData(*spDataItem.get()) && "Data already associated with tile.");
	switch (spDataItem->getDSType())
	{
		case PYXDataItem::knDEM:
		{
			assert(	spDataItem->getDSType() == PYXDataItem::knDEM &&
					"Data source type does not match."	);
			assert(	spDataItem->getDSAsCoverage() &&
					"Data source not open or not a coverage.");

			m_vecDataItemElevation.push_back(spDataItem);
			spDataItem->attach(this);	
			break;
		}

		case PYXDataItem::knRaster:
		{
			assert(	spDataItem->getDSType() == PYXDataItem::knRaster &&
					"Data source type does not match."	);
			assert(	(spDataItem->getDSAsCoverage())
					&& "Data source not open or not a coverage.");

			m_vecDataItemRaster.push_back(spDataItem);
			spDataItem->attach(this);	
			break;
		}

		case PYXDataItem::knVector:
		{
			assert(	spDataItem->getDSType() == PYXDataItem::knVector &&
					"Data source type does not match."	);
			assert(	spDataItem->getDSAsFeatureDS() &&
					"Data source not open or not a feature DS?");

			m_vecDataItemVector.push_back(spDataItem);
			spDataItem->attach(this);	
			break;
		}

		default: { assert(false && "Unknown data type"); }
	}
}
#endif


/*!
Process messages from the data sources and data tiles that were used to create 
this tile.  

\param spEvent	The notification event to process.
*/
void PYXDataDisplayTile::updateObserverImpl(PYXPointer<NotifierEvent> spEvent)
{
	// TOFIX: Event processing

#if 0
	bool bTexturing = 0; // PYXLibraryImpl::getTextureResIncrement() >= 0;

	DataSourceEvent* pDSEvent = dynamic_cast<DataSourceEvent*>(spEvent.get());
	if (pDSEvent != 0)
	{
		if (pDSEvent->getEventType() == DataSourceEvent::knDataInvalid)
		{
			// invalidate the data
			getCacheStatus()->setState(CacheStatus::knExpired);
			notify(spEvent);
		}
		else if (pDSEvent->getEventType() == DataSourceEvent::knGeometryInvalid)
		{
			if (pDSEvent->getGeometry()->intersects(&getTile()))
			{
				getCacheStatus()->setState(CacheStatus::knExpired);
				notify(spEvent);
				//{
				//	// the data source event was processed, pass on the tile event
				//	boost::shared_ptr<PYXDataDisplayTileEvent> spEvent(
				//		new PYXDataDisplayTileEvent(this)	);
				//	notify(spEvent);
				//}
				return;

				if (!bTexturing)
				{
					// Create an edge iterator if necessary.
					PYXPointer<PYXEdgeIterator> spItEdge;
					if (m_nKnitOffset != knInvalidOffset)
					{
						spItEdge = PYXEdgeIterator::create(	
							m_pyxTile.getRootIndex(),
							m_pyxTile.getCellResolution()	);				}

					// Iterate over event cells at the display resolution.
					PYXResolutionChangeIterator it(
						pDSEvent->getGeometry()->getIterator(),
						getTile().getCellResolution());

					for (; !it.end(); it.next())
					{
						// Get the offset into the tuple collection.
						const int nOffset = calcIndexOffset(it.getIndex(), spItEdge.get());
						if (nOffset == -1)
						{
							// This index doesn't intersect with this tile.
							continue;
						}

						//assert(0 <= nOffset && nOffset < m_spScalars->GetNumberOfTuples());

						// Get the new colour from the data source.
						// TODO don't just blindly use the first one, get it from the
						// data source event (when it is added there)
						unsigned char pcColour[3];

						bool bHasColour = getColour(it.getIndex(), pcColour);
						if (!bHasColour)
						{
							double fElevation;
							bool bHasElevation = getElevation(it.getIndex(), &fElevation);

							if (bHasElevation)
							{
								getColourFromElevation(fElevation, pcColour);

								// TODO obviously we're only handling colour change
								// for elevation and not an actual xyz points change
							}
							else
							{
								// Use black.
								pcColour[0] = 0;
								pcColour[1] = 0;
								pcColour[2] = 0;
							}
						}

						// Set the colour.
						m_spScalars->SetTuple3(
							nOffset,
							pcColour[0],
							pcColour[1],
							pcColour[2]);
					}
				}

				// Tell it to update.
				if (!bTexturing)
				{
					m_spScalars->Modified();
				}
				else
				{
					updateTexture();
				}
			}

			// the data source event was processed, pass on the tile event
			boost::shared_ptr<PYXDataDisplayTileEvent> spEvent(
				new PYXDataDisplayTileEvent(this)	);
			notify(spEvent);
		}
	}

	// event is not passed on to observers unless it is a known type.
#endif
}

/*! 
Determine the offset of the specified index in terms of its offset within the 
data arrays used to visually represent this tile.  This method requires that 
passed iterators be initialized to the correct start positions.

\param pyxIndex			The index to determine the offset of.
\param pEdgeIterator	The vector of iterators that are used to knit this tile
						to adjacent tiles (if required).

\return The offset into the arrays for the specified index or knInvalidOffset
		if the index does not exist in this tile.
*/
int PYXDataDisplayTile::calcIndexOffset(	const PYXIcosIndex& pyxIndex,
											PYXEdgeIterator* pEdgeIterator	)
{
	if (pyxIndex.getResolution() != getTile().getCellResolution())
	{
		return knInvalidOffset;
	}

	// determine if the index is within the main tesselation or not
	if (pyxIndex.isDescendantOf(getTile().getRootIndex()))
	{
		return PYXIcosMath::calcCellPosition(	getTile().getRootIndex(), 
												pyxIndex	);
	}
	else if (	(m_nKnitOffset != knInvalidOffset) &&
				(pEdgeIterator != 0)	)
	{
		if (pEdgeIterator->setIteratorIndex(pyxIndex))
		{
			return (pEdgeIterator->calcCurrentOffset() + m_nKnitOffset);
		}
	}

	return knInvalidOffset;
}

#if 0
/*! 
Initialize the test tile with a geometry and data items.

\param pyxTile		The geometry the test tile should represent.
\param lstDataItem	The list of data items to associate with the tile
*/
void PYXTestDataDisplayTile::initializeTile(
			const PYXTile& pyxTile,
			const PYXLibrary::PYXDataItemList& lstDataItem	)
{
	assert(	pyxTile.getRootIndex().hasVertexChildren() &&
			"Root index must be origin child."	);
	m_pyxTile = pyxTile;

	// add the data items to the tile
	PYXLibrary::PYXDataItemList::const_iterator itList = lstDataItem.begin();
	for (; itList != lstDataItem.end(); ++itList)
	{
		addDataItem(*itList);
	}
}
#endif

/*!
Determine if this data display tile spec is equal to a display tile spec.

\param rhs	The generic display tile spec to test for equality against this one.

\return true if the specifications match.
*/
bool DataDisplayTileSpec::operator==(const DisplayTileSpec& rhs) const
{
	const DataDisplayTileSpec* pSpec = dynamic_cast<const DataDisplayTileSpec*>(&rhs);
	if (pSpec != 0)
	{
		return (m_procref == pSpec->m_procref && getTile() == pSpec->getTile() 
			&& m_nTextureResolutionIncrement == pSpec->getTRI());
	}
	
	return false;
}
