﻿using System;
using HoytSoft.Common.Services;
using System.Threading;

namespace Service {
	class Program {
		static void Main(string[] args) {
			//Auto-detect available services
			//ServiceBase.Main(args);

			//Explicitly specify what to run
			ServiceBase.RunService(args, typeof(MyService));
		}
	}

	[Service(
		"MyServiceTest",
		"MyService Test",
		"MyService test description",
		AutoInstall = true,
		ServiceType = ServiceType.OwnProcess,
		ServiceStartType = ServiceStartType.AutoStart,
		ServiceControls = ServiceControls.StartAndStop | ServiceControls.Shutdown
	)]
	public class MyService : ServiceBase {
		#region Variables
		bool pleaseStop = false;
		#endregion

		#region Constructors
		public MyService() : base() {
		}
		#endregion

		protected override void Start() {
			base.Start();

			uint count = 0;
			while (!pleaseStop) {
				++count;

				System.Diagnostics.Debug.WriteLine("Running...");
				Thread.Sleep(1000);

				//Not technically a valid test b/c custom messages have to be between 128 and 255.
				if (count % 5 == 0)
					this.TestCustomMessage(count);
			}
			System.Diagnostics.Debug.WriteLine("Stopped");
		}

		protected override void Stop() {
			base.Stop();

			System.Diagnostics.Debug.WriteLine("Please stop...");
			pleaseStop = true;
		}

		protected override void CustomMessage(uint Code) {
			base.CustomMessage(Code);

			System.Diagnostics.Debug.WriteLine("Received custom message: " + Code + "...");
		}
	}
}
