﻿using System;
using HoytSoft.Common.Services;
using System.Threading;
using System.Diagnostics;

namespace SimpleService {
	class Program {
		static void Main(string[] args) {
			bool pleaseStop = false;

			ServiceBase.RunService(args, new HoytSoft.Common.Services.SimpleService(
				"SimpleServiceTest",
				"Simple Service Test",
				"Simple service test description",
				null,

				/* Start */
				delegate(HoytSoft.Common.Services.SimpleService Service, object Param) {
					while (!pleaseStop) {
						Debug.WriteLine("Running...");
						Thread.Sleep(1000);
					}
					Debug.WriteLine("Stopped");
				},

				/* Stop */
				delegate(HoytSoft.Common.Services.SimpleService Service, object Param) {
					Debug.WriteLine("Please stop...");
					pleaseStop = true;
				}
			));
		}
	}
}
