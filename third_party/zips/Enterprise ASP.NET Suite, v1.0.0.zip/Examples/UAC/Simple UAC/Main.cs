﻿using System;
using System.Windows.Forms;
using HoytSoft.Common.UAC;

namespace SimpleUAC {
	public partial class Main : Form {
		public Main() {
			InitializeComponent();
		}

		private void btnClose_Click(object sender, EventArgs e) {
			this.Close();
		}

		private void btnTask_Click(object sender, EventArgs e) {
			TaskResult result = null;
			if ((result = UAC.RunTask(new AdminTask())) != null && result.Result != Result.Success) {
				switch (result.Result) {
					case Result.Failed:
					case Result.Unknown:
						MessageBox.Show(this, "Task did not complete successfully.\r\n\r\nMessage: \r\n\r\n" + result.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
						break;
					case Result.Cancelled:
						MessageBox.Show(this, "Task was cancelled.", "Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
						break;
				}
			} else
				MessageBox.Show(this, "Task completed successfully!", "Success");
		}

		#region Administrative Tasks
		[Serializable]
		private class AdminTask : AbstractAdministrativeTask {
			public override TaskResult RunTask() {
				MessageBox.Show("Running on Vista: " + Utilities.IsReallyVista() + "\r\nIs 64-bit: " + Utilities.Is64Bit() + "\r\nIs WOW64: " + Utilities.IsWOW64() + "\r\nRunning elevated: " + Utilities.IsElevated(), "Administrative Task", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return new TaskResult(Result.Success);
			}
		}
		#endregion
	}
}
