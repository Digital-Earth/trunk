using System;
using System.Data;
using HoytSoft.Common;
using HoytSoft.Common.Web;

namespace AdvancedWebsite {

	public class Database : HoytSoft.Common.Data.Database {
		#region Login
		public static User CheckUser(string UserID) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				return CheckUser(cn, UserID, null, null);
			}
		}
		public static User CheckUser(string Login, string Password) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				return CheckUser(cn, null, Login, Password);
			}
		}
		public static User CheckUserByName(string Name, string UserID) {
			using (IDbConnection cn = getConnection(Name)) {
				return CheckUser(cn, UserID, null, null);
			}
		}
		public static User CheckUserByName(string Name, string Login, string Password) {
			using (IDbConnection cn = getConnection(getConnStr(Name))) {
				return CheckUser(cn, null, Login, Password);
			}
		}
		public static User CheckUser(IDbConnection Connection, string UserID, string Login, string Password) {
			if (Connection == null) 
				throw new NullReferenceException(NULL_CONNECTION_OBJ);

			try {
				IDbCommand cmd = null;

				using ((cmd = getCommandAsStoredProcedure("sp_check_login", ref Connection))) {
					if (!string.IsNullOrEmpty(UserID)) {
						int tmp;
						if (int.TryParse(UserID, out tmp))
							addParameterToCommand(ref cmd, "@UserID", SqlDbType.Int, tmp);
					} else {
						if (string.IsNullOrEmpty(Login) || string.IsNullOrEmpty(Password))
							return null;
						addParameterToCommand(ref cmd, "@Login", SqlDbType.NVarChar, 255, Login);
						addParameterToCommand(ref cmd, "@Password", SqlDbType.NVarChar, 255, Password);
					}
					
					if (Connection.State != ConnectionState.Open)
						Connection.Open();

					using (IDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
						if (!dr.Read()) {
							//If in test mode, skip actual login check (for now)
							//TO DO: Take this out once login table is added to db
							if (Settings.TestMode) {
								return new User(
									0, 
									Login, 
									"John", 
									"Doe"
								);
							}
							return null;
						}

						User user = new User(
							(int)dr["UserID"], 
							(string)dr["Login"], 
							(string)dr["FirstName"], 
							(string)dr["LastName"]
						);

						dr.Close();

						return user;
					}
				}
			} catch {
				if (Settings.DebugMode)
					throw;
				return null;
			}
		}
		#endregion

	}
}
