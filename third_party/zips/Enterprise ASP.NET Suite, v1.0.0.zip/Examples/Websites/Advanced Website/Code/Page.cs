﻿using System;
using HoytSoft.Common.Web;
using HoytSoft.Common.Configuration;
using System.Web.UI.WebControls;

namespace AdvancedWebsite {
	[PublicPage]
	public class PublicPage : Page {
	}

	public class Page : LocalizedPage {
		protected override void InitializeCulture() {
			base.InitializeCulture();

			string val = Request["ctl00$selCulture"];
			if (string.IsNullOrEmpty(val))
				return;

	        int lcid;
	        if (int.TryParse(val, out lcid))
	            this.SaveCulture(lcid, true);
		}

	}
}
