using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using HoytSoft.Common.Configuration;
using HoytSoft.Common;

namespace AdvancedWebsite {
	public partial class Email : Page {
		protected void Page_Load(object sender, EventArgs e) {

		}

		protected void btnSubmit_Click(object sender, EventArgs e) {
			Settings.EmailTemplates.SendMessage(
				new string[] {
					"{Name}", 
					"{Email}", 
					"{FriendName}", 
					"{FriendEmail}", 
					"{Link}"
				}, new string[] {
					SiteUser.FirstName + " " + SiteUser.LastName, 
					SiteUser.Email, 
					txtName.Text, 
					txtEmail.Text, 
					@"http://www.google.com/"
				},
				"EmailAFriend",
				true,
				txtEmail.Text
			);
		}
	}
}
