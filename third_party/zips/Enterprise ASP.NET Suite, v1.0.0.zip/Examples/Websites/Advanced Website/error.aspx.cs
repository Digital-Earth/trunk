using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;
using HoytSoft.Common;
using Resources;

namespace AdvancedWebsite {
	public partial class Error : HoytSoft.Common.Web.PublicSharedLocalizedPage {

		protected void Page_Load(object sender, EventArgs e) {
			if (Settings.DebugMode || this.IsAdministrator) {
				Exception exc = this.Server.GetLastError();
				if (exc != null && exc is System.Web.HttpUnhandledException) {
					if (exc is HttpUnhandledException && exc.InnerException != null)
						exc = exc.InnerException;

					this.ExceptionDetails.InnerText = exc.ToString();
					this.ExceptionDetails.Visible = true;
					this.Server.ClearError();
				}
			} else {
				this.ExceptionDetails.Visible = false;
			}

			string msg = string.Empty;
			string errTitle = string.Empty;

			switch (this.Response.StatusCode) {
				case 404:
					errTitle = TextResources.Page_Error_404_Title;
					msg = TextResources.Page_Error_404_Message;
					break;
				default:
					errTitle = TextResources.Page_Error_Generic_Title;
					msg = TextResources.Page_Error_Generic_Message;
					break;
			}

			this.ErrorTitle.InnerHtml = errTitle;
			this.Details.InnerHtml = msg;
			this.Details.Visible = true;
			this.ErrorTitle.Visible = true;
		}
	}
}
