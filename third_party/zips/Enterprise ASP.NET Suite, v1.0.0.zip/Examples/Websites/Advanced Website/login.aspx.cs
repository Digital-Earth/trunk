﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using HoytSoft.Common.Web;

namespace AdvancedWebsite {
	public partial class Login : PublicPage {
		#region Constants
		private const string
			LOGIN_INVALID = "Invalid login or password, please check your entries and try again."
		;
		#endregion

		#region Variables
		private string myRedirectURL = String.Empty;
		#endregion

		#region Properties
		public string RedirectURL {
			get { return this.myRedirectURL; }
			set { this.myRedirectURL = value; }
		}
		#endregion

		protected bool DoLogin(string UserName, string Password, bool RememberMe) {
			if (!string.IsNullOrEmpty(UserName) && !string.IsNullOrEmpty(Password) && this.Page is HoytSoft.Common.Web.Page) {
				HoytSoft.Common.Web.Page p = (this.Page as HoytSoft.Common.Web.Page);
				string redir = System.Web.Security.FormsAuthentication.GetRedirectUrl(UserName, true);
				User user = Database.CheckUser(UserName, Password);

				if (user != null) {
					LoginCurrentUser(user, RememberMe);
				} else {
					return false;
				}

				if (!string.IsNullOrEmpty(myRedirectURL)) {
					p.RedirectFromSecureSite(myRedirectURL, false);
				} else if (Request["ReturnUrl"] != null) {
					p.RedirectFromSecureSite(redir, false);
				} else {
					p.RedirectFromSecureSite("~/index.html", false);
				}
				return true;

			}
			return true;
		}

		///<summary>Recursively looks for a control in the hierarchy</summary>
		protected Control SuperFindControl(Control Parent, string Name) {
			if (Parent == null) {
				return null;
			}

			foreach (Control c in Parent.Controls) {
				if (!string.IsNullOrEmpty(c.ID) && Name.Equals(c.ID, StringComparison.InvariantCultureIgnoreCase)) {
					return c;
				} else {
					if (c.Controls != null && c.Controls.Count > 0) {
						Control ret = SuperFindControl(c, Name);
						if (ret != null)
							return ret;
					}
				}
			}
			return null;
		}

		protected void Page_Load(object sender, EventArgs e) {
			if (btnLoginSubmit != null && this.Page != null && this.Page is HoytSoft.Common.Web.Page) {
				// If member is already logged in, then redirect them to their content...
				HoytSoft.Common.Web.Page p = (this.Page as HoytSoft.Common.Web.Page);

				if (p.SiteUser != null && p.Authenticated)
					p.RedirectFromSecureSite("~/index.html", false);

				btnLoginSubmit.PostBackUrl = "/login.html";// p.FindPathToSecureSite("~/login.aspx");
			}

			btnLoginSubmit_Click(this, EventArgs.Empty);
		}

		protected void btnLoginSubmit_Click(object sender, System.EventArgs e) {
			bool rememberMe = false;
			string userName = null;
			string password = null;

			//Looks in various places for form input - from a previous page post, from a request string, 
			//and from the current page...
			if (this.Page.PreviousPage == null) {
				if (this.IsPostBack && txtLoginUserName != null && txtLoginPassword != null && txtLoginUserName.Value != null && txtLoginPassword.Value != null) {
					userName = txtLoginUserName.Value;
					password = txtLoginPassword.Value;
					if (chkLoginRememberMe != null)
						rememberMe = chkLoginRememberMe.Checked;
				}

				if (Request["txtLoginUserName"] != null && Request["txtLoginPassword"] != null) {
					userName = Request["txtLoginUserName"];
					password = Request["txtLoginPassword"];
					if (Request["chkLoginRememberMe"] != null)
						rememberMe = Request["chkLoginRememberMe"].Equals("on", StringComparison.InvariantCultureIgnoreCase);
				}
			} else {
				HtmlInputText txtUserName = (HtmlInputText)SuperFindControl(this.Page.PreviousPage, "txtLoginUserName");
				HtmlInputText txtPassword = (HtmlInputText)SuperFindControl(this.Page.PreviousPage, "txtLoginPassword");
				HtmlInputCheckBox chkRememberMe = (HtmlInputCheckBox)SuperFindControl(this.Page.PreviousPage, "chkLoginRememberMe");

				if (txtUserName != null) userName = txtUserName.Value;
				if (txtPassword != null) password = txtPassword.Value;
				if (chkRememberMe != null) rememberMe = chkRememberMe.Checked;
			}

			if (!string.IsNullOrEmpty(userName) && !string.IsNullOrEmpty(password) && !DoLogin(userName, password, rememberMe)) {
				this.spnLoginLabel.Visible = true;
				this.spnLoginLabel.InnerHtml = LOGIN_INVALID;

				if (txtLoginUserName != null) txtLoginUserName.Value = userName;
				if (txtLoginPassword != null) txtLoginPassword.Value = password;
				if (chkLoginRememberMe != null) chkLoginRememberMe.Checked = rememberMe;
			}
		}
	}
}
