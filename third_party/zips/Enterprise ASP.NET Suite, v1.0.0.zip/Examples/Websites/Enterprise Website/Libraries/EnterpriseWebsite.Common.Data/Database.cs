using System;
using System.Data;
using HoytSoft.Common;
using HoytSoft.Common.Web;

namespace EnterpriseWebsite.Common.Data {
	public class Weather {
		#region Variables
		private string zipCode;
		private int minTemp, maxTemp;
		#endregion

		#region Constructors
		public Weather(string ZipCode, int MinTemp, int MaxTemp) {
			this.zipCode = ZipCode;
			this.minTemp = MinTemp;
			this.maxTemp = MaxTemp;
		}
		#endregion

		#region Properties
		public string ZipCode {
			get { return this.zipCode; }
		}

		public int MinTemp {
			get { return this.minTemp; }
		}

		public int MaxTemp {
			get { return this.maxTemp; }
		}
		#endregion
	}

	public class Database : HoytSoft.Common.Data.Database {
		#region Delegates
		public delegate void DataHandlerDelegate(IDataReader dr);
		#endregion

		#region Login
		public static User CheckUser(string UserID) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				return CheckUser(cn, UserID, null, null);
			}
		}
		public static User CheckUser(string Login, string Password) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				return CheckUser(cn, null, Login, Password);
			}
		}
		public static User CheckUserByName(string Name, string UserID) {
			using (IDbConnection cn = getConnection(Name)) {
				return CheckUser(cn, UserID, null, null);
			}
		}
		public static User CheckUserByName(string Name, string Login, string Password) {
			using (IDbConnection cn = getConnection(getConnStr(Name))) {
				return CheckUser(cn, null, Login, Password);
			}
		}
		public static User CheckUser(IDbConnection Connection, string UserID, string Login, string Password) {
			if (Connection == null) 
				throw new NullReferenceException(NULL_CONNECTION_OBJ);

			try {
				IDbCommand cmd = null;

				using ((cmd = getCommandAsStoredProcedure("sp_check_login", ref Connection))) {
					if (!string.IsNullOrEmpty(UserID)) {
						int tmp;
						if (int.TryParse(UserID, out tmp))
							addParameterToCommand(ref cmd, "@UserID", SqlDbType.Int, tmp);
					} else {
						if (string.IsNullOrEmpty(Login) || string.IsNullOrEmpty(Password))
							return null;
						addParameterToCommand(ref cmd, "@Login", SqlDbType.NVarChar, 255, Login);
						addParameterToCommand(ref cmd, "@Password", SqlDbType.NVarChar, 255, Password);
					}
					
					if (Connection.State != ConnectionState.Open)
						Connection.Open();

					using (IDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
						if (!dr.Read())
							return null;

						User user = new User(
							(int)dr["UserID"], 
							(string)dr["Login"], 
							(string)dr["FirstName"], 
							(string)dr["LastName"]
						);

						user.Zip = (string)dr["ZipCode"];

						dr.Close();

						return user;
					}
				}
			} catch {
				if (Settings.DebugMode)
					throw;
				return null;
			}
		}
		#endregion

		#region Weather
		public static void ProcessAllZipCodes(DataHandlerDelegate Handler) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				ProcessAllZipCodes(cn, Handler);
			}
		}
		public static void ProcessAllZipCodesByName(string Name, DataHandlerDelegate Handler) {
			using (IDbConnection cn = getConnection(Name)) {
				ProcessAllZipCodes(cn, Handler);
			}
		}
		public static void ProcessAllZipCodes(IDbConnection Connection, DataHandlerDelegate Handler) {
			try {
				if (Connection == null)
					throw new NullReferenceException(NULL_CONNECTION_OBJ);
				if (Handler == null)
					throw new NullReferenceException("Missing handler");

				IDbCommand cmd = null;

				using ((cmd = getCommandAsStoredProcedure("sp_get_all_zipcodes", ref Connection))) {
					if (Connection.State != ConnectionState.Open)
						Connection.Open();

					using (IDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
						Handler(dr);
						dr.Close();
					}
				}
			} catch {
				if (Settings.DebugMode)
					throw;
			}
		}

		public static bool UpdateWeather(string ZipCode, int MinTemp, int MaxTemp) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				return UpdateWeather(cn, ZipCode, MinTemp, MaxTemp);
			}
		}
		public static bool UpdateWeatherByName(string Name, string ZipCode, int MinTemp, int MaxTemp) {
			using (IDbConnection cn = getConnection(Name)) {
				return UpdateWeather(cn, ZipCode, MinTemp, MaxTemp);
			}
		}
		public static bool UpdateWeather(IDbConnection Connection, string ZipCode, int MinTemp, int MaxTemp) {
			try {
				if (Connection == null)
					throw new NullReferenceException(NULL_CONNECTION_OBJ);

				IDbCommand cmd = null;

				using ((cmd = getCommandAsStoredProcedure("sp_update_weather", ref Connection))) {
					addParameterToCommand(ref cmd, "@ZipCode", SqlDbType.NVarChar, 10, ZipCode);
					addParameterToCommand(ref cmd, "@MinTemp", SqlDbType.Int, MinTemp);
					addParameterToCommand(ref cmd, "@MaxTemp", SqlDbType.Int, MaxTemp);

					if (Connection.State != ConnectionState.Open)
						Connection.Open();

					return (cmd.ExecuteNonQuery() > 0);
				}
			} catch {
				if (Settings.DebugMode)
					throw;
				return false;
			}
		}

		public static Weather GetWeather(int UserID) {
			using (IDbConnection cn = getConnection(DefaultConnectionString)) {
				return GetWeather(cn, UserID);
			}
		}
		public static Weather GetWeatherByName(string Name, int UserID) {
			using (IDbConnection cn = getConnection(Name)) {
				return GetWeather(cn, UserID);
			}
		}
		public static Weather GetWeather(IDbConnection Connection, int UserID) {
			try {
				if (Connection == null)
					throw new NullReferenceException(NULL_CONNECTION_OBJ);

				IDbCommand cmd = null;
				Weather info = null;

				using ((cmd = getCommandAsStoredProcedure("sp_get_weather", ref Connection))) {
					addParameterToCommand(ref cmd, "@UserID", SqlDbType.Int, UserID);

					if (Connection.State != ConnectionState.Open)
						Connection.Open();

					using (IDataReader dr = cmd.ExecuteReader()) {
						if (dr.Read()) {
							info = new Weather(
								(string)dr["ZipCode"],
								(int)dr["MinTemp"],
								(int)dr["MaxTemp"]
							);
						}
						dr.Close();
					}

					return info;
				}
			} catch {
				if (Settings.DebugMode)
					throw;
				return null;
			}
		}
		#endregion
	}
}
