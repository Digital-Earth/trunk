The Enterprise Example brings everything together. It's a simple app that uses a Windows service to download weather information every night. When the user logs in, the temperature of the zipcode where they live is displayed.

When you fire this up, you'll see the standard HoytSoft libraries, some common enterprise example libraries, the weather service, and the website.

To properly run this example, please follow these steps:

	1. In SQL Server Management Studio, for a SQL Server 2005 instance or later, run Database/Database.sql
	   This will setup the tables, stored procedures, and some sample data.

	2. Open up Enterprise Example.sln and in the solution Services folder, run the Weather service. 
	   This will download the latest forecast information for all zipcodes in the database.

	3. Run the website project and navigate to http://localhost:8222/index.html to see the site. 
	   You can login using:

	      Username: john
	      Password: doe

The following folder structure is recommended:

	Database

	  Holds database creation/administration scripts.

	Libraries

	  Holds application-specific libraries such as your data access layer.

	Services

	  Holds any Windows services that must be run continuously in the background.

	Site

	  Holds the actual website.