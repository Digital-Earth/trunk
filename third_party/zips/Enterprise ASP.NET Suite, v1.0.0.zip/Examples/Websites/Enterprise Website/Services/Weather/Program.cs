﻿using System;
using System.IO;
using System.Xml;
using System.Data;
using System.Threading;
using System.Reflection;
using System.Diagnostics;
using System.Collections.Generic;
using HoytSoft.Common;
using HoytSoft.Common.Services;
using EnterpriseWebsite.Common.Data;

namespace Weather {
	class Program {

		static void Main(string[] args) {
			bool pleaseStop = false;
			ManualResetEvent evt = new ManualResetEvent(false);
			ManualResetEvent appEvt = new ManualResetEvent(false);

			string config = new FileInfo(Path.Combine(new DirectoryInfo(Assembly.GetEntryAssembly().Location).FullName, @"..\..\..\..\..\Site\Web.common.config")).FullName;
			Debug.WriteLine("Using configuration file: " + config);
			Settings.Reload(config);

			/*
			 * This service is not meant to be a perfect example. You would probably want to do something 
			 * more intelligent regarding when to run this task (instead of checking every hour if it's 
			 * midnight or later).
			 * 
			 * However, it's still a good example of building a proper service. Note the use of the 
			 * ManualResetEvent objects to enable proper inter-thread communication/notification. 
			 * 
			 * The "appEvt" object is important because when RunService() ends, the app ends, even in 
			 * debug mode (i.e. when not running through the service MMC snap-in w/ the SCM). This 
			 * ensures that the behavior for testing is the same as when run through the SCM.
			 * 
			 * "appEvt" essentially waits for the main application code (in the start delegate) to 
			 * exit.
			 * 
			 * If you use a SimpleService object, you should be able to see how easy it would be to 
			 * localize the title and description of your service.
			 * 
			 * This service just calls a weather forecast service at midnight and updates our database 
			 * accordingly.
			 * 
			 * By checking Service.Debug in this example, we're checking for debug mode. If we are in 
			 * debug mode (e.g. we're running this from Visual Studio), then we define some special 
			 * behavior. For instance, we don't wait for midnight and instead proceed. We also 
			 * don't recheck the hour every hour - we wait for 2 minutes and then loop back around.
			 */
			ServiceBase.RunService(args, new SimpleService(
				"EnterpriseApplication_WeatherService",
				"Enterprise Application Weather Service",
				"Example of calling a weather service and updating a database with the information.",
				null,

				/* Start */

				delegate(SimpleService Service, object Param) {
					try {
						while (!pleaseStop) {

							//Check the time - if debugging, go ahead and execute
							if (Service.Debug || DateTime.Now.Hour == 0) {
								//Prepare this object to invoke the webservice later
								using (WebServices.NDFD.ndfdXML c = new Weather.WebServices.NDFD.ndfdXML()) {
									c.Timeout = 1000 * 5;

									//Gets all the zip codes from the database so we can find out the 
									//forecast for each
									Database.ProcessAllZipCodes(delegate(IDataReader dr) {
										while (dr.Read()) {
											try {
												string sZip = (string)dr["ZipCode"];

												//Look up latitude, longitude
												string sLatLon = c.LatLonListZipCode(sZip);

												//Returns an XML doc - parse out the lat/lon
												XmlDocument doc = new XmlDocument();
												doc.LoadXml(sLatLon);

												//Parse out the lat/lon for this zipcode
												XmlNode xn = null;
												if ((xn = doc.SelectSingleNode("dwml/latLonList")) != null && !string.IsNullOrEmpty(xn.InnerText)) {
													sLatLon = xn.InnerText.Trim();
													string[] split = xn.InnerText.Trim().Split(',');
													if (split != null && split.Length >= 2) {
														decimal lat = decimal.Parse(split[0]);
														decimal lon = decimal.Parse(split[1]);

														//Get the weather for this guy
														int maxTmp = int.MinValue;
														int minTmp = int.MinValue;
														string sForecast = c.NDFDgenByDay(lat, lon, DateTime.Now, "1", Weather.WebServices.NDFD.formatType.Item24hourly);
														doc.LoadXml(sForecast);

														//Attempt to load the result
														//Note: Sometimes the forecast web service does not return 
														//forecast information. In this case we skip past it. 
														//In a real service, you should do something more 
														//intelligent (perhaps queue it up to check again 
														//later).
														if (
															   (xn = doc.SelectSingleNode("dwml/data/parameters/temperature[@type='maximum']/value")) != null
															&& !string.IsNullOrEmpty(xn.InnerText)
															&& int.TryParse(xn.InnerText.Trim(), out maxTmp)
															&& (xn = doc.SelectSingleNode("dwml/data/parameters/temperature[@type='minimum']/value")) != null
															&& !string.IsNullOrEmpty(xn.InnerText)
															&& int.TryParse(xn.InnerText.Trim(), out minTmp)
														) {
															Database.UpdateWeather(sZip, minTmp, maxTmp);
														}
													}
												}
											} finally {
											}
										}
									});
								}
							}

							//Execute once an hour or every 2 minutes if debugging
							evt.WaitOne(Service.Debug ? 1000 * 60 * 2 /* 2 Minutes */ : 1000 * 60 * 60 /* 60 Minutes */, true);
						}
					} catch(Exception e) {
						//If debugging, then write out information about the exception 
						//and throw it anyway
						if (Service.Debug) {
							Debug.WriteLine(e);
							throw e;
						}
					} finally {
						//Tell the application it's okay to exit and cleanup
						appEvt.Set();
					}
				},

				/* Stop */

				delegate(SimpleService Service, object Param) {
					//Ask politely for the service to stop
					pleaseStop = true;
					//If the service is waiting in evt.WaitOne(), then snap out of it!
					evt.Set();
				}
			));

			appEvt.WaitOne();
			appEvt.Close();
			evt.Close();
		}
	}
}
