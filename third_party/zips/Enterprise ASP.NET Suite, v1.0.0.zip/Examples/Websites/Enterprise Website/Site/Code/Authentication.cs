﻿using System;
using System.Data;
using HoytSoft.Common.Web;
using System.Collections.Generic;
using EnterpriseWebsite.Common.Data;

namespace EnterpriseWebsite {
	public class Authentication : AbstractFormsAuthenticationCallback {
		public override string[] CheckRoles(IUser User) {
			if (User == null)
				return base.CheckRoles(User);

			List<string> roles = new List<string>(1);
			roles.Add("user");

			if (User.IsAdministrator)
				roles.Add("administrator");

			return roles.ToArray();
		}

		public override IUser CheckLogin(string Login, string Password) {
			//Try to load a user based on login and password - return null if unable to load
			return Database.CheckUser(Login, Password);
		}

		public override IUser CheckLogin(string UserID) {
			//Automatically log user back in - from "remember me" option - return null if unable to load
			return Database.CheckUser(UserID);
		}
	}
}
