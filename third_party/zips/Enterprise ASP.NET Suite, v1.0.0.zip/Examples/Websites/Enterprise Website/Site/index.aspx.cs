using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EnterpriseWebsite.Common.Data;

namespace EnterpriseWebsite {
	public partial class Index : PublicPage {
		private Weather weather;
		private bool weatherLoaded = false;

		protected void Page_Load(object sender, EventArgs e) {

		}

		public bool HasWeather {
			get {
				return (this.Weather != null);
			}
		}

		public Weather Weather {
			get {
				if (weatherLoaded)
					return weather;

				weatherLoaded = true;
				if (this.SiteUser != null)
					weather = Database.GetWeather(this.SiteUser.ID);
				else
					weather = null;

				return weather;
			}
		}
	}
}
