﻿using System;
using System.Diagnostics;
using HoytSoft.Common;
using HoytSoft.Common.Data;
using HoytSoft.Common.Configuration.Internal;

namespace SimpleWebsite {
	public partial class Index : HoytSoft.Common.Web.PublicSharedPage {
		protected void Page_Load(object sender, EventArgs e) {
			lblConnStr1.Text = Database.DefaultConnectionString;
			lblConnStr2.Text = Settings.From<ConnectionStringSettings>(Settings.Section.ConnectionString).LookUp(null);
			lblConnStr3.Text = Settings.From<ConnectionStringSettings>(Settings.Section.ConnectionString).LookUp("OtherTestDB");
		}
	}
}
