#region Copyright/Legal Notices
/***************************************************
 * Copyright � 2007 HoytSoft. All rights reserved. 
 *	Please see included license for more details.
 ***************************************************/
#endregion

using System;

namespace HoytSoft.Common.Gateways.LinkPoint {
	public class LinkPointUSState : USStateInformation {
		#region Constructors
		public LinkPointUSState(USState USState)
			: base(USState) {
		}
		#endregion
	}
}
