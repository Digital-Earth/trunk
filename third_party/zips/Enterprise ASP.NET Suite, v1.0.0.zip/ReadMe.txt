Thank you for downloading the Enterprise ASP.NET Suite!

We welcome any community improvements, feature requests, issues/bug notifications, etc. We want to make this the best out there and make your job as a developer that much easier!

Please check out the examples. In particular, go to the Examples/Websites/Enterprise Website/ folder and check out the Enterprise Website example. It makes use of many of the features this suite has to offer including logical directory structure and layout.

Also please read the included license agreement.

Thank you again!






Please send all bug fixes, feature requests, etc. to questions@hoytsoft.org