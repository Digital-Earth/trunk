/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
//
// ExGripData.h
//

#ifndef EX_GRIP_DATA_H_
#define EX_GRIP_DATA_H_

//#include "DbGsManager.h"
#include "Gi/GiDrawableImpl.h"
#include "DbEntity.h" // for dDbGripDataPtrArray
#include "DbGrip.h"
//#include "DbUserIO.h"

typedef OdSmartPtr<class OdExGripData> OdExGripDataPtr;
typedef OdArray<OdExGripDataPtr> OdExGripDataPtrArray;

class OdExGripData : public OdGiDrawableImpl<>
{
private:
  //OD_COPY_DISABLED(OdExGripData)
  OdExGripData(const OdExGripData &);
  OdExGripData& operator=(const OdExGripData &);

  OdDbStub* id() const //Teigha.Cloud: should return NULL for non-resident objects like grip point
  {
    ODA_ASSERT_ONCE(!OdGiDrawableImpl<>::id()); // test
    return NULL; // non-resident
  }
protected:
  OdExGripData()
    : m_status(OdDbGripOperations::kWarmGrip)
    , m_bInvisible(false)
    , m_bShared(false)
    , m_point(OdGePoint3d::kOrigin)
  {
  }
  virtual ~OdExGripData()
  {
  }

public:
  OdDbGripOperations::DrawType status() const 
  { 
    return m_status; 
  }
  bool isInvisible() const 
  { 
    return m_bInvisible; 
  }
  bool isShared() const 
  { 
    return m_bShared; 
  }
  OdGePoint3d point() const 
  { 
    return m_point; 
  }
  OdDbGripDataPtr data() const 
  { 
    return m_pData; 
  }
  OdDbStub* entityId() const // id() should return NULL for non-resident objects like grip point
  { 
    return m_entPath.objectIds().last(); 
  }
  bool entPath(OdDbBaseFullSubentPath *pPath = NULL) const
  {
    if (pPath)
      *pPath = m_entPath;
    return m_entPath.subentId() != OdDbSubentId();
  }

  void setStatus(OdDbGripOperations::DrawType val) 
  { 
    m_status = val; 
  }
  void setInvisible(bool val) 
  { 
    m_bInvisible = val; 
  }
  void setShared(bool val) 
  { 
    m_bShared = val; 
  }

protected:
  OdDbGripOperations::DrawType m_status;
  bool m_bInvisible;
  bool m_bShared;
  OdGePoint3d m_point;
  OdDbGripDataPtr m_pData;
  OdDbBaseFullSubentPath m_entPath;
};

#endif // EX_GRIP_DATA_H_
