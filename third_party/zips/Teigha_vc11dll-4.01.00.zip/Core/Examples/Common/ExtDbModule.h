/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
//
// ExtDbModule.h
//

#ifndef __EXTDB_MODULE__H__
#define __EXTDB_MODULE__H__

#include "RxModule.h"
#include "RxSystemServices.h"
#include "DbBaseHostAppServices.h"
#include "Gs/Gs.h"
#include "Gs/GsBaseVectorizeDevice.h"
#include "Gs/GsDCRectArray.h"
#include "StringArray.h"
#include "SSet.h"
#include "DbEntity.h" // for dDbGripDataPtrArray
#include "DbGrip.h"
#include "Ed/EdCommandContext.h"

#include "DbUnitsFormatter.h"  // TODO DbBaseDatabaseUnitsFormatter.h
#define OdDbBaseDatabaseUnitsFormatter OdDbUnitsFormatter

class ODRX_ABSTRACT OdExtDbModule : public OdRxModule
{
public:
  //ODRX_DECLARE_MEMBERS(OdExtDbModule);

  // init issues
  virtual void setBaseHostAppServices(OdDbBaseHostAppServices* pServices) = 0;
  virtual void initOdExtPE() = 0;
  virtual void uninitOdExtPE() = 0;
  
  virtual OdStringArray resetRegVariables() = 0; // set to default values

  virtual bool getPreviewBitmap(const OdString& fileName, 
                                class OdBinaryData& dataBmp) = 0; // out

  // load / save issues
  virtual OdRxObjectPtr readFile(const OdString& fileName, 
                                 Oda::FileShareMode shareMode = Oda::kShareDenyWrite) = 0;
  virtual OdRxObjectPtr createUninitializedDatabase() = 0;
  virtual bool loadToUninitializedDatabase(OdRxObjectPtr pRxDb, 
                                           const OdString& fileName, 
                                           Oda::FileShareMode shareMode = Oda::kShareDenyWrite) = 0;
  virtual bool writeFile(const OdString& fileName, OdRxObjectPtr pRxDatabase) = 0;
  // Cloud command command context issues
  virtual class OdEdBaseIO* baseIO(OdEdCommandContext* ctx) = 0;
  virtual OdEdCommandContextPtr cloneCommandContext(OdEdCommandContext* ctx,
                                                    OdEdBaseIO* pIOStream = NULL, 
                                                    OdRxObject* pRxDatabase = NULL) = 0;
  // render issues
  // for Dgn active model(group) only
  virtual bool getVisibleLayoutViewIds(OdRxObject* pRxDatabase,
                                       OdDbStub*& idActiveLayoutView, // out
                                       OdDbStubPtrArray& idsLayoutViews, OdGsDCRectArray& rects) = 0;
  // for all models (return false to use standard way (via OdDbBaseDatabasePE & OdDbBaseLayoutPE))
  virtual bool getLayoutViewNamesAndIds(OdRxObject* pRxDatabase,
                                        OdStringArray& namesLayoutView,
                                        OdDbStubPtrArray& idsLayoutView,
                                        OdString* pActiveLayoutViewName = NULL,
                                        bool bOneForModel = true,
                                        OdGsDCRectArray* pRects = NULL) = 0;
  virtual OdGsDevicePtr createDevice(OdGsModulePtr pGs, OdRxObjectPtr pRxDatabase) = 0;
  virtual OdGsDevicePtr createBitmapDevice(OdGsModulePtr pGs, OdRxObjectPtr pRxDatabase) = 0;
  virtual OdGsDevicePtr takeUnderlyingDeviceAndViewports(OdGsDevicePtr pGsDevice,
                                                         OdArray<OdGsViewPtr>& viewportsToDeleteAfterUpdate) = 0; // out
  virtual void enableGsModel(class OdGiDefaultContext* pCtx, bool bGsCache) = 0;
  virtual bool getModelBackground(OdRxObject* pRxDatabase, ODCOLORREF& clrBackground, 
                                                           ODGSPALETTE* pPalette = NULL) = 0;
  virtual bool setModelBackground(OdRxObject* pRxDatabase, ODCOLORREF clrBackground) = 0;

  // zoom issues
  virtual OdGsView* getActiveGsView(OdGsDevice* pGsDevice) = 0;
  virtual OdGsModel* getGsModel(OdGsDevice* pGsDevice) = 0;
  virtual bool getUcsPlane(OdRxObject* pRxDatabase, OdGsView* pGsView, class OdGePlane& plane) = 0;
  virtual OdDbBaseDatabaseUnitsFormatter* getFormatter(OdRxObject* pRxDatabase) = 0;

  // selection issues
  virtual OdSelectionSetPtr createSelectionSet(OdRxObject* pRxDatabase) = 0;
  virtual OdSelectionSetPtr select(OdGsView* gsView,
                                   int nPoints,
                                   const OdGePoint3d* wcsPts,
                                   OdDbVisualSelection::Mode mode = OdDbVisualSelection::kCrossing,
                                   OdDbVisualSelection::SubentSelectionMode sm = OdDbVisualSelection::kDisableSubents,
                                   const OdRxObject* pFilter = NULL) = 0;
  virtual void getVisibleAllIds(OdRxObject* pRxDatabase, OdDbStubPtrArray& ids) = 0;
  virtual OdDbStub* getVisibleLastId(OdRxObject* pRxDatabase) = 0;
  virtual void highlight(OdGsView* gsView, bool bValue,
                         OdDbStub* id, const OdDbBaseFullSubentPath* pPath) = 0;
  virtual bool getGripPoints(OdDbStub* id,
                             OdGePoint3dArray& gripPoints,
                             class OdEdCommandContext* pCmdCtx = NULL) = 0;
  virtual bool getGripPoints(OdDbStub* id,
                             OdDbGripDataPtrArray& grips,
                             double curViewUnitSize,
                             int gripSize,
                             const OdGeVector3d& curViewDir,
                             int bitFlags = 0) = 0;
  virtual bool getGripPointsAtSubentPath(const OdDbBaseFullSubentPath& path, 
                                         OdDbGripDataPtrArray& grips,
                                         double curViewUnitSize, 
                                         int gripSize,
                                         const OdGeVector3d& curViewDir, 
                                         OdUInt32 bitflags = 0) = 0;
  virtual bool isErased(OdDbStub* id) = 0;
  virtual class OdDbHandle getElementHandle(OdDbStub* id) = 0;
  virtual OdString getElementClassName(OdDbStub* id) = 0;

  // command issues
  virtual bool cmdErase(class OdEdCommandContext* pCmdCtx) = 0;
};

//typedef OdSmartPtr<OdExtDbModule> OdExtDbModulePtr;
//
// way to use module without linking - impossible if TG is missing
// (via loading to OdRxModulePtr and next convertion)
inline OdExtDbModule* OdExtDbModule_cast(OdRxModule* pExtDb)
{
  return static_cast<OdExtDbModule*>(pExtDb);
}
inline OdExtDbModule* OdExtDbModule_cast(OdRxModulePtr pExtDb)
{
  return OdExtDbModule_cast(pExtDb.get());
}

inline OdString getExtDbModuleNameByExtension(const OdString& sExt)
{
  if (sExt == L"dgn")
    return L"TD_DgnDb.tx";
  if (sExt == L"rvt" || sExt == L"rfa")
    return L"TD_BimDb.tx";
  ODA_ASSERT_ONCE(   sExt == L"dwg" || sExt == L"dxf" || sExt == L"dxb"  
                  || sExt == L"dws" || sExt == L"dwt");
  return OdString::kEmpty;
}

inline OdRxModulePtr loadExtDbModuleByExtension(const OdString& sExt)
{
  OdString sModuleName = getExtDbModuleNameByExtension(sExt);
  if (sModuleName.isEmpty())
    return OdRxModulePtr();
  return ::odrxDynamicLinker()->loadModule(sModuleName);
}

inline OdString getExtDbModuleName(OdRxObject* pRxDatabase)
{
  ODA_ASSERT_ONCE(pRxDatabase);
  if (!pRxDatabase)
    return OdString::kEmpty;

  OdRxClass* pClass = pRxDatabase->isA();
  OdString sClassName = pClass->name();
  ODA_ASSERT_ONCE(!sClassName.isEmpty());
  if (sClassName.isEmpty())
    return OdString::kEmpty;
  if (sClassName == L"OdDbDatabase")
    return OdString::kEmpty;
  if (sClassName == L"OdDgDatabase")
    return L"TD_DgnDb.tx";
  if (sClassName == L"OdBmDatabase")
    return L"TD_BimDb.tx";
  ODA_FAIL_ONCE(); // TODO
  return OdString::kEmpty;
}

inline OdRxModulePtr getExtDbModule(OdRxObject* pRxDatabase)
{
  OdString sModuleName = getExtDbModuleName(pRxDatabase);
  if (sModuleName.isEmpty())
    return OdRxModulePtr();
  return ::odrxDynamicLinker()->loadModule(sModuleName);
}

#endif // __EXTDB_MODULE__H__
