/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

#include <stdlib.h>
#include "OdAlloc.h"
#include "OdAllocExport.h"
#include <new>

// Duplicate symbol link errors result using PocketPC if we define our own new & delete
#if !defined(_WIN32_WCE) 

#ifdef _MSC_VER
#pragma warning(disable: 4290)  // C++ exception spec. ignored
#endif

//#define _DEBUG_ALLOC_CHECK
#define _ALLOC_ALIGNMENT 8
#define _ALLOCATED_VIA_SCALAR_NEW 1
#define _ALLOCATED_VIA_VECTOR_NEW 2

#ifdef _DEBUG_ALLOC_CHECK
#include <cassert>
#endif

void* operator new (size_t size) throw(std::bad_alloc)
{
#ifdef _DEBUG_ALLOC_CHECK
  size += _ALLOC_ALIGNMENT;
  char* p = (char*)::odrxAlloc(size);
  *p = _ALLOCATED_VIA_SCALAR_NEW;
  return p + _ALLOC_ALIGNMENT;
#else
  return ::odrxAlloc(size);
#endif
}

void operator delete (void *p) throw()
{
  if (!p) return;
#ifdef _DEBUG_ALLOC_CHECK
  char* pi = (char*)p;
  pi -= _ALLOC_ALIGNMENT;
  p = pi;
  if (*pi != _ALLOCATED_VIA_SCALAR_NEW) 
  {
    assert(false);
  }
#endif
  ::odrxFree(p);
}

void* operator new[] (size_t size) throw(std::bad_alloc)
{
#ifdef _DEBUG_ALLOC_CHECK
  size += _ALLOC_ALIGNMENT;
  char* p = (char*)::odrxAlloc(size);
  *p = _ALLOCATED_VIA_VECTOR_NEW;
  return p + _ALLOC_ALIGNMENT;
#else
  return ::odrxAlloc(size);
#endif
}

void operator delete[] (void *p) throw()
{
  if (!p) return;
#ifdef _DEBUG_ALLOC_CHECK
  char* pi = (char*)p;
  pi -= _ALLOC_ALIGNMENT;
  p = pi;
  if (*pi != _ALLOCATED_VIA_VECTOR_NEW) 
  {
    assert(false);
  }
#endif
  ::odrxFree(p);
}

#ifndef __BCPLUSPLUS__
void *operator new(size_t size, const std::nothrow_t&) throw()
{
  return operator new(size);
}
void * operator new[](::size_t count, const std::nothrow_t&) throw()
{
  return operator new[](count);
}
void operator delete[](void *ptr, const std::nothrow_t&) throw()
{
  operator delete[](ptr);
}
void operator delete(void *ptr, const std::nothrow_t&) throw()
{
  operator delete(ptr);
}
#endif

#endif

// Support _CRTDBG_MAP_ALLOC memory allocation
//
#if (_MSC_VER >= 1200) && defined(_DEBUG) && defined(_CRTDBG_MAP_ALLOC)

extern "C"
{
  extern _CRTIMP void * __cdecl _malloc_dbg(size_t, int, const char *, int);
}

ALLOCDLL_EXPORT void* __cdecl operator new(size_t size, int type, const char* fname, int line)
{
#ifdef _DEBUG_ALLOC_CHECK
  char* p = (char*)_malloc_dbg( size + _ALLOC_ALIGNMENT, type, fname, line );
  *p = _ALLOCATED_VIA_SCALAR_NEW;
  return p + _ALLOC_ALIGNMENT;
#else
  return _malloc_dbg(size, type, fname, line);
#endif
}

ALLOCDLL_EXPORT void* __cdecl operator new[](size_t size, int type, const char* fname, int line)
{
#ifdef _DEBUG_ALLOC_CHECK
  char* p = (char*)operator new(size, type, fname, line);
  *(p - _ALLOC_ALIGNMENT) = _ALLOCATED_VIA_VECTOR_NEW;
  return p;
#else
  return operator new(size, type, fname, line);
#endif
}

#else //_CRTDBG_MAP_ALLOC

#ifdef _MSC_VER
#define TD_CDECL __cdecl
#else
#define TD_CDECL
#endif

ALLOCDLL_EXPORT void* TD_CDECL operator new(size_t size, int, const char*,int)
{
  return ::operator new(size);
}

ALLOCDLL_EXPORT void* TD_CDECL operator new[](size_t size, int, const char*, int)
{
  return ::operator new[](size);
}

#endif //_CRTDBG_MAP_ALLOC
