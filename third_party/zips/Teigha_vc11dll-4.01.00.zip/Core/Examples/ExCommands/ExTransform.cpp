/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "DbCurve.h"
#include "DbEntity.h"
#include "DbJoinEntityPE.h"

void _Move_func(OdEdCommandContext* pCmdCtx)
{

  struct MoveTracker : public OdStaticRxObject<OdEdPointTracker>
  {
    OdArray<OdDbEntityPtr>  m_ents;
    OdGePoint3d             m_ptBase;

    MoveTracker(OdGePoint3d ptBase, OdDbSelectionSet* pSSet)
      : m_ptBase(ptBase)
    {
      OdDbSelectionSetIteratorPtr pIter = pSSet->newIterator();

      while (!pIter->done())
      {
        OdDbObjectId objId  = pIter->objectId();
        OdDbEntityPtr pEnt  = objId.openObject(OdDb::kForWrite);

        if (!pEnt.isNull())
        {
          OdDbEntityPtr pSubEnt;
          if (pIter->subentCount() == 0)
          {
            pSubEnt = pEnt->clone();
            m_ents.push_back(pSubEnt);
          }
          else
          {
            OdDbFullSubentPath pathSubent;
            OdDbFullSubentPathArray arrPaths;

            for (unsigned int i = 0; i < pIter->subentCount(); i++)
            {
              pIter->getSubentity(i,pathSubent);
              pSubEnt = pEnt->subentPtr(pathSubent);
              if (!pSubEnt.isNull())
                m_ents.push_back(pSubEnt);
            }
          }
        }
        pIter->next();
      }
    }

    virtual void setValue(const OdGePoint3d& value)
    {
      OdGeMatrix3d matOffset;
      matOffset.setTranslation(value - m_ptBase);
      m_ptBase = value;
      for ( int i = m_ents.size() - 1; i >= 0; --i)
      {
        m_ents[i]->transformBy(matOffset);
      }
    }

    virtual int addDrawables(OdGsView* pView)
    {
      for ( int i = m_ents.size() - 1; i >= 0; --i)
      {
        pView->add(m_ents[i], 0);
      }
      return 1;
    }

    virtual void removeDrawables(OdGsView* pView)
    {
      for ( int i = m_ents.size() - 1; i >= 0; --i)
      {
        pView->erase(m_ents[i]);
      }
    }

  };


  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdSmartPtr<OdDbUserIO> pIO = pDbCmdCtx->userIO();
  OdDbSelectionSetPtr pSSet = pIO->select(L"Select objects:", 
                                          OdEd::kSelAllowObjects | 
                                          OdEd::kSelAllowSubents |
                                          OdEd::kSelLeaveHighlighted);

  if (pSSet->numEntities())
  {
    OdGePoint3d ptBase   = pIO->getPoint(L"Specify base point:");
    MoveTracker tracker(ptBase, pSSet);
    OdGePoint3d ptOffset = pIO->getPoint(L"Specify second point:", OdEd::kGptRubberBand, 0, OdString::kEmpty, &tracker);

    OdGeMatrix3d matOffset;
    matOffset.setTranslation(ptOffset - ptBase);
    OdDbSelectionSetIteratorPtr pIter = pSSet->newIterator();

    OdDbDatabasePtr pDb = pDbCmdCtx->database();
    pDb->startTransaction();
    while (!pIter->done())
    {
      OdDbObjectId objId  = pIter->objectId();
      OdDbEntityPtr pEnt  = objId.openObject(OdDb::kForWrite);

      if (!pEnt.isNull())
      {
        if (pIter->subentCount())
        {
          OdDbFullSubentPath pathSubent;
          OdDbFullSubentPathArray arrPaths;

          for (unsigned int i = 0; i < pIter->subentCount(); i++)
          {
            pIter->getSubentity(i,pathSubent);
            arrPaths.push_back(pathSubent);
          }

          pEnt->transformSubentPathsBy(arrPaths, matOffset);
        }
        else
          pEnt->transformBy(matOffset);
      }

      pIter->next();
    }
    pDb->endTransaction();
  }
}

void _Scale_func(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdSmartPtr<OdDbUserIO> pIO = pDbCmdCtx->userIO();
  OdDbSelectionSetPtr pSSet = pIO->select(L"Select objects:", 
                                          OdEd::kSelAllowObjects | 
                                          OdEd::kSelAllowSubents |
                                          OdEd::kSelLeaveHighlighted);

  if (pSSet->numEntities())
  {
    OdGePoint3d ptBase = pIO->getPoint(L"Specify base point:");
    double dScale = pIO->getReal(L"Specify scale factor",OdEd::kInpNonZero, 1.0);

    OdGeMatrix3d matOffset;
    matOffset.setToScaling(dScale, ptBase);
    OdDbSelectionSetIteratorPtr pIter = pSSet->newIterator();

    OdDbDatabasePtr pDb = pDbCmdCtx->database();
    pDb->startTransaction();
    while (!pIter->done())
    {
      OdDbObjectId objId = pIter->objectId();
      OdDbEntityPtr pEnt = objId.openObject(OdDb::kForWrite);

      if (!pEnt.isNull())
      {
        if (pIter->subentCount())
        {
          OdDbFullSubentPath pathSubent;
          OdDbFullSubentPathArray arrPaths;

          for (unsigned int i = 0; i < pIter->subentCount(); i++)
          {
            pIter->getSubentity(i,pathSubent);
            arrPaths.push_back(pathSubent);
          }

          pEnt->transformSubentPathsBy(arrPaths, matOffset);
        }
        else
          pEnt->transformBy(matOffset);
      }

      pIter->next();
    }
    pDb->endTransaction();
  }
}

void _Rotate_func(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdDbDatabasePtr pDb = pDbCmdCtx->database();
  OdSmartPtr<OdDbUserIO> pIO = pDbCmdCtx->userIO();
  OdDbSelectionSetPtr pSSet = pIO->select(L"Select objects:", 
                                          OdEd::kSelAllowObjects | 
                                          OdEd::kSelAllowSubents |
                                          OdEd::kSelLeaveHighlighted);
  if (pSSet->numEntities())
  {
    OdGePoint3d ptBase = pIO->getPoint(L"Specify base point:");
    double dAngle = pIO->getAngle(L"Specify rotation angle", OdEd::kGanNoZero | OdEd::kGanFromLastPoint | OdEd::kGptRubberBand, OdaPI);

    OdGeMatrix3d matOffset;
    matOffset.setToRotation(dAngle, pDb->getUCSXDIR().crossProduct(pDb->getUCSYDIR()), ptBase);
    OdDbSelectionSetIteratorPtr pIter = pSSet->newIterator();

    pDb->startTransaction();
    while (!pIter->done())
    {
      OdDbObjectId objId = pIter->objectId();
      OdDbEntityPtr pEnt = objId.openObject(OdDb::kForWrite);

      if (!pEnt.isNull())
      {
        if (pIter->subentCount())
        {
          OdDbFullSubentPath pathSubent;
          OdDbFullSubentPathArray arrPaths;

          for (OdUInt32 i = 0; i < pIter->subentCount(); i++)
          {
            pIter->getSubentity(i, pathSubent);
            arrPaths.push_back(pathSubent);
          }

          pEnt->transformSubentPathsBy(arrPaths, matOffset);
        }
        else
          pEnt->transformBy(matOffset);
      }
      pIter->next();
    }
    pDb->endTransaction();
  }
}

void _Join_func(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdSmartPtr<OdDbUserIO> pIO = pDbCmdCtx->userIO();
  OdDbSelectionSetPtr pSSet = pIO->select(L"Select primary entity:", 
                                          OdEd::kSelSingleEntity | 
                                          OdEd::kSelLeaveHighlighted);

  if (pSSet->numEntities())
  {
    ODA_ASSERT(pSSet->numEntities() == 1);
    OdDbSelectionSetIteratorPtr pIter = pSSet->newIterator();
    OdDbObjectId objId = pIter->objectId();
    OdDbEntityPtr pPrimary = objId.openObject(OdDb::kForWrite);

    pSSet = pIO->select(L"Select entities to join:", 
      OdEd::kSelAllowObjects | 
      OdEd::kSelLeaveHighlighted);

    OdDbEntityPtrArray aEnt;
    if (pSSet->numEntities())
    {
      pIter = pSSet->newIterator();

      while (!pIter->done())
      {
        OdDbObjectId objId = pIter->objectId();
        OdDbEntityPtr pEnt = objId.openObject(OdDb::kForWrite);

        if (!pEnt.isNull())
        {
          ODA_ASSERT(pIter->subentCount() == 0);
          aEnt.push_back(pEnt);
        }

        pIter->next();
      }

      OdDbJoinEntityPEPtr pJoinPE = OdDbJoinEntityPE::cast(pPrimary);
      if(!pJoinPE.isNull())
      {
        OdGeIntArray aInd;
        OdResult res = pJoinPE->joinEntities(pPrimary, aEnt, aInd);
        if(res == eOk)
        {
          for(unsigned int i = 0; i < aInd.logicalLength(); ++i)
          {
            aEnt[aInd[i]]->erase();
          }
        }
      }
    }
  }
}

//////////////////////////////////////////////////////////////////////////
void _Reverse_func(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdSmartPtr<OdDbUserIO> pIO = pDbCmdCtx->userIO();
  OdDbSelectionSetPtr pSSet = pIO->select(L"Select objects:", 
                                          OdEd::kSelAllowObjects | 
                                          OdEd::kSelLeaveHighlighted);

  int nObjects = 0;
  if (pSSet->numEntities())
  {
    OdDbSelectionSetIteratorPtr pIter = pSSet->newIterator();
    OdDbDatabasePtr pDb = pDbCmdCtx->database();
    pDb->startTransaction();
    bool bOk = true;
    try
    {
      while (!pIter->done())
      {
        OdDbObjectId objId = pIter->objectId();
        OdDbCurvePtr pEnt = OdDbCurve::cast(objId.openObject(OdDb::kForWrite));

        if (!pEnt.isNull())
        {
          if (pEnt->reverseCurve() == eOk)
            ++nObjects;
        }
        pIter->next();
      }
    }
    catch (...)
    {
      bOk = false;
    }

    if (bOk)
    {
      pDb->endTransaction();
      OdString strMessage;
      strMessage.format(L"%d object(s) direction has been reversed.", nObjects);
      pIO->putString(strMessage);
    }
    else
    {
      pDb->abortTransaction();
      pIO->putString(L"Failed.");
    }
  }
}
