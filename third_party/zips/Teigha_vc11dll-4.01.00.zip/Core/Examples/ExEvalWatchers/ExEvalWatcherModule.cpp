/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* Defines entry points for the DLL                                     */
/************************************************************************/
#include "StdAfx.h"
#include "ExEvalWatcherModule.h"
#include "RxDynamicModule.h"
#include "DbHatch.h"
#include "DbDimAssoc.h"
#include "DbLeader.h"
#include "ExHatchWatcher.h"
#include "ExDimAssocWatcher.h"

/************************************************************************/
/* OdExEvalWatchers methods                                             */
/************************************************************************/
void OdExEvalWatchers::init()
{
  if ( !OdDbHatch::desc() )
  {
    throw OdError(eNotInitializedYet);
  }
  OdDbHatch::desc()->module()->addRef();

  OdDbHatch::desc()->addX(OdDbEvalWatcherPE::desc(), &_hatchWatcher);
  OdDbDimAssoc::desc()->addX(OdDbEvalWatcherPE::desc(), &_dimWatcher);
  ::odedRegCmds()->addReactor(this);
}

void OdExEvalWatchers::uninit()
{
  OdDbHatch::desc()->delX(OdDbEvalWatcherPE::desc());
  OdDbDimAssoc::desc()->delX(OdDbEvalWatcherPE::desc());
  ::odedRegCmds()->removeReactor(this);

  OdDbHatch::desc()->module()->release();
}

void OdExEvalWatchers::commandWillStart(OdEdCommand*, OdEdCommandContext*)
{
  _hatchWatcher.open();
  _dimWatcher.open();
}

void OdExEvalWatchers::commandEnded(OdEdCommand*, OdEdCommandContext* )
{
  _hatchWatcher.close(true);
  _dimWatcher.close(true);
}

void OdExEvalWatchers::commandCancelled(OdEdCommand*, OdEdCommandContext* )
{
  _hatchWatcher.close(false);
  _dimWatcher.close(false);
}

void OdExEvalWatchers::commandFailed(OdEdCommand*, OdEdCommandContext* )
{
  _hatchWatcher.close(false);
  _dimWatcher.close(false);
}

/************************************************************************/
/* OdExEvalWatcherModule methods                                        */
/************************************************************************/
ODRX_DEFINE_DYNAMIC_MODULE(OdExEvalWatcherModule);

OdExEvalWatcherModule::OdExEvalWatcherModule()
{
}

void OdExEvalWatcherModule::initApp()
{
  _watchers.init();
}

void OdExEvalWatcherModule::uninitApp()
{
  _watchers.uninit();
}
