/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
#include <math.h>
#include <stdlib.h>
#include "AcExpr.h"

#include <OdaCommon.h>
#include <Ge/GePoint3d.h>
#include <OdRound.h>
#include <DbObjectId.h>
#include <DbHostAppServices.h>
#include <odaxwrap.h>
#include "ExFieldEvaluator.h"
#include <Ge/GeLine3d.h>
#include "OdExprEval.h"
#include <DbTable.h>
#include <DbBlockTableRecord.h>
#define STL_USING_LIST
#define STL_USING_ALGORITHM
#include <OdaSTL.h>

extern "C"
{
#include "scanner.h"
#include "parser.h"
  int yyparse (yyscan_t yyscanner, AcExprEvalResult* ptr);
}

ODRX_CONS_DEFINE_MEMBERS(OdExprEvaluator,OdEvaluatorBase,RXIMPL_CONSTR);

OdExprEvaluator::OdExprEvaluator() : OdEvaluatorBase(OD_T("AcExpr")) {}

const OdString OdExprEvaluator::evaluatorId(OdDbField* pField) const 
{
  if (!pField) 
    return OdString::kEmpty;
  OdString code = pField->getFieldCode(OdDbField::kFieldCode);
  if (code.find(OD_T("\\AcExpr ")) != -1)
    return OD_T("AcExpr");
  if (code.find(OD_T("\\AcExpr.16.2 ")) != -1)
    return OD_T("AcExpr.16.2");
  return OdString::kEmpty;
}
OdResult OdExprEvaluator::format(OdDbField* pField, OdString& pszValue) const
{
  OdFieldValue fv; 
  OdResult res = pField->getValue(fv);
  if (res != eOk) return res;
  pszValue = OD_T("");
  OdString format = pField->getFormat();
  if (format.isEmpty())
  {
    switch (fv.dataType())
    {
    case OdValue::kDouble:
    case OdValue::k3dPoint:
      format = L"%lu6%pr6";
      break;
    }
  }
  if (fv.format(format, pszValue, pField->database()))
    return eOk;
  return eNotImplemented;
}

#ifdef _DEBUG
extern "C" int yydebug;
#endif
void odEvaluateExpr(const char* str, AcExprEvalResult& result)
{
  yyscan_t scanner;
  yylex_init(&scanner);
  result.success = 1;
  result.result = 0;
#ifdef _DEBUG
  yydebug = 0;
#endif
  YY_BUFFER_STATE buf = yy_scan_string(str, scanner);
  yyparse(scanner, &result);
  yy_delete_buffer(buf, scanner);
  yylex_destroy(scanner);
}

OdResult OdExprEvaluator::evaluate(OdDbField* pField, int nContext, OdDbDatabase* pDb, OdFdFieldResult* pResult) const
{
  OdString code = pField->getFieldCode(
    OdDbField::FieldCodeFlag(OdDbField::kStripOptions|OdDbField::kForExpression|OdDbField::kEvaluatedChildren|OdDbField::kFieldCode));
  code.makeLower();
  AcExprEvalResult result;
  result.user_data = pField;
  result.heap = new std::list<OdResBufPtr>();
  odEvaluateExpr((const char*)code, result);
  OdResult r = eOk;
  if (result.success != 0 && result.result != 0)
  {
    OdFieldValue v;
    switch (((OdResBuf*)result.result)->restype())
    {
    case OdResBuf::kDxfInt64:
      v.set((OdInt32)((OdResBuf*)result.result)->getInt64());
      break;
    case OdResBuf::kDxfReal:
      v.set(((OdResBuf*)result.result)->getDouble());
      break;
    case OdResBuf::kDxfXCoord:
      {
        OdGePoint3d p = ((OdResBuf*)result.result)->getPoint3d();
        v.set(p.x, p.y, p.z);
      }
      break;
    }
    pResult->setFieldValue(&v);
    pResult->setEvaluationStatus(OdDbField::kSuccess);
  }
  else
  {
    pResult->setEvaluationStatus(OdDbField::kOtherError);
    r = eInvalidInput;
  }
  delete (std::list<OdResBufPtr>*)result.heap;
  return r;
}

void acexprSaveToHeap(OdResBuf* rb, AcExprEvalResult* ptr)
{
  ((std::list<OdResBufPtr>*)ptr->heap)->push_back(rb);
}
void* Vec(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb;
  try {
    OdGePoint3d pp1 = ((OdResBuf*)p1)->getPoint3d();
    OdGePoint3d pp2 = ((OdResBuf*)p2)->getPoint3d();
    rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, pp2 - pp1);
    acexprSaveToHeap(rb, ptr);
  }
  catch(const OdError&){
    ptr->success = 0;
  }
  return rb.get();
}
void* UnitVec(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb;
  try {
    OdGePoint3d pp1 = ((OdResBuf*)p1)->getPoint3d();
    OdGePoint3d pp2 = ((OdResBuf*)p2)->getPoint3d();
    OdGeVector3d vec(pp2 - pp1);
    vec.normalize();
    rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, vec);
    acexprSaveToHeap(rb, ptr);
  } catch(const OdError&) {
    ptr->success = 0;
  }
  return rb.get();
}
void* Normal(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb;
  try {
    OdGePoint3d pp1 = ((OdResBuf*)p1)->getPoint3d();
    OdGePoint3d pp2 = ((OdResBuf*)p2)->getPoint3d();
    OdGeVector3d vec(pp2 - pp1);
    vec.perpVector();
    rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, vec);
    acexprSaveToHeap(rb, ptr);
  } catch (const OdError&) {
    ptr->success = 0;
  }
  return rb.get();
}

void* Ill(void* p1, void* p2, void* p3, void* p4, AcExprEvalResult* ptr)
{
  OdResBufPtr rb;
  try {
    OdGePoint3d pp1 = ((OdResBuf*)p1)->getPoint3d();
    OdGePoint3d pp2 = ((OdResBuf*)p2)->getPoint3d();
    OdGePoint3d pp3 = ((OdResBuf*)p3)->getPoint3d();
    OdGePoint3d pp4 = ((OdResBuf*)p4)->getPoint3d();
    OdGeLine3d l1(pp1, pp2);
    OdGeLine3d l2(pp3, pp4);
    OdGePoint3d p;
    if (!l1.intersectWith(l2, p))
    {
      ptr->success = 0;
    }
    else
    {
      rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, p);
      acexprSaveToHeap(rb, ptr);
    }
  } catch (const OdError&) {
    ptr->success = 0;
  }
  return rb.get();
}

void* Add(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1, rb2 = (OdResBuf*)p2;
  if (rb1->restype() == OdResBuf::kDxfXCoord) // both arguments must be points if the first is a point
  {
    if (rb2->restype() == OdResBuf::kDxfXCoord)
    {
      OdGePoint3d pp1 = ((OdResBuf*)p1)->getPoint3d();
      OdGePoint3d pp2 = ((OdResBuf*)p2)->getPoint3d();
      rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, OdGePoint3d(pp2 + pp1.asVector()));
    }
  }
  // if both arguments are of integral type - preserve type (intermediate integers are all int64)
  else if (rb1->restype() == OdResBuf::kDxfInt64 && rb2->restype() == OdResBuf::kDxfInt64)
  {
    rb = OdResBuf::newRb(OdResBuf::kDxfInt64, rb1->getInt64() + rb2->getInt64());
  }
  else
  {
    double arg1, arg2;
    switch(rb1->restype())
    {
      case OdResBuf::kDxfInt64:
        arg1 = (double)rb1->getInt64();
        break;
      case OdResBuf::kDxfReal:
        arg1 = rb1->getDouble();
        break;
      default:
        ptr->success = 0;
        return 0;
    }
    switch(rb2->restype())
    {
    case OdResBuf::kDxfInt64:
      arg2 = (double)rb2->getInt64();
      break;
    case OdResBuf::kDxfReal:
      arg2 = rb2->getDouble();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, arg1 + arg2);
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}
void* Mul(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1, rb2 = (OdResBuf*)p2;  
  // both are integers - result is an integer
  if (rb1->restype() == OdResBuf::kDxfInt64 && rb2->restype() == OdResBuf::kDxfInt64)
  {
    rb = OdResBuf::newRb(OdResBuf::kDxfInt64, rb1->getInt64() * rb2->getInt64());
  }
  // both are points/vectors - result is a scalar product
  else if (rb1->restype() == OdResBuf::kDxfXCoord && rb2->restype() == OdResBuf::kDxfXCoord)
  {
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, rb1->getVector3d().dotProduct(rb2->getVector3d()));
  }
  // one of the arguments is a point - another should be scalar
  else if (rb1->restype() == OdResBuf::kDxfXCoord || rb2->restype() == OdResBuf::kDxfXCoord)
  {
    OdGeVector3d pp1;
    double arg;
    if (rb1->restype() == OdResBuf::kDxfXCoord)
    {
      pp1 = rb1->getVector3d();
      switch (rb2->restype())
      {
      case OdResBuf::kDxfReal:
        arg = rb2->getDouble();
        break;
      case OdResBuf::kDxfInt64:
        arg = (double)rb2->getInt64();
        break;
      default:
        ptr->success = 0;
        return 0;
      }
    }
    else
    {
      pp1 = rb2->getVector3d();
      switch (rb1->restype())
      {
      case OdResBuf::kDxfReal:
        arg = rb1->getDouble();
        break;
      case OdResBuf::kDxfInt64:
        arg = (double)rb1->getInt64();
        break;
      default:
        ptr->success = 0;
        return 0;
      }
    }
    rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, pp1 * arg);
  }
  else // both are scalars
  {
    double arg1, arg2;
    switch (rb1->restype())
    {
    case OdResBuf::kDxfReal:
      arg1 = rb1->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg1 = (double)rb1->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    switch (rb2->restype())
    {
    case OdResBuf::kDxfReal:
      arg2 = rb2->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg2 = (double)rb2->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, arg1 * arg2);
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}

void* Div(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1, rb2 = (OdResBuf*)p2;
  if (rb1->restype() == OdResBuf::kDxfXCoord)
  {
    OdGeVector3d pp1 = rb1->getVector3d();
    double arg;
    switch (rb2->restype())
    {
    case OdResBuf::kDxfReal:
      arg = rb2->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg = (double)rb2->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    if (!OdZero(arg))
      rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, pp1 * (1/arg));
  }
  else
  {
    double arg1, arg2;
    switch (rb1->restype())
    {
    case OdResBuf::kDxfReal:
      arg1 = rb1->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg1 = (double)rb1->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    switch (rb2->restype())
    {
    case OdResBuf::kDxfReal:
      arg2 = rb2->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg2 = (double)rb2->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    if (!OdZero(arg2))
      rb = OdResBuf::newRb(OdResBuf::kDxfReal, arg1 / arg2);
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}
void* Neg(void* p1, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1;  
  switch(rb1->restype())
  {
  case OdResBuf::kDxfXCoord:
    rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, -rb1->getVector3d());
    break;
  case OdResBuf::kDxfInt64:
    rb = OdResBuf::newRb(OdResBuf::kDxfInt64, -rb1->getInt64());
    break;
  case OdResBuf::kDxfReal:
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, -rb1->getDouble());
    break;
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}
void* Sub(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1, rb2 = (OdResBuf*)p2;
  if (rb1->restype() == OdResBuf::kDxfXCoord) // both arguments must be points if the first is a point
  {
    rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, rb1->getPoint3d() - rb2->getVector3d());
  }
  // if both arguments are of integral type - preserve type (intermediate integers are all int64)
  else if (rb1->restype() == OdResBuf::kDxfInt64 && rb2->restype() == OdResBuf::kDxfInt64)
  {
    rb = OdResBuf::newRb(OdResBuf::kDxfInt64, rb1->getInt64() - rb2->getInt64());
  }
  else
  {
    double arg1, arg2;
    switch (rb1->restype())
    {
    case OdResBuf::kDxfReal:
      arg1 = rb1->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg1 = (double)rb1->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    switch (rb2->restype())
    {
    case OdResBuf::kDxfReal:
      arg2 = rb2->getDouble();
      break;
    case OdResBuf::kDxfInt64:
      arg2 = (double)rb2->getInt64();
      break;
    default:
      ptr->success = 0;
      return 0;
    }
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, arg1 - arg2);
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}
void* Distance(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1, rb2 = (OdResBuf*)p2;
  try {
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, rb2->getPoint3d().distanceTo(rb1->getPoint3d()));
  }
  catch(const OdError&){
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}

int symLookup(void* fun)
{
  OdString str = ((OdResBuf*)fun)->getString();
  if (str == L"sin")
    return SIN;
  else if (str == L"cos")
      return COS;
  else if (str == L"tan")
    return TAN;
  else if (str == L"asin")
    return ASIN;
  else if (str == L"acos")
      return ACOS;
  else if (str == L"atan")
      return ATAN;
  else if (str == L"log")
      return LOG;
  else if (str == L"ln")
      return LN;
  else if (str == L"exp")
      return EXP;
  else if (str == L"sqr")
      return SQR;
  else if (str == L"sqrt")
      return SQRT;
  else if (str == L"r2d")
      return R2D;
  else if (str == L"d2r")
      return D2R;
  else if (str == L"abs")
      return ABS;
  else if (str == L"round")
      return ROUND;
  else if (str == L"trunc")
      return TRUNC; 
  return -1;
}

static bool getRowCol(void* param, OdUInt32& row, OdUInt32& col)
{
  if (((OdResBuf*)param)->restype() != OdResBuf::kDxfText)
    return false;
  OdString str = ((OdResBuf*)param)->getString();
  const char* index = (const char*)str;
  row = 0;
  col = 0;
  while ((*index) <= 'z' && (*index) >= 'a')
  {
    col = (col*('z' - 'a' + 1)) + (*index) - 'a' + 1;
    ++index;
  }
  if (col == 0)
    return false;
  --col; // indices are zero based
  while ((*index) <= '9' && (*index) >= '0')
  {
    row = row * 10 + (*index) - '0';
    ++index;
  }
  if (row == 0)
    return false;
  --row; // indices are zero based
  return true;
}

void* getTableCell(OdDbTable* table, void* cell, AcExprEvalResult* ptr);

static OdResBufPtr evalTableSum(OdDbTable* table, OdResBuf* seq, AcExprEvalResult* ptr)
{
  OdResBufPtr res = OdResBuf::newRb(OdResBuf::kDxfInt64, (OdInt64)0);
  for (OdResBufPtr r = seq; !r.isNull(); r = r->next())
  {
    OdResBufPtr rb = r;
    if (rb->restype() == OdResBuf::kDxfText)
      rb = (OdResBuf*)getTableCell(table, r.get(), ptr);
    if (rb.isNull())
    {
      continue;
    }
    switch (rb->restype())
    {
    case OdResBuf::kRtNil:
      break;
    case OdResBuf::kDxfReal:
      if (res->restype() == OdResBuf::kDxfInt64)
        res = OdResBuf::newRb(OdResBuf::kDxfReal, rb->getDouble() + res->getInt64());
      else
        res->setDouble(rb->getDouble() + res->getDouble());
      break;
    case OdResBuf::kDxfInt64:
      if (res->restype() == OdResBuf::kDxfInt64)
        res->setInt64(rb->getInt64() + res->getInt64());
      else
        res = OdResBuf::newRb(OdResBuf::kDxfReal, res->getDouble() + rb->getInt64());
      break;
    }
  }
  return res;
}
static int evalTableCount(OdDbTable* table, OdResBuf* seq, AcExprEvalResult* ptr)
{
  int res = 0;
  for (OdResBufPtr r = seq; !r.isNull(); r = r->next())
  {
    OdResBufPtr rb = r;
    if (rb->restype() == OdResBuf::kDxfText)
      rb = (OdResBuf*)getTableCell(table, r.get(), ptr);
    if (!rb.isNull() && rb->restype() != OdResBuf::kRtNil)
      ++res;
  }
  return res;
}
static bool evalTableAvg(OdDbTable* table, OdResBuf* seq, double& res, AcExprEvalResult* ptr)
{
  res = 0;
  int count = 0;
  for (OdResBufPtr r = seq; !r.isNull(); r = r->next())
  {
    OdResBufPtr rb = r;
    if (rb->restype() == OdResBuf::kDxfText)
      rb = (OdResBuf*)getTableCell(table, r.get(), ptr);
    if (rb.isNull())
    {
      continue;
    }
    switch (rb->restype())
    {
    case OdResBuf::kDxfReal:
      res += rb->getDouble();
      ++count;
      break;
    case OdResBuf::kDxfInt64:
      res += rb->getInt64();
      ++count;
      break;
    }
  }
  if (count != 0)
  {
    res /= count;
    return true;
  }
  else
    return false;
}

static void* tableEvalExplicit(OdDbTable* table, void* fun, void* range, AcExprEvalResult* ptr)
{
  if (((OdResBuf*)fun)->restype() != OdResBuf::kDxfText)
  {
    ptr->success = 0;
    return 0;
  }
  OdResBufPtr rb, seq = (OdResBuf*)range;
  OdString str = ((OdResBuf*)fun)->getString();
  if (str == L"sum")
  {
    rb = evalTableSum(table, seq, ptr);
  }
  else if (str == L"average")
  {
    double res;
    if (evalTableAvg(table, seq, res, ptr))
      rb = OdResBuf::newRb(OdResBuf::kDxfReal, res);
  }
  else if (str == L"count")
  {
    rb = OdResBuf::newRb(OdResBuf::kDxfInt64, (OdInt64)evalTableCount(table, seq, ptr));
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}

OdDbObjectId getObjectId(void* id, AcExprEvalResult* ptr)
{
  if (((OdResBuf*)id)->restype() == OdResBuf::kDxfInt64)
  {
    return OdDbObjectId((OdDbStub*)((OdResBuf*)id)->getInt64());
  }
  else
  {
    ptr->success = 0;
    return OdDbObjectId::kNull;
  }
}

void* TableEval(void* id, void* fun, void* seq, AcExprEvalResult* ptr)
{
  OdDbObjectId objId(getObjectId(id, ptr));
  if (!ptr->success)
    return 0;
  OdDbTablePtr table = objId.openObject();
  return tableEvalExplicit(table, fun, seq, ptr);
}
static OdDbTablePtr getOwnerTable(OdDbObjectId ownerId)
{
  if (ownerId.isNull())
    return OdDbTablePtr();
  OdDbObjectPtr obj = ownerId.openObject();
  if (obj.isNull())
    return OdDbTablePtr();
  else if (obj->isKindOf(OdDbBlockTableRecord::desc()))
    return OdDbTablePtr();
  else if (obj->isKindOf(OdDbTable::desc()))
    return OdDbTablePtr(obj);
  else
    return getOwnerTable(obj->ownerId());
}

static OdDbBlockTableRecordPtr getOwnerBlock(OdDbObjectId ownerId)
{
  if (ownerId.isNull())
    return OdDbBlockTableRecordPtr();
  OdDbObjectPtr obj = ownerId.openObject();
  if (obj.isNull())
    return OdDbBlockTableRecordPtr();
  else if (obj->isKindOf(OdDbBlockTableRecord::desc()))
    return OdDbBlockTableRecordPtr(obj);
  else 
    return getOwnerBlock(obj->ownerId());
}
static OdDbTablePtr getImplicitTable(AcExprEvalResult* ptr)
{
  OdDbTablePtr table = getOwnerTable(((OdDbField*)ptr->user_data)->ownerId());
  if (!table.isNull())
    return table;
  OdDbBlockTableRecordPtr block = getOwnerBlock(((OdDbField*)ptr->user_data)->ownerId());
  if (block.isNull())
    return table;
  OdString nm = block->getName();
  if ( nm.getAt(0) == '*' && nm.getAt(1) == 'T' )
  {
    OdDbObjectIdArray ia;
    block->getBlockReferenceIds(ia);
    if (ia.isEmpty())
      return table;
    table = ia[0].openObject();
  }
  return table;
}
void* ImplicitTableEval(void* fun, void* range, AcExprEvalResult* ptr)
{
  OdDbTablePtr table = getImplicitTable(ptr);
  return tableEvalExplicit(table, fun, range, ptr);
}
// number is [[whitespace?] [sign?] [digits] [whitespace?]]
static bool isNumber(const OdChar* s)
{
  while (*s && isspace(*s))
    ++s;
  while (*s && (*s == '-' || *s == '+'))
    ++s;
  if (!*s)
    return false;
  while (*s && isdigit(*s))
    ++s;
  while (*s && isspace(*s))
    ++s;
  return *s == 0;
}

// real number is [[whitespace]? [sign]? [digits]? . [E|e]? [sign]? [digits]? [whitespace]?]
static bool isReal(const OdChar* s)
{
  while (*s && isspace(*s))
    ++s;
  while (*s && (*s == '-' || *s == '+'))
    ++s;
  if (!*s)
    return false;
  while (*s && (isdigit(*s) || *s == '.' || *s == '-' || *s == '+' || *s == 'E' || *s == 'e'))
    ++s;
  while (*s && isspace(*s))
    ++s;
  return *s == 0;
}

OdResBufPtr acexprValueToResbuf(const OdValue& v)
{
  switch (v.dataType())
  {
  case OdValue::kDouble:
    return OdResBuf::newRb(OdResBuf::kDxfReal, (double)v);
  case OdValue::kLong:
    return OdResBuf::newRb(OdResBuf::kDxfInt64, (OdInt64)(long)v);
  case OdValue::kDate:
    return OdResBuf::newRb(OdResBuf::kDxfInt64, (OdInt64)v);
  case OdValue::kString:
    {
      OdString s = (OdString)v;
      if (isNumber(s))
        return OdResBuf::newRb(OdResBuf::kDxfInt64,(OdInt64)odStrToD(s));
      else if (isReal(s))
          return OdResBuf::newRb(OdResBuf::kDxfReal,odStrToD(s));
    }
  default:
    return OdResBufPtr();
  }
}

void* acexprCreateTableRange(void* cell1, void* cell2, AcExprEvalResult* ptr)
{
  OdUInt32 row1, col1, row2, col2;
  ptr->success = false;
  if (!getRowCol(cell1, row1, col1) || !getRowCol(cell2, row2, col2))
    return 0;
  OdResBufPtr rb;
  OdArray<OdResBufPtr> res;
  if (row1 > row2)
    std::swap(row1, row2);
  if (col1 > col2)
    std::swap(col1, col2);
  for (OdUInt32 row = row1; row <= row2; ++row)
  {
    for (OdUInt32 col = col1; col <= col2; ++col)
    {
      OdString s;
      const int N = 'z' - 'a' + 1;
      int c = col;
      do
      {
        OdString tmp;
        tmp = (OdChar)('a' + (c % N));
        s = tmp + s;
        c /= N;
      }
      while (c > 0);
      char buf[256] = {0};
      s += itoa(row + 1, buf, 10);
      res.append(OdResBuf::newRb(OdResBuf::kDxfText, s));
    }
  }
  if (res.isEmpty())
  {
    res.append(OdResBuf::newRb(OdResBuf::kRtNil));
  }
  rb = res[0];
  OdResBufPtr last = rb;
  for (unsigned i = 1; i < res.size();++i)
    last = last->setNext(res[i]);
  acexprSaveToHeap(rb, ptr);
  ptr->success = true;
  return rb;
}

void* getTableCell(OdDbTable* table, void* cell, AcExprEvalResult* ptr)
{
  OdUInt32 row, col;
  OdResBufPtr res;
  try
  {
    if (table && getRowCol(cell, row, col))
    {
      for (OdInt32 i = 0; i < table->numContents(row, col) && res.isNull(); ++i)
      {
        res = acexprValueToResbuf(table->value(row, col, i, OdValue::kIgnoreMtextFormat));
      }
    }
  }
  catch (const OdError& )
  {
    ptr->success = 0;
  }
  if (!res.isNull())
    acexprSaveToHeap(res, ptr);
  else
    ptr->success = 0;
  return res;
}

void* acexprCreateTableSequence(void* val1, void* val2, AcExprEvalResult* ptr)
{
  OdResBufPtr res = (OdResBuf*)val2;
  if (!val1)
    return res;
  OdResBufPtr seq = ((OdResBuf*)val1);
  if (seq->restype() == OdResBuf::kRtNil)
    seq = res;
  else
    seq->last()->setNext(res);
  return seq;
}

void* ImplicitTableCell(void* cell, AcExprEvalResult* ptr)
{
  OdDbTablePtr table = getImplicitTable(ptr);
  return getTableCell(table, cell, ptr);
}
void* TableCell(void* id, void* cell, AcExprEvalResult* ptr)
{
  OdDbObjectId objId(getObjectId(id, ptr));
  if (!ptr->success)
    return 0;
  OdDbTablePtr table = objId.openObject();
  return getTableCell(table, cell, ptr);
}
OdFieldValue oddbGetObjectProperty(OdDbObjectId id, const OdString& propName, bool& bFound);
void* ObjectEval(void* id, void* fun, AcExprEvalResult* ptr)
{
  OdDbObjectId objId(getObjectId(id, ptr));
  if (!ptr->success)
    return 0;
  if (((OdResBuf*)fun)->restype() != OdResBuf::kDxfText)
  {
    ptr->success = 0;
    return 0;
  }
  OdResBufPtr rb;
  OdString str = ((OdResBuf*)fun)->getString();
  bool bFound = false;
  OdFieldValue fv = oddbGetObjectProperty(objId, str, bFound);
  if (bFound)
  {
    switch(fv.dataType())
    {
    case OdValue::k3dPoint:
      {
        OdGePoint3d p;
        fv.get(p.x, p.y, p.z);
        rb = OdResBuf::newRb(OdResBuf::kDxfXCoord, p);
      }
      break;
    case OdValue::kDouble:
      rb = OdResBuf::newRb(OdResBuf::kDxfReal, (double)fv);
      break;
    case OdValue::kLong:
      rb = OdResBuf::newRb(OdResBuf::kDxfInt64, (OdInt64)(long)fv);
      break;
    default:
      ptr->success = 0;
      break;
    }
  }
  if (!rb.isNull())
    acexprSaveToHeap(rb, ptr);
  else
    ptr->success = 0;
  return rb.get();
}

OdGeVector3d convertCoords(void* x, void* y, void* z, AcExprEvalResult* ptr)
{
  OdGeVector3d p;
  switch(((OdResBuf*)x)->restype())
  {
  case OdResBuf::kDxfReal:
    p.x = ((OdResBuf*)x)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    p.x = (double)((OdResBuf*)x)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  switch(((OdResBuf*)y)->restype())
  {
  case OdResBuf::kDxfReal:
    p.y = ((OdResBuf*)y)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    p.y = (double)((OdResBuf*)y)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  switch(((OdResBuf*)z)->restype())
  {
  case OdResBuf::kDxfReal:
    p.z = ((OdResBuf*)z)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    p.z = (double)((OdResBuf*)z)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  return p;
}

#define RELATIVE_COORD 1
#define WCS_COORD 2
void* Vector(void* x, void* y, void* z, void* relativeFlags, AcExprEvalResult* ptr)
{
  OdResBufPtr v;
  OdGeVector3d p = convertCoords(x, y, z, ptr);
  /* // relative flags are useless in ordinary fields, so currently we just ignore them
  if (relativeFlags & RELATIVE_COORD) 
  {
    OdGeExtents3d ext;
    ((OdDbField*)ptr->user_data)->getGeomExtents()
    res += ext.center()
  }
  */
  if (ptr->success)
  {
    v = OdResBuf::newRb(OdResBuf::kDxfXCoord, p);
    acexprSaveToHeap(v, ptr);
  }
  return v.get();
}

void* PolarVector(void* x, void* a, void* z, void* relativeFlags, AcExprEvalResult* ptr)
{
  OdResBufPtr v;
  OdGeVector3d p = convertCoords(x, a, z, ptr);
  if (ptr->success)
  {
    v = OdResBuf::newRb(OdResBuf::kDxfXCoord, OdGePoint3d(p.x*cos(OdaToRadian(p.y)), p.x*sin(OdaToRadian(p.y)), p.z));
    acexprSaveToHeap(v, ptr);
  }
  return v.get();
}
void* SphereVector(void* r, void* phi, void* theta, void* relativeFlags, AcExprEvalResult* ptr)
{
  OdResBufPtr v;
  OdGeVector3d p = convertCoords(r, phi, theta, ptr);
  if (ptr->success)
  {
    v = OdResBuf::newRb(OdResBuf::kDxfXCoord, OdGePoint3d(
      p.x*sin(OdaToRadian(p.z))*cos(OdaToRadian(p.y)),
      p.x*sin(OdaToRadian(p.z))*sin(OdaToRadian(p.y)), 
      p.x*cos(OdaToRadian(p.z))));
    acexprSaveToHeap(v, ptr);
  }
  return v.get();
}

void* Round(void* d, AcExprEvalResult* ptr)
{
  OdResBufPtr v;
  double arg;
  switch(((OdResBuf*)d)->restype())
  {
  case OdResBuf::kDxfReal:
    arg = ((OdResBuf*)d)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    arg = (double)((OdResBuf*)d)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  if (ptr->success)
  {
    v = OdResBuf::newRb(OdResBuf::kDxfReal, OdRound(arg));
    acexprSaveToHeap(v, ptr);
  }
  return v.get();
}
void* R2d(void* d, AcExprEvalResult* ptr)
{
  OdResBufPtr v;
  double arg;
  switch(((OdResBuf*)d)->restype())
  {
  case OdResBuf::kDxfReal:
    arg = ((OdResBuf*)d)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    arg = (double)((OdResBuf*)d)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  if (ptr->success)
  {
    v = OdResBuf::newRb(OdResBuf::kDxfReal, OdaToDegree(arg));
    acexprSaveToHeap(v, ptr);
  }
  return v.get();
}
void* D2r(void* d, AcExprEvalResult* ptr)
{
  OdResBufPtr v;
  double arg;
  switch(((OdResBuf*)d)->restype())
  {
  case OdResBuf::kDxfReal:
    arg = ((OdResBuf*)d)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    arg = (double)((OdResBuf*)d)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  if (ptr->success)
  {
    v = OdResBuf::newRb(OdResBuf::kDxfReal, OdaToRadian(arg));
    acexprSaveToHeap(v, ptr);
  }
  return v.get();
}

void* Angle(void* p1, void* p2, AcExprEvalResult* ptr)
{
  OdResBufPtr rb, rb1 = (OdResBuf*)p1, rb2 = (OdResBuf*)p2;
  if (rb1->restype() == OdResBuf::kDxfXCoord && rb2->restype() == OdResBuf::kDxfXCoord)
  {
    OdGeVector3d pp1 = rb1->getVector3d(), pp2 = rb2->getVector3d();
    rb = OdResBuf::newRb(OdResBuf::kDxfReal, pp1.angleTo(pp2));
    acexprSaveToHeap(rb, ptr);
    return rb.get();
  }
  else
  {
    ptr->success = 0;
    return 0;
  }
}

void* acexprParseDouble(const char* text, int len, AcExprEvalResult* ptr)
{
  double val;
  sscanf(text, "%lf", &val);
  OdResBufPtr v = OdResBuf::newRb(OdResBuf::kDxfReal, val);
  acexprSaveToHeap(v, ptr);
  return v.get();
}

void* acexprParseLiteral(const char* text, int len, AcExprEvalResult* ptr)
{
  OdResBufPtr v = OdResBuf::newRb(OdResBuf::kDxfText, OdString(text, len));
  acexprSaveToHeap(v, ptr);
  return v.get();
}

void* acexprParseInteger(const char* text, int len, AcExprEvalResult* ptr)
{
  OdInt64 val;
  sscanf(text, "%I64d", &val);
  OdResBufPtr v = OdResBuf::newRb(OdResBuf::kDxfInt64, val);
  acexprSaveToHeap(v, ptr);
  return v.get();
}

void* acexprCreateDouble2(double d, AcExprEvalResult* ptr)
{
  OdResBufPtr v = OdResBuf::newRb(OdResBuf::kDxfReal, d);
  acexprSaveToHeap(v, ptr);
  return v.get();
}

void* acexprCreateInteger2(__int64 i, AcExprEvalResult* ptr)
{
  OdResBufPtr v = OdResBuf::newRb(OdResBuf::kDxfInt64, (OdInt64)i);
  acexprSaveToHeap(v, ptr);
  return v.get();
}

void* acexprCopyValue(void* p, AcExprEvalResult* ptr)
{
  if (p == 0)
    return 0;
  OdResBufPtr v = OdResBuf::createObject();
  v->copyFrom((OdResBuf*)p);
  acexprSaveToHeap(v, ptr);
  return v.get();
}

double convertArgument(void* d, AcExprEvalResult* ptr)
{
  double arg;
  switch(((OdResBuf*)d)->restype())
  {
  case OdResBuf::kDxfReal:
    arg = ((OdResBuf*)d)->getDouble();
    break;
  case OdResBuf::kDxfInt64:
    arg = (double)((OdResBuf*)d)->getInt64();
    break;
  default:
    ptr->success = 0;
    break;
  }
  return arg;
}
// the input value is converted from current AUnits to radians
double convertArgumentA(void* d, AcExprEvalResult* ptr)
{
  double arg = convertArgument(d, ptr);
  if (ptr->success)
  {
    switch(((OdDbField*)ptr->user_data)->database()->getAUNITS())
    {
    case 0: // decimal degrees
    case 1: // d m s
    case 4: // Surveyors
      arg *= OdaPI / 180.0;
      break;
    case 2: // grad
      arg *= OdaPI / 200.0;
      break;
    }
  }
  return arg;
}


// the result value is converted to current AUnits
void* convertResultA(double d, AcExprEvalResult* ptr)
{
  switch(((OdDbField*)ptr->user_data)->database()->getAUNITS())
  {
  case 0: // decimal degrees
  case 1: // d m s
  case 4: // Surveyors
    d *= 180.0 / OdaPI;
    break;
  case 2: // grad
    d *= 200.0 / OdaPI;
    break;
  }
  return acexprCreateDouble2(d, ptr);
}

void* Sin(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgumentA(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(sin(res), ptr);
  return 0;  
}
void* Cos(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgumentA(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(cos(res), ptr);
  return 0;  
}
void* Tan(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgumentA(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(tan(res), ptr);
  return 0;  
}
void* Asin(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return convertResultA(OD_ASIN(res), ptr);
  return 0;  
}
void* Acos(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return convertResultA(OD_ACOS(res), ptr);
  return 0;  
}
void* Atan(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return convertResultA(atan(res), ptr);
  return 0;  
}
void* Log(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(log10(res), ptr);
  return 0;  
}
void* Ln(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(log(res), ptr);
  return 0;  
}
void* Exp(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(exp(res), ptr);
  return 0;  
}
void* Sqr(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(res*res, ptr);
  return 0;  
}
void* Sqrt(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(sqrt(res), ptr);
  return 0;  
}
void* Abs(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(fabs(res), ptr);
  return 0;  
}
void* Trunc(void* d, AcExprEvalResult* ptr)
{
  double res = convertArgument(d, ptr);
  if (ptr->success)
    return acexprCreateDouble2(floor(res), ptr);
  return 0;  
}

void* acexprParseAngle(const char* text, int len, AcExprEvalResult* ptr)
{
  OdString s(text, len);
  double d = OdUnitsFormatter::unformatA(s);
  // angle values coming w/o format are treated by trigonometric functions as being in current AUnits
  // but unformatA() always returns radians so we convert the result to AUnits as well
  switch(((OdDbField*)ptr->user_data)->database()->getAUNITS())
  {
  case 0: // decimal degrees
  case 1: // d m s
  case 4: // Surveyors
    d *= (180/OdaPI);
    break;
  case 3:
    break;
  case 2: // grad
    d *= (200/OdaPI);
    break;
  }
  return acexprCreateDouble2(d, ptr);
}
