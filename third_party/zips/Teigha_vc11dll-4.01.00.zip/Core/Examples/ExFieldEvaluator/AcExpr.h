/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
#ifndef _AcExpr_h_Included_
#define _AcExpr_h_Included_

#define YYSTYPE void*

typedef struct AcExprEvalResult
{
  void* result;
  int success;
  void* user_data;
  void* heap;
}
AcExprEvalResult;

#if defined __cplusplus
extern "C" {
#endif
void* acexprCopyValue(void* p, AcExprEvalResult* ptr);
void* acexprParseDouble(const char* text, int len, AcExprEvalResult* ptr);
void* acexprParseAngle(const char* text, int len, AcExprEvalResult* ptr);
void* acexprCreateDouble2(double d, AcExprEvalResult* ptr);
void* acexprParseLiteral(const char* text, int len, AcExprEvalResult* ptr);
void* acexprParseInteger(const char* text, int len, AcExprEvalResult* ptr);
void* acexprCreateInteger2(__int64 i, AcExprEvalResult* ptr);
void* acexprConvertAngle(void* v, void* format, AcExprEvalResult* ptr);
void* Sub(void* x, void* y, AcExprEvalResult* ptr);
void* Add(void* x, void* y, AcExprEvalResult* ptr);
void* Div(void* x, void* y, AcExprEvalResult* ptr);
void* Mul(void* x, void* y, AcExprEvalResult* ptr);
void* Neg(void* x, AcExprEvalResult* ptr);
void* TableEval(void* id, void* fun, void* range, AcExprEvalResult* ptr);
void* ImplicitTableEval(void* fun, void* range, AcExprEvalResult* ptr);
void* acexprCreateTableSequence(void* val1, void* val2, AcExprEvalResult* ptr);
void* acexprCreateTableRange(void* cell1, void* cell2, AcExprEvalResult* ptr);
void* TableCell(void* id, void* cell, AcExprEvalResult* ptr);
void* ImplicitTableCell(void* cell, AcExprEvalResult* ptr);
void* ObjectEval(void* id, void* fun, AcExprEvalResult* ptr);
void* Vector(void* x, void* y, void* z, void* relativeFlags, AcExprEvalResult* ptr);
void* PolarVector(void* x, void* a, void* z, void* relativeFlags, AcExprEvalResult* ptr);
void* SphereVector(void* x, void* p, void* r, void* relativeFlags, AcExprEvalResult* ptr);
void* Vec(void* p1, void* p2, AcExprEvalResult* ptr);
void* UnitVec(void* p1, void* p2, AcExprEvalResult* ptr);
void* Normal(void* p1, void* p2, AcExprEvalResult* ptr);
void* Ill(void* p1, void* p2, void* p3, void* p4, AcExprEvalResult* ptr); 
void* Distance(void* x, void* y, AcExprEvalResult* ptr);
void* Angle(void* x, void* y, AcExprEvalResult* ptr);
void* Round(void* d, AcExprEvalResult* ptr);
void* R2d(void* d, AcExprEvalResult* ptr);
void* D2r(void* d, AcExprEvalResult* ptr);

void* Sin(void* d, AcExprEvalResult* ptr);
void* Cos(void* d, AcExprEvalResult* ptr);
void* Tan(void* d, AcExprEvalResult* ptr);
void* Asin(void* d, AcExprEvalResult* ptr);
void* Acos(void* d, AcExprEvalResult* ptr);
void* Atan(void* d, AcExprEvalResult* ptr);
void* Log(void* d, AcExprEvalResult* ptr);
void* Ln(void* d, AcExprEvalResult* ptr);
void* Exp(void* d, AcExprEvalResult* ptr);
void* Sqr(void* d, AcExprEvalResult* ptr);
void* Sqrt(void* d, AcExprEvalResult* ptr);
void* Abs(void* d, AcExprEvalResult* ptr);
void* Trunc(void* d, AcExprEvalResult* ptr);

int symLookup(void* fun);
#if defined __cplusplus
}
#endif

#define YY_DECL int yylex( YYSTYPE * yylval, YYLTYPE* loc, yyscan_t yyscanner, AcExprEvalResult* ptr )
#define YY_NO_UNISTD_H

#endif
