/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* Implements notification functions for the evaluation of OdDbField    */ 
/* objects                                                              */
/************************************************************************/
#include "StdAfx.h"
#include "OdaObjProp.h"
#include <RxObjectImpl.h>
#include <DbHostAppServices.h>
#include <odaxwrap.h>
#include <Ge/GePoint3d.h>
#include <objbase.h>

OdDbDatabase* database(OdDbField* pField);
bool hasDecimals(OdValue::DataType type);
void fixPointCoords(OdString& format, OdValue::DataType type);
void fixPrecision(OdString& format, OdDbDatabase* pDb);

ODRX_CONS_DEFINE_MEMBERS(OdObjPropEvaluator,OdEvaluatorBase,RXIMPL_CONSTR);

OdObjPropEvaluator::OdObjPropEvaluator() : OdEvaluatorBase(OD_T("AcObjProp")) {}

const OdString OdObjPropEvaluator::evaluatorId(OdDbField* pField) const 
{
  if (!pField) 
    return OdString::kEmpty;
  OdString code = pField->getFieldCode(OdDbField::kFieldCode);
  if (code.find(OD_T("\\AcObjProp ")) != -1)
    return OD_T("AcObjProp");
  if (code.find(OD_T("\\AcObjProp.16.2 ")) != -1)
    return OD_T("AcObjProp.16.2");
  return OdString::kEmpty;
}

OdResult OdObjPropEvaluator::compile(OdDbField* pField, OdDbDatabase* pDb, OdFdFieldResult* pResult) const
{
  OdString code = pField->getFieldCode(OdDbField::kStripOptions);
  OdFdFieldEnginePEPtr pFieldEnginePE = OdFdFieldEngine::desc()->getX(OdFdFieldEnginePE::desc());
  if (!pFieldEnginePE.isNull())
  {
    OdString propName;
    OdDbObjectId id;
    if (!pFieldEnginePE->parseObjProp(code, pDb, id, propName))
      return eInvalidInput;
    if ( !id.isNull() )
      pField->setData(OD_T("ObjectPropertyId"), OdFieldValue(id));
    if ( !propName.isEmpty() )
      pField->setData(OD_T("ObjectPropertyName"), OdFieldValue(propName));  }
  else
  {
    int propNameStart = code.reverseFind('.');
    if (propNameStart != -1)
    {
      OdFieldValue propName = pField->getData(OD_T("ObjectPropertyName"));
      if (!propName.isValid())
      {
        pField->setData(OD_T("ObjectPropertyName"), OdFieldValue(code.mid(propNameStart + 1)));
      }
    }
    else
    {
      pResult->setEvaluationStatus(OdDbField::kSyntaxError, 0, OD_T("Property name not found"));
      return eInvalidInput;
    }
  }
  pResult->setEvaluationStatus(OdDbField::kSuccess);
  return eOk;
}

OdResult OdObjPropEvaluator::format(OdDbField* pField, OdString& pszValue) const
{
  OdFieldValue fv; 
  OdResult res = pField->getValue(fv);
  if (res != eOk) return res;
  pszValue = OD_T("");
  OdString format = pField->getFormat();
  fixPointCoords(format, fv.dataType());
  // OdValue can't handle specifiers that need the database
  OdDbDatabase* pDb = database(pField);
  if (pDb && hasDecimals(fv.dataType()))
    fixPrecision(format, pDb);
  if (fv.format(format, pszValue, pDb))
    return eOk;
  return eNotImplemented;
}

static OdFieldValue getPropValue(MEMBERID memid, IDispatch* pDisp)
{
  unsigned int  uArgErr;
  EXCEPINFO     except;
  _variant_t    varRes;
  DISPPARAMS    param = { NULL, NULL, 0, 0 };
  OdFieldValue fv;
  HRESULT hr = pDisp->Invoke(memid, IID_NULL, ::GetSystemDefaultLCID(), 
    DISPATCH_PROPERTYGET, &param, &varRes, &except, &uArgErr);
  if (!SUCCEEDED(hr))
      return fv;
  switch (varRes.vt)
  {
  case VT_DISPATCH:
  case VT_UNKNOWN:
    {
      IAcadAcCmColor* pColor = 0;
      if (SUCCEEDED(varRes.pdispVal->QueryInterface(&pColor)))
      {
        long ec;
        pColor->get_EntityColor(&ec);
        OdCmColor c;
        c.setColor(ec);
        fv = c.colorNameForDisplay();
        pColor->Release();
      }
      // what other types are possible?
    }
    break;
  case (VT_ARRAY | VT_R8): // treat as point
    {
      LONG index = 0;
      double x, y, z;
      SafeArrayGetElement(varRes.parray, &index, &x);
      index = 1;
      SafeArrayGetElement(varRes.parray, &index, &y);
      index = 2;
      SafeArrayGetElement(varRes.parray, &index, &z);
      fv = OdFieldValue(x, y, z);
    }
    break;
  case VT_BOOL:
    fv = OdInt32(VARIANT_TRUE == varRes.boolVal);
    break;
  case VT_I2:
  case VT_UI2:
    fv = OdInt32(varRes.iVal);
    break;
  case VT_I4:
  case VT_UI4:
    fv = OdInt32(varRes.lVal);
    break;
  case VT_R8:
    fv = varRes.dblVal;
    break;
  case VT_BSTR:
    fv = OdString(varRes.bstrVal);
    break;
  default:
    break;
  }
  return fv;
}

OdFieldValue oddbGetObjectProperty(OdDbObjectId id, const OdString& propName, bool& bFound)
{
  HRESULT hr = S_OK;
  OdFieldValue fv;
#if _WIN32_WINNT >= 0x400
  if ( (hr = ::CoInitializeEx( 0, COINIT_APARTMENTTHREADED )) == RPC_E_CHANGED_MODE )
    hr = ::CoInitializeEx( 0, COINIT_MULTITHREADED );
#else
  if ( HMODULE hm = ::LoadLibrary( OD_T("ole32.dll") ) )
  {
    typedef HRESULT (PASCAL *PCoInitializeEx)( LPVOID, DWORD );
    if ( PCoInitializeEx pf = (PCoInitializeEx)::GetProcAddress( hm, "CoInitializeEx" ) )
    {
      if ( pf( 0, COINIT_APARTMENTTHREADED ) == RPC_E_CHANGED_MODE )
        pf( 0, 0 );
    }
    ::FreeLibrary( hm );
  }
#endif

  if (FAILED(hr))
    return fv;
  try
  {
    // weird construction to take care of the reference counter
    // we pass NULL for application, because this sample is application independent 
    // (also, properties should be read w/o application access)
    IDispatchPtr pDisp = IUnknownPtr(::OdOxGetIUnknownOfObject(id, NULL), false);
    ITypeInfoPtr pTi;
    pDisp->GetTypeInfo(0, ::GetSystemDefaultLCID(), &pTi);
    FUNCDESC *pFD;
    UINT i = 0;
    while (!bFound && SUCCEEDED(pTi->GetFuncDesc(i, &pFD)))
    {
      if (pFD->invkind == INVOKE_PROPERTYGET)
      {
        _bstr_t res;
        hr = pTi->GetDocumentation(pFD->memid, res.GetAddress(), NULL, NULL, NULL);
        if (SUCCEEDED(hr))
        {
          if (propName.iCompare((const wchar_t*)res) == 0)
          {
            fv = getPropValue(pFD->memid, pDisp);
            bFound = true;
          }
        }
      }
      i++;
      pTi->ReleaseFuncDesc(pFD);
    }
  }
  catch (const _com_error&)
  {
    bFound = false;
  }
  catch(...)
  {
    ::CoUninitialize();
    throw;
  }
  ::CoUninitialize();
  return fv;
}

OdResult OdObjPropEvaluator::evaluate(OdDbField* pField, int nContext, OdDbDatabase* pDb, OdFdFieldResult* pResult) const
{
  OdFieldValue objId = pField->getData(OD_T("ObjectPropertyId"));
  OdFieldValue propNameValue = pField->getData(OD_T("ObjectPropertyName"));
  if (!objId.isValid() || !propNameValue.isValid() || !((OdDbObjectId)objId).isValid())
  {
    pResult->setEvaluationStatus(OdDbField::kInvalidContext);
    return eInvalidInput;
  }

  bool bFound = false;
  OdFdFieldEnginePEPtr pFieldEnginePE = OdFdFieldEngine::desc()->getX(OdFdFieldEnginePE::desc());
  if (pFieldEnginePE.isNull())
  {
    OdFieldValue fv = oddbGetObjectProperty(objId, OdString(propNameValue), bFound);
    if (bFound)
    {
      pResult->setFieldValue(fv.isValid() ? &fv : 0);
      pResult->setEvaluationStatus(OdDbField::kSuccess);
    }
    else
    {
      pResult->setFieldValue(0);
      pResult->setEvaluationStatus(OdDbField::kOtherError);
    }
  }
  else 
    bFound = pFieldEnginePE->getObjPropValue((OdString)propNameValue, (OdDbObjectId)objId, *pResult);
  return bFound ? eOk : eInvalidInput;
}
