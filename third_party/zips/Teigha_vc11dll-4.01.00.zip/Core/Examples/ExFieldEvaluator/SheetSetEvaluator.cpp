/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
#include "StdAfx.h"
#include "ExFieldEvaluator.h"
#include "RxObjectImpl.h"
#include "DbHostAppServices.h"


ODRX_CONS_DEFINE_MEMBERS(OdSheetSetEvaluator, OdEvaluatorBase, RXIMPL_CONSTR);

OdSheetSetEvaluator::OdSheetSetEvaluator() : OdEvaluatorBase(OD_T("AcSm")) {}

const OdString OdSheetSetEvaluator::evaluatorId(OdDbField* pField) const
{
    if (!pField)
        return OdString::kEmpty;
    OdString code = pField->getFieldCode(OdDbField::kFieldCode);
    if (code.find(OD_T("\\AcSm ")) != -1)
        return OD_T("AcSm");
    else if (code.find(OD_T("\\AcSm.16.2 ")) != -1)
        return OD_T("AcSm.16.2");
    return OdString::kEmpty;
}

OdResult OdSheetSetEvaluator::compile(OdDbField* pField, OdDbDatabase* /*pDb*/, OdFdFieldResult* pResult) const
{
    OdString code = pField->getFieldCode(OdDbField::kStripOptions);
    int dot = code.reverseFind('.');
    if (dot < 0)
    {
        pResult->setEvaluationStatus(OdDbField::kSyntaxError, 0, OD_T("Sheetset field code must contain a dot."));
        return eInvalidInput;
    }
    OdString compName = code.left(dot);
    OdString propName = code.mid(dot+1);
    OdFieldValuePtr fData = OdFieldValue::createObject();
    if (!compName.isEmpty())
    {
        // TODO: must be 'Sheet', 'Subset', 'SheetSet' or 'Database("{DstFilePath}").{CompName}("{ClsId}")'
        fData->set(compName);
        pField->setData(OD_T("SheetSetCompName"), *fData);
    }
    fData = OdFieldValue::createObject();
    if (!propName.isEmpty())
    {
        fData->set(propName);
        pField->setData(OD_T("SheetSetPropertyName"), *fData);
    }
    pResult->setEvaluationStatus(OdDbField::kSuccess);
    return eOk;
}

OdResult OdSheetSetEvaluator::evaluate(OdDbField* pField, int /*nContext*/, OdDbDatabase* pDb, OdFdFieldResult* pResult) const
{
    OdFieldValue fData = pField->getData(OD_T("SheetSetCompName"));
    OdString compName;
    if (!fData.get(compName))
    {
        pResult->setEvaluationStatus(OdDbField::kOtherError);
        return eInvalidInput;
    }
    fData = pField->getData(OD_T("SheetSetPropertyName"));
    OdString propName;
    if (!fData.get(propName))
    {
        pResult->setEvaluationStatus(OdDbField::kOtherError);
        return eInvalidInput;
    }
    OdString propValue;
    OdFdFieldEnginePEPtr pFieldEnginePE = OdFdFieldEngine::desc()->getX(OdFdFieldEnginePE::desc());
    bool found = pFieldEnginePE.isNull() ? false :
        pFieldEnginePE->getSheetSetProperty(propValue, compName, propName, pDb);
    if (!found)  // when DST was not found, do not update the text
    {
        pResult->setEvaluationStatus(OdDbField::kNotYetEvaluated);
        return eOk;
    }
    OdFieldValuePtr fValue = OdFieldValue::createObject();
    fValue->set(propValue);
    pResult->setFieldValue(fValue);
    pResult->setEvaluationStatus(OdDbField::kSuccess);
    return eOk;
}

OdResult OdSheetSetEvaluator::format(OdDbField* pField, OdString& value) const
{
    OdFieldValue fValue;
    OdResult res = pField->getValue(fValue);
    if (res != eOk) return res;
    value.empty();
    OdString format = pField->getFormat();
    if ((format.isEmpty() && fValue.get(value)) || fValue.format(format, value))
        return eOk;
    return eNotImplementedYet;
}
