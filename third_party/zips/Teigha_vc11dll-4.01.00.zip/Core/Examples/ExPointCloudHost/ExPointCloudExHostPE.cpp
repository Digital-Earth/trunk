/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

#include "OdaCommon.h"
#include "RxObjectImpl.h"
#include "ExPointCloudExHostPE.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"
//#include "Ge/GePoint3d.h"

#include "../Extensions/ExServices/OdFileBuf.h"
#include "DbHostAppServices.h"
#include "OdPlatformStreamer.h"

ODRX_CONS_DEFINE_MEMBERS( ExPointCloudExItem, OdDbPointCloudExItem, RXIMPL_CONSTR);


OdGeExtents3d ExPointCloudExItem::extents() const
{
  return m_extents;
}

OdInt64 ExPointCloudExItem::pointsCount() const
{
  return m_points.size();
}

bool ExPointCloudExItem::worldDrawPoints(const OdDbPointCloudEx* pEnt, OdGiWorldDraw* pWd) const
{
  drawPoints(pWd->geometry());
  return true;
}

void ExPointCloudExItem::viewportDrawPoints(const OdDbPointCloudEx* pEnt, OdGiViewportDraw* pWd) const
{
  drawPoints(pWd->geometry());
}

void ExPointCloudExItem::drawPoints(OdGiGeometry& geom) const
{
  OdInt32 nCount = (OdInt32)m_points.size();
  const OdGePoint3d* pPt = m_points.getPtr();
  geom.polypoint(nCount, pPt);
}

/////////////////////////////////////////////////////////////////////
ODRX_NO_CONS_DEFINE_MEMBERS(ExPointCloudExHostPE, OdDbPointCloudExHostPE);

OdResult ExPointCloudExHostPE::load(const OdString& filename, OdDbPointCloudExItemPtr& pItem)
{
  if(!::odSystemServices()->accessFile(filename, Oda::kFileRead))
    return eCantOpenFile;

  ExPointCloudExItemImplPtr exItem = ExPointCloudExItem::createObject();
  pItem = exItem;
  return eOk;
}

