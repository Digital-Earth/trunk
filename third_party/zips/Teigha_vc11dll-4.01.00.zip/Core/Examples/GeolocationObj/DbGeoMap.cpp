/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

#include "OdaCommon.h"
#include "DbGeoMap.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"
#include "DbRasterVariables.h"
#include "DbFiler.h"

#include "DbProxyEntity.h"
#include "DbProxyObject.h"
#include "RxObject.h"
#include "DbText.h"

ODRX_DEFINE_MEMBERS_EX(OdDbGeoMap, OdDbRasterImage, DBOBJECT_CONSTR,
                    OdDb::vAC27, 81, OdDbProxyEntity::kEraseAllowed,
                    L"AcDbGeoMap", L"GEOMAPIMAGE", L"AcGeolocationObj",
                    OdRx::kMTLoading|OdRx::kMTRender|OdRx::kMTRenderInBlock);


OdDbGeoMap::OdDbGeoMap()
    : OdDbRasterImage()
    , m_myBrightness(50)
    , m_myContrast(50)
    , m_myFade(0)
{}



OdDbGeoMap::~OdDbGeoMap()
{
}



OdResult OdDbGeoMap::dwgInFields(OdDbDwgFiler* pFiler)
{
  assertWriteEnabled();

  OdResult res = OdDbRasterImage::dwgInFields(pFiler);
  if (res != eOk)
    return res;

  int nI16 = pFiler->rdInt16();
  // Version ?
  if (nI16 != 0)
  {
    ODA_FAIL_ONCE();
    return eMakeMeProxy;
  }

  m_UnkId = pFiler->rdSoftPointerId();
  ODA_ASSERT_ONCE(m_UnkId.isNull());

  m_ptImageBottomLeft = pFiler->rdPoint3d();
  m_ptTextPosition = pFiler->rdPoint3d();

  m_dImageWidth = pFiler->rdDouble();
  m_dImageHeight = pFiler->rdDouble();

  m_LOD = pFiler->rdInt8();

  m_Resolution = pFiler->rdUInt8();
  ODA_ASSERT_ONCE(m_Resolution <= kFiner);

  m_MapType = pFiler->rdUInt8();
  ODA_ASSERT_ONCE(m_MapType <= kHybrid);

  m_vU = pFiler->rdVector3d();
  m_vV = pFiler->rdVector3d();

  m_myBrightness = pFiler->rdInt8();
  m_myContrast = pFiler->rdInt8();
  m_myFade = pFiler->rdInt8();
  m_bOutOfDate = pFiler->rdBool();

  m_nWidth = pFiler->rdInt32();
  m_nHeight = pFiler->rdInt32();

  OdUInt32 nBytes = m_nWidth * m_nHeight * 4;

  m_PixelData.resize(nBytes);
  if (nBytes)
  {
    pFiler->rdBytes(m_PixelData.asArrayPtr(), nBytes);
  }

  m_nInt32_1 = pFiler->rdInt32();
  ODA_ASSERT_ONCE(m_nInt32_1 == 4);
  m_nInt32_2 = pFiler->rdInt32();
  ODA_ASSERT_ONCE(m_nInt32_2 == 4);
  m_nInt32_3 = pFiler->rdInt32();
  ODA_ASSERT_ONCE(m_nInt32_3 == 8);

  m_ptBottomLeft = pFiler->rdPoint3d();
  m_ptBottomRight = pFiler->rdPoint3d();
  m_ptUpperRight = pFiler->rdPoint3d();
  m_ptUpperLeft = pFiler->rdPoint3d();

  OdInt32 nStrings = pFiler->rdInt32();
  m_strings.resize(nStrings);
  for (OdInt32 i = 0; i < nStrings; ++i)
  {
    m_strings[i] = pFiler->rdString();
  }

  m_nUInt16 = pFiler->rdInt16();
  m_nUInt32 = pFiler->rdInt32();
  m_nUInt8 = pFiler->rdInt8();

  m_dTextHeight = pFiler->rdDouble();

  int nInt16 = pFiler->rdInt16(); // Clip boundary type? 2 - polygonal
  ODA_ASSERT_ONCE(nInt16 == 2);

  OdInt32 nClipPts = pFiler->rdInt32();
  m_ptClipBnd.resize(nClipPts + 1);
  OdInt32 i;
  for (i = 0; i < nClipPts; ++i)
  {
    m_ptClipBnd[i] = pFiler->rdPoint2d();
  }
  m_ptClipBnd[i] = m_ptClipBnd[0];  // Like in DXF loading

  m_idGeoMapDef = pFiler->rdHardOwnershipId();
  
  return eOk;
}


void OdDbGeoMap::dwgOutFields(OdDbDwgFiler* pFiler) const
{
  assertReadEnabled();

  OdDbRasterImage::dwgOutFields(pFiler);

  pFiler->wrInt16(0); // Version ?

  pFiler->wrSoftPointerId(m_UnkId);

  pFiler->wrPoint3d(m_ptImageBottomLeft);
  pFiler->wrPoint3d(m_ptTextPosition);

  pFiler->wrDouble(m_dImageWidth);
  pFiler->wrDouble(m_dImageHeight);

  pFiler->wrInt8(m_LOD);
  pFiler->wrUInt8(m_Resolution);
  pFiler->wrUInt8(m_MapType);
  pFiler->wrVector3d(m_vU);
  pFiler->wrVector3d(m_vV);

  pFiler->wrInt8(m_myBrightness);
  pFiler->wrInt8(m_myContrast);
  pFiler->wrInt8(m_myFade);
  pFiler->wrBool(m_bOutOfDate);

  pFiler->wrInt32(m_nWidth);
  pFiler->wrInt32(m_nHeight);

  OdUInt32 nBytes = m_nWidth * m_nHeight * 4;
  if (nBytes)
  {
    pFiler->wrBytes(m_PixelData.asArrayPtr(), nBytes);
  }

  pFiler->wrInt32(m_nInt32_1);
  pFiler->wrInt32(m_nInt32_2);
  pFiler->wrInt32(m_nInt32_3);

  pFiler->wrPoint3d(m_ptBottomLeft);
  pFiler->wrPoint3d(m_ptBottomRight);
  pFiler->wrPoint3d(m_ptUpperRight);
  pFiler->wrPoint3d(m_ptUpperLeft);

  OdInt32 nStrings = m_strings.size();
  pFiler->wrInt32(nStrings);
  for (OdInt32 i = 0; i < nStrings; ++i)
  {
    pFiler->wrString(m_strings[i]);
  }

  pFiler->wrInt16(m_nUInt16);
  pFiler->wrInt32(m_nUInt32);
  pFiler->wrInt8(m_nUInt8);

  pFiler->wrDouble(m_dTextHeight);
  pFiler->wrInt16(2); //Clip boundary type? 2 - polygonal

  OdInt32 nClipPts = m_ptClipBnd.size();
  if (nClipPts > 3 && m_ptClipBnd[0] == m_ptClipBnd[nClipPts - 1])
    --nClipPts;

  pFiler->wrInt32(nClipPts);
  for (OdInt32 i = 0; i < nClipPts; ++i)
  {
    pFiler->wrPoint2d(m_ptClipBnd[i]);
  }
  pFiler->wrHardOwnershipId(m_idGeoMapDef);
}


OdGeoMapResolution	OdDbGeoMap::resolution() const
{
  assertReadEnabled();
  return (OdGeoMapResolution)m_Resolution;
}

OdResult OdDbGeoMap::setResolution(OdGeoMapResolution resolution)
{
  assertWriteEnabled();
  if (m_Resolution != resolution)
  {
    m_Resolution = resolution;
    m_bOutOfDate = true;
  }
  return eOk;
}

OdInt8 OdDbGeoMap::LOD() const
{
  assertReadEnabled();
  return m_LOD;
}

OdGeoMapType OdDbGeoMap::mapType() const
{
  assertReadEnabled();
  return (OdGeoMapType)m_MapType;
}

OdResult	OdDbGeoMap::setMapType(OdGeoMapType mapType)
{
  assertWriteEnabled();
  if (m_MapType != mapType)
  {
    m_MapType = mapType;
    m_bOutOfDate = true;
  }
  return eOk;
}


OdGePoint3d OdDbGeoMap::imageBottomLeftPt() const
{
  assertReadEnabled();
  return m_ptImageBottomLeft;
}

double OdDbGeoMap::imageHeight() const
{
  assertReadEnabled();
  return m_dImageHeight;
}

double OdDbGeoMap::imageWidth() const
{
  assertReadEnabled();
  return m_dImageWidth;
}

OdGeVector2d OdDbGeoMap::imageSize(bool /*bGetCachedValue = false*/) const
{
  assertReadEnabled();
  return OdGeVector2d(m_nWidth, m_nHeight);
}

OdDbObjectId OdDbGeoMap::imageDefId() const
{
  assertReadEnabled();
  return m_idGeoMapDef;
}

void OdDbGeoMap::getVertices(OdGePoint3dArray& vertices) const
{
  assertReadEnabled();
  vertices.append(m_ptBottomLeft);
  vertices.append(m_ptBottomRight);
  vertices.append(m_ptUpperRight);
  vertices.append(m_ptUpperLeft);
  vertices.append(m_ptBottomLeft);
}

const OdGePoint2dArray& OdDbGeoMap::clipBoundary() const
{
  assertReadEnabled();
  return m_ptClipBnd;
}

bool OdDbGeoMap::isOutOfDate() const
{
  assertReadEnabled();
  return m_bOutOfDate;
}

#define NEXT_CODE(code)         \
if (pFiler->nextItem() != code) \
{                               \
  ODA_FAIL_ONCE();              \
  return eMakeMeProxy;          \
}

OdResult OdDbGeoMap::dxfInFields(OdDbDxfFiler* pFiler)
{
  OdResult res = OdDbEntity::dxfInFields(pFiler);
  if (res != eOk)
  {
    ODA_FAIL_ONCE();
    return res;
  }

  if (!pFiler->atSubclassData(desc()->name()))
  {
    ODA_FAIL_ONCE();
    return eMakeMeProxy;
  }

  setDisplayOpt(OdDbRasterImage::kShow, true);  // Because RasterImage data is not saved to DXF

  NEXT_CODE(70);
  int nI16 = pFiler->rdInt16();
  // Version ?
  if (nI16 != 0)
  {
    ODA_FAIL_ONCE();
    return eMakeMeProxy;
  }
  NEXT_CODE(330);
  m_UnkId = pFiler->rdObjectId();
  ODA_ASSERT_ONCE(m_UnkId.isNull());

  NEXT_CODE(10);
  pFiler->rdPoint3d(m_ptImageBottomLeft);
  NEXT_CODE(10);
  pFiler->rdPoint3d(m_ptTextPosition);

  NEXT_CODE(40);
  m_dImageWidth = pFiler->rdDouble();
  NEXT_CODE(40);
  m_dImageHeight = pFiler->rdDouble();

  NEXT_CODE(280);
  m_LOD = pFiler->rdInt8();

  NEXT_CODE(280);
  m_Resolution = pFiler->rdUInt8();
  ODA_ASSERT_ONCE(m_Resolution <= kFiner);

  NEXT_CODE(280);
  m_MapType = pFiler->rdUInt8();
  ODA_ASSERT_ONCE(m_MapType <= kHybrid);

  NEXT_CODE(10);
  pFiler->rdVector3d(m_vU);
  NEXT_CODE(10);
  pFiler->rdVector3d(m_vV);

  NEXT_CODE(280);
  m_myBrightness = pFiler->rdInt8();
  NEXT_CODE(280);
  m_myContrast = pFiler->rdInt8();
  NEXT_CODE(280);
  m_myFade = pFiler->rdInt8();
  NEXT_CODE(290);
  m_bOutOfDate = pFiler->rdBool();

  NEXT_CODE(90);
  m_nWidth = pFiler->rdInt32();
  NEXT_CODE(90);
  m_nHeight = pFiler->rdInt32();

  OdUInt32 nBytes = m_nWidth * m_nHeight * 4;

  m_PixelData.resize(0);
  if (nBytes)
  {
    m_PixelData.reserve(nBytes);
    OdBinaryData chunk;
    while (m_PixelData.size() < nBytes)
    {
      NEXT_CODE(310);
      pFiler->rdBinaryChunk(chunk);
      m_PixelData.append(chunk);
    }
  }

  NEXT_CODE(90);
  m_nInt32_1 = pFiler->rdInt32();
  ODA_ASSERT_ONCE(m_nInt32_1 == 4);
  NEXT_CODE(90);
  m_nInt32_2 = pFiler->rdInt32();
  ODA_ASSERT_ONCE(m_nInt32_2 == 4);
  NEXT_CODE(90);
  m_nInt32_3 = pFiler->rdInt32();
  ODA_ASSERT_ONCE(m_nInt32_3 == 8);

  NEXT_CODE(10);
  pFiler->rdPoint3d(m_ptBottomLeft);
  NEXT_CODE(10);
  pFiler->rdPoint3d(m_ptBottomRight);
  NEXT_CODE(10);
  pFiler->rdPoint3d(m_ptUpperRight);
  NEXT_CODE(10);
  pFiler->rdPoint3d(m_ptUpperLeft);

  NEXT_CODE(90);
  OdInt32 nStrings = pFiler->rdInt32();
  m_strings.resize(nStrings);
  for (OdInt32 i = 0; i < nStrings; ++i)
  {
    NEXT_CODE(1);
    m_strings[i] = pFiler->rdString();
  }

  NEXT_CODE(63);
  m_nUInt16 = pFiler->rdInt16();
  NEXT_CODE(421);
  m_nUInt32 = pFiler->rdInt32();
//  m_nUInt8 = pFiler->rdInt8();

  NEXT_CODE(40);
  m_dTextHeight = pFiler->rdDouble();

  NEXT_CODE(71);
  int nInt16 = pFiler->rdInt16(); // Clip boundary type? 2 - polygonal
  ODA_ASSERT_ONCE(nInt16 == 2);

  NEXT_CODE(91);
  OdInt32 nClipPts = pFiler->rdInt32();
  m_ptClipBnd.resize(nClipPts);
  for (OdInt32 i = 0; i < nClipPts; ++i)
  {
    NEXT_CODE(14);
    pFiler->rdPoint2d(m_ptClipBnd[i]);
  }
//  m_idGeoMapDef - not saved to DXF
  
  return eOk;
}


void OdDbGeoMap::dxfOutFields(OdDbDxfFiler* pFiler) const
{
  OdDbEntity::dxfOutFields(pFiler);

  pFiler->wrSubclassMarker(desc()->name());

  pFiler->wrInt16(70, 0); // Version ?
  pFiler->wrObjectId(330, m_UnkId);

  pFiler->wrPoint3d(10, m_ptImageBottomLeft);
  pFiler->wrPoint3d(10, m_ptTextPosition);

  pFiler->wrDouble(40, m_dImageWidth);
  pFiler->wrDouble(40, m_dImageHeight);

  pFiler->wrInt8(280, m_LOD);
  pFiler->wrUInt8(280, m_Resolution);
  pFiler->wrUInt8(280, m_MapType);

  pFiler->wrVector3d(10, m_vU);
  pFiler->wrVector3d(10, m_vV);

  pFiler->wrInt8(280, m_myBrightness);
  pFiler->wrInt8(280, m_myContrast);
  pFiler->wrInt8(280, m_myFade);
  pFiler->wrBool(290, m_bOutOfDate);

  pFiler->wrInt32(90, m_nWidth);
  pFiler->wrInt32(90, m_nHeight);

  pFiler->wrBinaryChunk(310, m_PixelData.getPtr(), m_PixelData.size());

  pFiler->wrInt32(90, m_nInt32_1);
  pFiler->wrInt32(90, m_nInt32_2);
  pFiler->wrInt32(90, m_nInt32_3);

  pFiler->wrPoint3d(10, m_ptBottomLeft);
  pFiler->wrPoint3d(10, m_ptBottomRight);
  pFiler->wrPoint3d(10, m_ptUpperRight);
  pFiler->wrPoint3d(10, m_ptUpperLeft);

  OdInt32 nStrings = m_strings.size();
  pFiler->wrInt32(90, nStrings);
  for (OdInt32 i = 0; i < nStrings; ++i)
  {
    pFiler->wrString(1, m_strings[i]);
  }

  pFiler->wrInt16(63, m_nUInt16);
  pFiler->wrInt32(421, m_nUInt32);
//  pFiler->wrInt8(, m_nUInt8);   - not saved to DXF

  pFiler->wrDouble(40, m_dTextHeight);

  pFiler->wrInt16(71, 2);  // Clip boundary type? 2 - polygonal

  OdInt32 nClipPts = m_ptClipBnd.size();
  pFiler->wrInt32(91, nClipPts);
  for (OdInt32 i = 0; i < nClipPts; ++i)
  {
    pFiler->wrPoint2d(14, m_ptClipBnd[i]);
  }
//  m_idGeoMapDef - not saved to DXF
}

void OdDbGeoMap::composeForLoad(OdDb::SaveType format, OdDb::DwgVersion version, OdDbAuditInfo* pAuditInfo)
{
  // Def object is not saved to DXF and is recreated each time DXF is loaded.
  if (m_idGeoMapDef.isNull())
  {
    OdDbGeoMapDefPtr pDef = OdDbGeoMapDef::createObject();
    m_idGeoMapDef = database()->addOdDbObject(pDef, objectId());
  }
}

OdInt8 OdDbGeoMap::brightness() const
{
  assertReadEnabled();
  return m_myBrightness;
}

OdResult OdDbGeoMap::setBrightness(OdInt8 brightness)
{
  assertWriteEnabled();
  m_myBrightness = brightness;
  return eOk;
}

OdInt8 OdDbGeoMap::contrast() const
{
  assertReadEnabled();
  return m_myContrast;
}

OdResult OdDbGeoMap::setContrast(OdInt8 contrast)
{
  assertWriteEnabled();
  m_myContrast = contrast;
  return eOk;
}
OdInt8 OdDbGeoMap::fade() const
{
  assertReadEnabled();
  return m_myFade;
}

OdResult OdDbGeoMap::setFade(OdInt8 fade)
{
  assertWriteEnabled();
  m_myFade = fade;
  return eOk;
}


bool OdDbGeoMap::updateMapImage(bool)
{
  // TODO - look at protocol extension
  return true;
}

class OdGiRasterImageRGBA32 : public OdGiRasterImageBGRA32
{
public:
  OdGiRasterImage::PixelFormatInfo pixelFormat() const
  {
    OdGiRasterImage::PixelFormatInfo pf;
    pf.setRGBA();
    return pf;
  }

  static OdGiRasterImagePtr createObject(OdGiImageBGRA32 *pImage, OdGiRasterImage::TransparencyMode transparencyMode = OdGiRasterImage::kTransparency8Bit)
  {
    ODA_ASSERT(pImage);
    OdSmartPtr<OdGiRasterImageRGBA32> pIw = OdRxObjectImpl<OdGiRasterImageRGBA32>::createObject();
    pIw->m_pBGRAImage = pImage;
    pIw->m_transparencyMode = transparencyMode;
    return pIw;
  }
};

//#include "RxRasterServices.h"
OdGiRasterImagePtr OdDbGeoMap::image(bool /*load*/) const
{
  assertReadEnabled();

  OdGiImageBGRA32 * pImg = (OdGiImageBGRA32 *) &m_image;
  pImg->setImage(m_nWidth, m_nHeight, (OdGiPixelBGRA32 *)m_PixelData.asArrayPtr());
  OdGiRasterImagePtr pImage = OdGiRasterImageRGBA32::createObject(pImg);

  // Flip it
  OdSmartPtr<OdGiUpsideDownRasterTransformer> pRet
    = OdRxObjectImpl<OdGiUpsideDownRasterTransformer>::createObject();
  pRet->setOriginal(pImage);

//  OdRxRasterServicesPtr pRasSvcs = odrxDynamicLinker()->loadApp(RX_RASTER_SERVICES_APPNAME);
//  pRasSvcs->saveRasterImage(pRet, L"d:/0/##GeoMap/background.bmp");
//  pRasSvcs->saveRasterImage(pRet, L"d:/0/##GeoMap/background.png");

  return pRet;
}

bool OdDbGeoMap::subWorldDraw(OdGiWorldDraw* pWd) const
{
  OdGiRegenType regenType = pWd->regenType();
  if ( regenType == kOdGiForExtents
    || regenType == kOdGiSaveWorldDrawForProxy
    || !isSetDisplayOpt(kShow) )
  {
    OdGePoint3dArray framePoints;
    getVertices(framePoints);
    pWd->geometry().polyline(framePoints.size(), framePoints.getPtr());
    return true;
  }
  return false; // go to viewportDraw, and paint image
}

void OdDbGeoMap::subViewportDraw(OdGiViewportDraw* pVd) const
{
  assertReadEnabled();
  OdGiRasterImagePtr pRaster = image();

  pVd->geometry().rasterImageDc(
            m_ptImageBottomLeft,
            m_vU,
            m_vV,
            pRaster,
            m_ptClipBnd.asArrayPtr(), m_ptClipBnd.size(),
            isSetDisplayOpt(kTransparent),
            brightness(),
            contrast(),
            fade()
            );
  // Draw Frame
  OdGePoint3dArray framePoints;
  getVertices(framePoints);
  pVd->geometry().polyline(framePoints.size(), framePoints.getPtr());

  OdString strText;
  for (unsigned int i = 0; i < m_strings.size(); i++)
  {
    if (!m_strings[i].isEmpty())
    {
      strText += m_strings[i];
      strText += L' ';    // Last (terminating) space is required because of right alignment
    }
  }
  if (!strText.isEmpty())
  {
    OdDbTextPtr pText = OdDbText::createObject();
    pText->setTextString(strText);
    OdCmColor color;
    color.setRGB(255, 255, 255);
    pText->setColor(color);

    pText->setHorizontalMode(OdDb::kTextRight);
//    pText->setVerticalMode(OdDb::kTextTop);
//    pText->setVerticalMode(OdDb::kTextVertMid);
    pText->setHeight(m_dTextHeight);
    pText->setTextStyle(database()->getTEXTSTYLE()); // TODO

    if (!m_vU.isCodirectionalTo(OdGeVector3d::kXAxis) || !m_vV.isCodirectionalTo(OdGeVector3d::kYAxis))
    {
      OdGeVector3d vNormal = m_vU.crossProduct(m_vV);
      pText->setNormal(vNormal);
      OdGePlane plane;
      OdDb::Planarity type;
      pText->getPlane(plane, type);
      double dRotation = m_vU.angleOnPlane(plane);
      pText->setRotation(dRotation);
    }
    OdGeVector3d vDisplacement = m_vV.normal() * (m_dTextHeight * 2./3.);
    OdGePoint3d ptAlignment(m_ptTextPosition - vDisplacement);
    pText->setAlignmentPoint(ptAlignment);
    pText->adjustAlignment();

    OdGePoint3d ptPos = pText->position();
    // Check if text fits into image boundaries

    OdGeVector3d vRightToLeft(m_ptBottomLeft - m_ptBottomRight);
    OdGeVector3d vCornerToText(m_ptTextPosition - m_ptBottomRight);
    double dBoxWidth = vRightToLeft.length();
    double dRightOffset = vCornerToText.dotProduct(vRightToLeft) / dBoxWidth;
    double dDistToBoxBorder = dBoxWidth - dRightOffset;
    OdGeVector3d vAlignToPos = ptPos - ptAlignment;
    double dTextLength = vAlignToPos.length();
    if (dTextLength > dDistToBoxBorder)
    {
      ptPos = ptAlignment + vAlignToPos * (dDistToBoxBorder / dTextLength);
      pText->setHorizontalMode(OdDb::kTextAlign);
      pText->setPosition(ptPos);
      pText->adjustAlignment();
    }

    pVd->geometry().draw(pText);
  }
}

OdResult OdDbGeoMap::subGetGeomExtents(OdGeExtents3d& ext) const
{
  assertReadEnabled();
  ext = OdGeExtents3d();

  OdGePoint3dArray framePoints;
  getVertices(framePoints);
  for(OdUInt32 f=0; f<framePoints.size(); ++f)
    ext.addPoint(framePoints[f]);

  return eOk;
}

OdResult OdDbGeoMap::subTransformBy(const OdGeMatrix3d& xform)
{
  assertWriteEnabled();
  double dOldULen = m_vU.length();
  double dOldVLen = m_vV.length();
  m_vU.transformBy(xform);
  m_vV.transformBy(xform);

  double dUScale = m_vU.length() / dOldULen;
  double dVScale = m_vV.length() / dOldVLen;

  m_ptImageBottomLeft.transformBy(xform);
  m_ptTextPosition.transformBy(xform);
  m_dImageWidth *= dUScale;
  m_dImageHeight *= dVScale;
  m_dTextHeight *= dVScale;

  m_ptBottomLeft.transformBy(xform);
  m_ptBottomRight.transformBy(xform);
  m_ptUpperRight.transformBy(xform);
  m_ptUpperLeft.transformBy(xform);

  m_bOutOfDate = true;

  xDataTransformBy(xform);
  return eOk;
}

void  OdDbGeoMap::getOrientation(OdGePoint3d& origin, OdGeVector3d& u, OdGeVector3d& v) const
{
  assertReadEnabled();
  origin = m_ptImageBottomLeft;
  u = m_vU * m_nWidth;
  v = m_vV * m_nHeight;
}

////////////////////////////////////////////////////////////////////////////////////
//
//                  OdDbGeoMapDef
//
////////////////////////////////////////////////////////////////////////////////////
ODRX_DEFINE_MEMBERS_EX(OdDbGeoMapDef, OdDbRasterImageDef, DBOBJECT_CONSTR,
                    OdDb::vAC27, 81, OdDbProxyObject::kDisableProxyWarning,
                    L"AcDbGeoMapDef", L"AcDbGeoMapDef", L"AcGeolocationObj",
                    OdRx::kMTLoading);


OdDbGeoMapDef::OdDbGeoMapDef()
    : OdDbRasterImageDef()
{}


OdDbGeoMapDef::~OdDbGeoMapDef()
{
}



OdResult OdDbGeoMapDef::dwgInFields(OdDbDwgFiler* pFiler)
{
  assertWriteEnabled();

  OdResult res = OdDbObject::dwgInFields(pFiler);
  if (res != eOk)
    return res;

  int nI16 = pFiler->rdInt16();
  // Version ?
  if (nI16 != 0)
  {
    ODA_FAIL_ONCE();
    return eMakeMeProxy;
  }

  OdDbObjectId id = pFiler->rdSoftPointerId();
  if (id != ownerId())
  {
    ODA_FAIL_ONCE();
    return eMakeMeProxy;
  }
  return eOk;
}


void OdDbGeoMapDef::dwgOutFields(OdDbDwgFiler* pFiler) const
{
  assertReadEnabled();
  OdDbObject::dwgOutFields(pFiler);

  pFiler->wrInt16(0);
  pFiler->wrSoftPointerId(ownerId());
}


OdGiRasterImagePtr OdDbGeoMapDef::image(bool bReset)
{
  assertReadEnabled();
  OdDbGeoMapPtr pEnt = ownerId().safeOpenObject();
  return pEnt->image(bReset);
}
