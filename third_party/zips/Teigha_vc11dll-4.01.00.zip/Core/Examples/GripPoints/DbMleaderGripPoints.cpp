/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////


/************************************************************************/
/* This class is an implementation of the OdDbGripPointsPE class for    */
/* OdDbMline entities.                                                   */
/************************************************************************/
#include "StdAfx.h"
#include "DbMleaderGripPoints.h"
#include "DbMLeader.h"
#include "RxObjectImpl.h"
#include "DbGrip.h"
#include "Ge/GeLineSeg3d.h"

//#define  SUBENTITY_TEST 1

#ifdef SUBENTITY_TEST
#include "DbBlockTableRecord.h"
#endif

const int START_GRIP	= 1;

const int DOGLEG_START_GRIP		= START_GRIP;
const int DOGLEG_CENTER_GRIP	= START_GRIP + 1;
const int DOGLEG_END_GRIP		= START_GRIP + 2;
const int TEXT_POS_GRIP			= START_GRIP + 3;
const int BLOCK_POS_GRIP		= START_GRIP + 4;
const int LINE_START_GRIP		= START_GRIP + 5;

static OdGePoint3d ProjectPointToLine( const OdGePoint3d ptLineStart, 
									  const OdGePoint3d ptLineEnd, 
									  const OdGePoint3d ptBase )
{
	double a = ptBase.distanceTo( ptLineStart );
	double b = ptBase.distanceTo( ptLineEnd );
	double c = ptLineStart.distanceTo( ptLineEnd );

	if( c < 1e-8 )
		return ptLineStart;

	double d = (a*a+c*c-b*b)/(2*c);

	OdGePoint3d ptRet;

	ptRet.x = ptLineStart.x + (ptLineEnd.x - ptLineStart.x) * d / c;
	ptRet.y = ptLineStart.y + (ptLineEnd.y - ptLineStart.y) * d / c;
	ptRet.z = ptLineStart.z + (ptLineEnd.z - ptLineStart.z) * d / c;

	return ptRet;
}

static bool IsOnSegment( const OdGePoint3d ptSegStart, const OdGePoint3d ptSegEnd, const OdGePoint3d ptCheck )
{
	OdGeLineSeg3d pLineSeg( ptSegStart, ptSegEnd );
	return pLineSeg.isOn( ptCheck, 0);
}

OdResult OdDbMleaderGripPointsPE::getGripPoints( const OdDbEntity* ent, OdGePoint3dArray& gripPoints )const
{
#ifdef SUBENTITY_TEST

	OdDbMLeader* pMLeader = OdDbMLeader::cast(ent);

	if( GetAsyncKeyState( VK_SHIFT) )
	{
		int nPaths = 0;
		int iMarker = 0;
		int iMinMarker = 0;
		int iMaxMarker = 16000;

		for( iMarker = iMinMarker; iMarker < iMaxMarker; iMarker++ )
		{
			OdGePoint3d  ptTmp;
			OdGeMatrix3d matTmp;
			OdGeVector3d vrTmp;
			OdDbFullSubentPathArray PathArr;

			OdResult es = pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, iMarker, ptTmp, matTmp, PathArr );

			if( es == eOk && PathArr.size() > 0 )
			{
				OdDbEntityPtr pNewEnt = pMLeader->subentPtr( PathArr[0] );

				if( !pNewEnt.isNull() )
				{
					OdDbDatabase* pDb = pMLeader->database();
					OdDbBlockTableRecordPtr pMs = pDb->getModelSpaceId().safeOpenObject(OdDb::kForWrite);
					pMs->appendOdDbEntity(pNewEnt);
				}
			}
		}

		return eOk;
	}

	OdIntArray LeaderIndexArr;
	OdIntArray LeaderLineIndexArr;
	pMLeader->getLeaderIndexes(LeaderIndexArr);

	if( LeaderIndexArr.size() > 0 )
		pMLeader->getLeaderLineIndexes( LeaderIndexArr[0], LeaderLineIndexArr);

	OdDbGripDataPtrArray pGrips;

	bool bEnableDogleg = pMLeader->enableDogleg();

	if( pMLeader->leaderLineType() == OdDbMLeaderStyle::kSplineLeader ||
      pMLeader->textAttachmentDirection() == OdDbMLeaderStyle::kAttachmentVertical )
		bEnableDogleg = false;

	OdGePoint3d  ptTmp;
	OdGeMatrix3d matTmp;
	OdGeVector3d vrTmp;
	OdDbFullSubentPathArray PathArr;

	if( bEnableDogleg )
	{
		pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kDoglegMark, ptTmp, matTmp,PathArr);

		if( PathArr.size() > 0 )
		{
			OdResult iRes = getGripPointsAtSubentPath( ent, PathArr[0], pGrips, 0, 0, vrTmp, 0);

			if( iRes == eOk )
				for( unsigned int i = 0; i < pGrips.size(); i++ )
					gripPoints.append( pGrips[i]->gripPoint() );
		}
	}
	else
	{
		pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kLeaderLineMark, ptTmp, matTmp,PathArr);

		if( PathArr.size() > 0 )
		{
			OdResult iRes = getGripPointsAtSubentPath( ent, PathArr[0], pGrips, 0, 0, vrTmp, 0);

			if( iRes == eOk && pGrips.size())
				gripPoints.append( pGrips[0]->gripPoint() );
		}
	}

	for( OdUInt32 j = 0; j < LeaderLineIndexArr.size(); j++ )
	{
		PathArr.clear();
		pGrips.clear();

		pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kLeaderLineMark + LeaderLineIndexArr[j], ptTmp, matTmp,PathArr);

		if( PathArr.size() > 0 )
		{
			OdResult iRes = getGripPointsAtSubentPath( ent, PathArr[0], pGrips, 0, 0, vrTmp, 0);

			if( iRes == eOk )
				for( unsigned int i = 0; i < pGrips.size(); i++ )
				{
					if( i == 0 )
						continue;

					gripPoints.append( pGrips[i]->gripPoint() );
				}
		}
	}

	if( pMLeader->contentType() == OdDbMLeaderStyle::kMTextContent )
	{
		PathArr.clear();
		pGrips.clear();

		pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kMTextMark, ptTmp, matTmp,PathArr);

		if( PathArr.size() > 0 )
		{
			OdResult iRes = getGripPointsAtSubentPath( ent, PathArr[0], pGrips, 0, 0, vrTmp, 0);

			if( iRes == eOk )
				for( unsigned int i = 0; i < pGrips.size(); i++ )
					gripPoints.append( pGrips[i]->gripPoint() );
		}
	}

	return eOk;
#else
	OdDbMLeader* pMLeader = OdDbMLeader::cast(ent);

  if (pMLeader->leaderLineType() == OdDbMLeaderStyle::kInVisibleLeader) // #5591
    return eOk;

  bool bEnableDogleg = pMLeader->enableDogleg();

	if( pMLeader->leaderLineType() == OdDbMLeaderStyle::kSplineLeader ||
      pMLeader->textAttachmentDirection() == OdDbMLeaderStyle::kAttachmentVertical )
		bEnableDogleg = false;

	OdIntArray LeaderIndexArr;
	pMLeader->getLeaderIndexes(LeaderIndexArr);

	for( OdUInt32 i = 0; i < LeaderIndexArr.size(); i++ )
	{
		OdGePoint3d  ptConnect;
		OdGeVector3d vrDoglegDir;
		double		 dDoglegLength = 0;

		pMLeader->getDoglegDirection(LeaderIndexArr[i],vrDoglegDir);
		dDoglegLength = pMLeader->doglegLength(LeaderIndexArr[i]);
		OdResult res = pMLeader->connectionPoint( vrDoglegDir, ptConnect);

		if( res == eOk )
		{
			if( bEnableDogleg )
			{
				gripPoints.append( ptConnect );
				OdGePoint3d tmpPt1( ptConnect + vrDoglegDir * dDoglegLength/2);
				gripPoints.append( tmpPt1 );
				OdGePoint3d tmpPt2( ptConnect + vrDoglegDir * dDoglegLength);
				gripPoints.append( tmpPt2 );
			}
			else
			{
				OdGePoint3d tmpPt2( ptConnect + vrDoglegDir * dDoglegLength);
				gripPoints.append( tmpPt2 );
			}

			OdIntArray LeaderLineIndexArr;
			pMLeader->getLeaderLineIndexes( LeaderIndexArr[i], LeaderLineIndexArr);

			for( OdUInt32 k = 0; k < LeaderLineIndexArr.size(); k++ )
			{
				int nVertices = 0;
			
				res = pMLeader->numVertices( LeaderLineIndexArr[k], nVertices );

				if( res == eOk )
				{
					for( int j = 0; j < nVertices; j++ )
					{
						OdGePoint3d ptVertex;
						pMLeader->getVertex(LeaderLineIndexArr[k], j, ptVertex);
						gripPoints.append( ptVertex );
					}
				}
			}
		}
	}

	if( pMLeader->contentType() == OdDbMLeaderStyle::kBlockContent )
	{
		/*OdGePoint3d ptBlockPos;
		pMLeader->getBlockPosition( ptBlockPos );
		gripPoints.append( ptBlockPos );*/
	}
	else if( pMLeader->contentType() == OdDbMLeaderStyle::kMTextContent )
	{
		OdGePoint3d ptTextPos;
		pMLeader->getTextLocation( ptTextPos );
		gripPoints.append( ptTextPos );
	}

	return eOk;
#endif
}

OdResult OdDbMleaderGripPointsPE::moveGripPointsAt( OdDbEntity* pEnt, const OdIntArray& indices, const OdGeVector3d& offset )
{
	unsigned size = indices.size();

	if ( size == 0 )
		return eOk;

	OdDbMLeader* pMLeader = OdDbMLeader::cast(pEnt);

#ifdef SUBENTITY_TEST
	if( GetAsyncKeyState(VK_CONTROL) )
	{
		OdGePoint3d  ptTmp;
		OdGeMatrix3d matTmp;
		OdGeVector3d vrTmp;
		OdDbFullSubentPathArray PathArr;
		pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kLeaderLineMark, ptTmp, matTmp,PathArr);

		if( PathArr.size() > 0 )
			pMLeader->deleteSubentPaths( PathArr );

		return eOk;
	}
#endif

	bool bEnableDogleg = pMLeader->enableDogleg();

	if( pMLeader->leaderLineType() == OdDbMLeaderStyle::kSplineLeader ||
      pMLeader->textAttachmentDirection() == OdDbMLeaderStyle::kAttachmentVertical )
		bEnableDogleg = false;

	OdIntArray LeaderIndexArr;
	pMLeader->getLeaderIndexes(LeaderIndexArr);

	for( unsigned iPt = 0; iPt < size; iPt++ )
	{
		int iIndex = indices[iPt];
#ifdef SUBENTITY_TEST

		OdIntArray LeaderLineIndexArr;

		if( LeaderIndexArr.size() > 0 )
			pMLeader->getLeaderLineIndexes( LeaderIndexArr[0], LeaderLineIndexArr);

		OdDbGripDataPtrArray pGrips;

		OdGePoint3d  ptTmp;
		OdGeMatrix3d matTmp;
		OdGeVector3d vrTmp;
		OdDbFullSubentPathArray PathArr;
		OdDbVoidPtrArray pGripData;

		int iCurIndex = 0;

		if( bEnableDogleg && (iIndex < 3) )
		{
			pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kDoglegMark, ptTmp, matTmp,PathArr);

			if( PathArr.size() > 0 )
			{
				OdResult iRes = getGripPointsAtSubentPath( pEnt, PathArr[0], pGrips, 0, 0, vrTmp, 0);

				if( iRes == eOk )
				{
					pGripData.append( pGrips[iIndex]->appData() );
					iRes = moveGripPointsAtSubentPaths( pEnt, PathArr, pGripData, offset, 0 );
				}
			}
		}
		else if( (iIndex == 0) && !bEnableDogleg )
		{
			pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kLeaderLineMark, ptTmp, matTmp,PathArr);

			if( PathArr.size() > 0 )
			{
				OdResult iRes = getGripPointsAtSubentPath( pEnt, PathArr[0], pGrips, 0, 0, vrTmp, 0);

				if( iRes == eOk && pGrips.size() )
				{
					pGripData.append( pGrips[0]->appData() );
					iRes = moveGripPointsAtSubentPaths( pEnt, PathArr, pGripData, offset, 0 );
				}
			}
		}
		else
		{
			bool bMoveGripPt = false;

			if( bEnableDogleg )
				iCurIndex += 3;
			else
				iCurIndex++ ;

			OdUInt32 nVertices = 0;

			for( unsigned int k = 0; k < LeaderLineIndexArr.size(); k++ )
			{
				OdResult res = pMLeader->numVertices( LeaderLineIndexArr[k], nVertices );

				if( iCurIndex + nVertices <= iIndex )
					iCurIndex += nVertices;
				else
				{
					pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kLeaderLineMark + LeaderLineIndexArr[k], ptTmp, matTmp,PathArr);

					if( PathArr.size() > 0 )
					{
						OdResult iRes = getGripPointsAtSubentPath( pEnt, PathArr[0], pGrips, 0, 0, vrTmp, 0);

						if( iRes == eOk && pGrips.size() == nVertices + 1 )
						{
							pGripData.append( pGrips[ iIndex - iCurIndex + 1 ]->appData() );
							iRes = moveGripPointsAtSubentPaths( pEnt, PathArr, pGripData, offset, 0 );
						}
					}

					bMoveGripPt = true;
					break;
				}
			}

			if( !bMoveGripPt )
			{
				if( pMLeader->contentType() == OdDbMLeaderStyle::kMTextContent )
				{
					pMLeader->getSubentPathsAtGsMarker( OdDb::kClassSubentType, OdDbMLeader::kMTextMark, ptTmp, matTmp,PathArr);

					if( PathArr.size() > 0 )
					{
						OdResult iRes = getGripPointsAtSubentPath( pEnt, PathArr[0], pGrips, 0, 0, vrTmp, 0);

						if( iRes == eOk )
						{
							pGripData.append( pGrips[0]->appData() );
							iRes = moveGripPointsAtSubentPaths( pEnt, PathArr, pGripData, offset, 0 );
						}
					}
				}
			}
		}

#else
		int iCurIndex = 0;

		bool bMoveGripPt = false;

		for( OdUInt32 i = 0; i < LeaderIndexArr.size(); i++ )
		{
			OdGePoint3d  ptConnect;
			OdGeVector3d vrDoglegDir;
			double		 dDoglegLength = 0;

			pMLeader->getDoglegDirection(LeaderIndexArr[i],vrDoglegDir);
			dDoglegLength = pMLeader->doglegLength(LeaderIndexArr[i]);
			OdResult res = pMLeader->connectionPoint( vrDoglegDir, ptConnect);

			if( res == eOk )
			{
				if( bEnableDogleg )
				{
					if( iIndex - iCurIndex < 3 )
					{
						// Dogleg

						OdGePoint3d StartDoglegPt = ptConnect;
						OdGePoint3d EndDoglegPt( ptConnect + vrDoglegDir * dDoglegLength);

						if( iIndex == iCurIndex )
						{
							if( dDoglegLength < 1e-8 )
								break;

							OdGePoint3d tmpPt = ptConnect;
							tmpPt += offset;

							OdGePoint3d tmpNewPt = ProjectPointToLine(StartDoglegPt, EndDoglegPt, tmpPt );

							double dNewLength = tmpNewPt.distanceTo(EndDoglegPt);

							bool bZeroLength = true;

							if( IsOnSegment( StartDoglegPt, EndDoglegPt, tmpNewPt) || 
								( StartDoglegPt.distanceTo(tmpNewPt) < EndDoglegPt.distanceTo(tmpNewPt) )
							  )
							{
								if( dNewLength > 1e-8 )
									bZeroLength = false;
							}

							if( !bZeroLength )
								pMLeader->setDoglegLength( LeaderIndexArr[i], dNewLength );
						}
						else if( iIndex == iCurIndex + 1 )
						{
							  pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints,false);
						}
						else
						{
							if( dDoglegLength < 1e-8 )
								break;

							OdGePoint3d tmpPt = EndDoglegPt;
							tmpPt += offset;

							OdGePoint3d tmpNewPt = ProjectPointToLine(StartDoglegPt, EndDoglegPt, tmpPt );

							OdGeVector3d tmpOffset = tmpNewPt - EndDoglegPt;

							double dNewLength = tmpNewPt.distanceTo(StartDoglegPt);
							bool bZeroLength = true;

							if( IsOnSegment( StartDoglegPt, EndDoglegPt, tmpNewPt) || 
								( StartDoglegPt.distanceTo(tmpNewPt) > EndDoglegPt.distanceTo(tmpNewPt) )
							  )
							{
								if( dNewLength > 1e-8 )
									bZeroLength = false;
							}

							if( !bZeroLength )
							{
                pMLeader->moveMLeader( tmpOffset, OdDbMLeader::kMoveContentAndDoglegPoints,false);
								pMLeader->setDoglegLength( LeaderIndexArr[i], dNewLength );
							}
						}

						bMoveGripPt = true;
						break;
					}
					else
						iCurIndex += 3;
				}
				else
				{
					if( iIndex == iCurIndex )
					{
						pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
						bMoveGripPt = true;
						break;
					}
					else
						iCurIndex++;
				}
			}

			if( bMoveGripPt )
				break;

			OdIntArray LeaderLineIndexArr;
			pMLeader->getLeaderLineIndexes( LeaderIndexArr[i], LeaderLineIndexArr);

			for( OdUInt32 k = 0; k < LeaderLineIndexArr.size(); k++ )
			{
				int nVertices = 0;

				res = pMLeader->numVertices( LeaderLineIndexArr[k], nVertices );

				if( res == eOk )
				{
					for( int j = 0; j < nVertices; j++ )
					{
						if( iIndex == iCurIndex )
						{
							// line pt
							OdGePoint3d ptVertex;
							pMLeader->getVertex( LeaderLineIndexArr[k],j,ptVertex);
							ptVertex += offset;
							pMLeader->setVertex( LeaderLineIndexArr[k],j,ptVertex);
							bMoveGripPt = true;
							break;
						}
						else
							iCurIndex++;
					}

					if( bMoveGripPt )
						break;
				}

				if( bMoveGripPt )
					break;
			}

      if( bMoveGripPt )
					break;
		}

		if( bMoveGripPt )
			continue;

		if( pMLeader->contentType() == OdDbMLeaderStyle::kBlockContent )
		{
			if( iIndex == iCurIndex )
			{
				// block pt
				pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
				bMoveGripPt = true;
				break;
			}
			else
				iCurIndex++;
		}
		else if( pMLeader->contentType() == OdDbMLeaderStyle::kMTextContent )
		{
			if( iIndex == iCurIndex )
			{
				pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
				bMoveGripPt = true;
				break;
			}
			else
				iCurIndex++;
		}
#endif
	}

	return eOk;
}

OdResult OdDbMleaderGripPointsPE::getStretchPoints( const OdDbEntity* ent, OdGePoint3dArray& stretchPoints ) const
{
	return getGripPoints( ent, stretchPoints );
}

OdResult OdDbMleaderGripPointsPE::moveStretchPointsAt( OdDbEntity* ent, const OdIntArray& indices, const OdGeVector3d& offset )
{
	return moveGripPointsAt( ent, indices, offset );
}

OdResult OdDbMleaderGripPointsPE::getOsnapPoints(const OdDbEntity* ent, 
											   OdDb::OsnapMode osnapMode, 
											   OdGsMarker gsSelectionMark, 
											   const OdGePoint3d& pickPoint,
											   const OdGePoint3d& lastPoint, 
											   const OdGeMatrix3d& xWorldToEye, 
											   OdGePoint3dArray& snapPoints) const
{
	OdResult res;
	OdRxObjectPtrArray arrExploded;
	res = ent->explode(arrExploded);
	if (res != eOk)
		return res;

	for (unsigned int i = 0; i < arrExploded.size(); ++i)
	{
		OdDbEntityPtr pEnt = OdDbEntity::cast(arrExploded[i]);
		if (!pEnt.isNull())
		{
			pEnt->getOsnapPoints( osnapMode, gsSelectionMark,
				pickPoint, lastPoint, xWorldToEye, snapPoints);
		}
	}
	return eOk;
}

OdResult OdDbMleaderGripPointsPE::getGripPointsAtSubentPath(  const OdDbEntity* pEntity, 
															  const OdDbFullSubentPath& path, 
															  OdDbGripDataPtrArray& grips,
															  const double curViewUnitSize, 
															  const int gripSize,
															  const OdGeVector3d& curViewDir, 
															  const OdUInt32 bitflags) const
{
	OdDbMLeader*	 pMLeader = OdDbMLeader::cast(pEntity);
	int gsMarker = (int)path.subentId().index();

	if( gsMarker < OdDbMLeader::kLeaderLineMark || gsMarker >= OdDbMLeader::kBlockAttribute )
		return eOk;

	bool bEnableDogleg = pMLeader->enableDogleg();

	if( pMLeader->leaderLineType() == OdDbMLeaderStyle::kSplineLeader ||
      pMLeader->textAttachmentDirection() == OdDbMLeaderStyle::kAttachmentVertical )
		bEnableDogleg = false;

	OdIntArray LeaderIndexArr;
	pMLeader->getLeaderIndexes(LeaderIndexArr);

	if( bEnableDogleg && gsMarker >= OdDbMLeader::kDoglegMark && gsMarker < OdDbMLeader::kMTextMark )
	{
		for( OdUInt32 i = 0; i < LeaderIndexArr.size(); i++ )
		{
			if( gsMarker != OdDbMLeader::kDoglegMark + LeaderIndexArr[i] )
				continue;

			OdGePoint3d  ptConnect;
			OdGeVector3d vrDoglegDir;
			double		 dDoglegLength = 0;

			pMLeader->getDoglegDirection(LeaderIndexArr[i],vrDoglegDir);
			dDoglegLength = pMLeader->doglegLength(LeaderIndexArr[i]);
			OdResult res = pMLeader->connectionPoint( vrDoglegDir, ptConnect);

			if( res == eOk )
			{
				OdDbGripData *pGrip1 = new OdDbGripData();
        pGrip1->setAppData(OdIntToPtr(DOGLEG_START_GRIP));
				pGrip1->setGripPoint(ptConnect);
				grips.append(pGrip1);

				OdGePoint3d tmpPt1( ptConnect + vrDoglegDir * dDoglegLength/2);

				OdDbGripData *pGrip2 = new OdDbGripData();
				pGrip2->setAppData(OdIntToPtr(DOGLEG_CENTER_GRIP));
				pGrip2->setGripPoint(tmpPt1);
				grips.append(pGrip2);

				OdGePoint3d tmpPt2( ptConnect + vrDoglegDir * dDoglegLength);

				OdDbGripData *pGrip3 = new OdDbGripData();
				pGrip3->setAppData(OdIntToPtr(DOGLEG_END_GRIP));
				pGrip3->setGripPoint(tmpPt2);
				grips.append(pGrip3);
			}

			break;
		}
	}
	else if( gsMarker >= OdDbMLeader::kLeaderLineMark && gsMarker < OdDbMLeader::kDoglegMark )
	{
		bool bAddGrips = false;

		for( OdUInt32 i = 0; i < LeaderIndexArr.size(); i++ )
		{
			OdGePoint3d  ptConnect;
			OdGeVector3d vrDoglegDir;
			double		 dDoglegLength = 0;
			OdGePoint3d  ptFirst;

			pMLeader->getDoglegDirection(LeaderIndexArr[i],vrDoglegDir);
			dDoglegLength = pMLeader->doglegLength(LeaderIndexArr[i]);
			OdResult res = pMLeader->connectionPoint( vrDoglegDir, ptConnect);

			if( res == eOk )
			{
				if( bEnableDogleg )
					ptFirst =  ptConnect;
				else
					ptFirst =  ptConnect + vrDoglegDir * dDoglegLength;

				OdIntArray LeaderLineIndexArr;
				pMLeader->getLeaderLineIndexes( LeaderIndexArr[i], LeaderLineIndexArr);

				for( OdUInt32 k = 0; k < LeaderLineIndexArr.size(); k++ )
				{
					if( gsMarker != OdDbMLeader::kLeaderLineMark + LeaderLineIndexArr[k] )
						continue;

					int nVertices = 0;

					res = pMLeader->numVertices( LeaderLineIndexArr[k], nVertices );

					if( res == eOk )
					{
						OdDbGripData *pGrip = new OdDbGripData();
						pGrip->setAppData(OdIntToPtr(LINE_START_GRIP));
						pGrip->setGripPoint(ptFirst);
						grips.append(pGrip);

						for( int j = 0; j < nVertices; j++ )
						{
							OdGePoint3d ptVertex;
							pMLeader->getVertex(LeaderLineIndexArr[k], j, ptVertex);

							OdDbGripData *pGrip1 = new OdDbGripData();
							pGrip1->setAppData(OdIntToPtr(LINE_START_GRIP + j + 1));
							pGrip1->setGripPoint(ptVertex);
							grips.append(pGrip1);
						}
					}

					bAddGrips = true;
					break;
				}
			}

			if( bAddGrips )
				break;
		}
	}
	else if( gsMarker >= OdDbMLeader::kMTextMark )
	{
		if( pMLeader->contentType() == OdDbMLeaderStyle::kBlockContent )
		{
			if( gsMarker == OdDbMLeader::kBlockMark )
			{
				//OdGePoint3d ptBlockPos;
				//pMLeader->getBlockPosition( ptBlockPos );
				//OdDbGripData *pGrip = new OdDbGripData();
				//pGrip->setAppData(reinterpret_cast<void*>(BLOCK_POS_GRIP));
				//pGrip->setGripPoint(ptBlockPos);
				//grips.append(pGrip);
			}
		}
		else if( pMLeader->contentType() == OdDbMLeaderStyle::kMTextContent )
		{
			if( gsMarker == OdDbMLeader::kMTextMark )
			{
				OdGePoint3d ptTextPos;
				pMLeader->getTextLocation( ptTextPos );
				OdDbGripData *pGrip = new OdDbGripData();
				pGrip->setAppData(OdIntToPtr(TEXT_POS_GRIP));
				pGrip->setGripPoint(ptTextPos);
				grips.append(pGrip);
			}
		}
	}

	return eOk;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////

OdResult OdDbMleaderGripPointsPE::moveGripPointsAtSubentPaths( OdDbEntity* pEntity,
															   const OdDbFullSubentPathArray& paths, 
															   const OdDbVoidPtrArray& gripAppData,
															   const OdGeVector3d& offset, 
															   const OdUInt32 bitflags)
{
	OdDbMLeader*	 pMLeader = OdDbMLeader::cast(pEntity);
	bool bEnableDogleg = pMLeader->enableDogleg();

	if( pMLeader->leaderLineType() == OdDbMLeaderStyle::kSplineLeader ||
      pMLeader->textAttachmentDirection() == OdDbMLeaderStyle::kAttachmentVertical )
		bEnableDogleg = false;

	OdIntArray LeaderIndexArr;
	pMLeader->getLeaderIndexes(LeaderIndexArr);

	for( OdUInt32 i = 0; i < paths.size(); i++ )
	{
		OdDbObjectIdArray pArr = paths[i].objectIds();

		OdDbObjectId CurId = pArr[ pArr.size() - 1 ];
		OdDbObjectId ObjId = pMLeader->id();

		if( CurId != ObjId )
			continue;

		int gsMarker  = (int)paths[i].subentId().index();
		OdInt32 iGripType = OdPtrToInt32(gripAppData.at(i));

		if( gsMarker < OdDbMLeader::kLeaderLineMark || gsMarker >= OdDbMLeader::kBlockAttribute )
			continue;

		if( gsMarker >= OdDbMLeader::kDoglegMark && gsMarker < OdDbMLeader::kMTextMark )
		{
			for( OdUInt32 i = 0; i < LeaderIndexArr.size(); i++ )
			{
				if( gsMarker != OdDbMLeader::kDoglegMark + LeaderIndexArr[i] )
					continue;

				OdGePoint3d  ptConnect;
				OdGeVector3d vrDoglegDir;
				double		 dDoglegLength = 0;

				pMLeader->getDoglegDirection(LeaderIndexArr[i],vrDoglegDir);
				dDoglegLength = pMLeader->doglegLength(LeaderIndexArr[i]);
				OdResult res = pMLeader->connectionPoint( vrDoglegDir, ptConnect);

				if( res == eOk )
				{
					if( bEnableDogleg )
					{
						OdGePoint3d StartDoglegPt = ptConnect;
						OdGePoint3d EndDoglegPt( ptConnect + vrDoglegDir * dDoglegLength);

						if( iGripType == DOGLEG_START_GRIP )
						{
							if( dDoglegLength < 1e-8 )
								break;

							OdGePoint3d tmpPt = ptConnect;
							tmpPt += offset;

							OdGePoint3d tmpNewPt = ProjectPointToLine(StartDoglegPt, EndDoglegPt, tmpPt );

							double dNewLength = tmpNewPt.distanceTo(EndDoglegPt);

							bool bZeroLength = true;

							if( IsOnSegment( StartDoglegPt, EndDoglegPt, tmpNewPt) || 
								( StartDoglegPt.distanceTo(tmpNewPt) < EndDoglegPt.distanceTo(tmpNewPt) )
							  )
							{
								if( dNewLength > 1e-8 )
									bZeroLength = false;
							}

							if( !bZeroLength )
							{
								OdGeVector3d vrNewOffset = tmpNewPt - ptConnect;
								pMLeader->moveMLeader( vrNewOffset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
								pMLeader->setDoglegLength( LeaderIndexArr[i], dNewLength );
							}
						}
						else if( iGripType == DOGLEG_CENTER_GRIP )
						{
							pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
						}
						else if( iGripType == DOGLEG_END_GRIP )
						{
							if( dDoglegLength < 1e-8 )
								break;

							OdGePoint3d tmpPt = EndDoglegPt;
							tmpPt += offset;

							OdGePoint3d tmpNewPt = ProjectPointToLine(StartDoglegPt, EndDoglegPt, tmpPt );

							OdGeVector3d tmpOffset = tmpNewPt - EndDoglegPt;

							double dNewLength = tmpNewPt.distanceTo(StartDoglegPt);
							bool bZeroLength = true;

							if( IsOnSegment( StartDoglegPt, EndDoglegPt, tmpNewPt) || 
								( StartDoglegPt.distanceTo(tmpNewPt) > EndDoglegPt.distanceTo(tmpNewPt) )
							  )
							{
								if( dNewLength > 1e-8 )
									bZeroLength = false;
							}

							if( !bZeroLength )
							{
								pMLeader->setDoglegLength( LeaderIndexArr[i], dNewLength );
							}
						}
					}
				}
			}
		}
		else if( gsMarker >= OdDbMLeader::kLeaderLineMark && gsMarker < OdDbMLeader::kDoglegMark )
		{
			bool bMoveGripPt = false;

			for( OdUInt32 i = 0; i < LeaderIndexArr.size(); i++ )
			{
				OdIntArray LeaderLineIndexArr;
				pMLeader->getLeaderLineIndexes( LeaderIndexArr[i], LeaderLineIndexArr);

				for( OdUInt32 k = 0; k < LeaderLineIndexArr.size(); k++ )
				{
					if( gsMarker != OdDbMLeader::kLeaderLineMark + LeaderLineIndexArr[k] )
						continue;

					int nVertices = 0;

					OdResult res = pMLeader->numVertices( LeaderLineIndexArr[k], nVertices );

					if( res == eOk )
					{
						if( iGripType == LINE_START_GRIP && !bEnableDogleg)
						{
							pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
						}
						else if( iGripType > LINE_START_GRIP && iGripType <= (OdInt32)(LINE_START_GRIP + nVertices) )
						{
							OdInt32 iVertex = iGripType - LINE_START_GRIP - 1;
							OdGePoint3d ptVertex;
							pMLeader->getVertex( LeaderLineIndexArr[k],iVertex,ptVertex);
							ptVertex += offset;
							pMLeader->setVertex( LeaderLineIndexArr[k],iVertex,ptVertex);
							bMoveGripPt = true;
							break;
						}
					}
				}

				if( bMoveGripPt )
					break;
			}
		}
		else if( gsMarker >= OdDbMLeader::kMTextMark )
		{
			if( pMLeader->contentType() == OdDbMLeaderStyle::kBlockContent )
			{
				if( gsMarker == OdDbMLeader::kBlockMark && iGripType == BLOCK_POS_GRIP )
					pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
			}
			else if( pMLeader->contentType() == OdDbMLeaderStyle::kMTextContent )
			{
				if( gsMarker == OdDbMLeader::kMTextMark && iGripType == TEXT_POS_GRIP )
					pMLeader->moveMLeader( offset, OdDbMLeader::kMoveContentAndDoglegPoints, false);
			}
		}
	}

	return eOk;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
