/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

#include "OdaCommon.h"
#include "Spa_extrude_Command.h"
#include "RxDynamicModule.h"
#include "Ed/EdUserIO.h"
#include "DbCommandContext.h"
#include "StaticRxObject.h"

#include "DbRegion.h"
#include "Db3dSolid.h"
#include "DbSweepOptions.h"
#include "OdErrorContext.h"
#include "DbBlockTableRecord.h"
#include "DbCurve.h"

class ExtrudePathFilter : public OdStaticRxObject<OdEdSSetTracker>
{
public:

  ExtrudePathFilter( )
  {}

  int addDrawables(OdGsView* ) { return 0; }
  void removeDrawables(OdGsView* ) { }

  bool check(const OdDbObjectId& entId)
  {
    OdDbEntityPtr pEnt = entId.openObject();
    return true;//pEnt->isKindOf(OdDbRegion::desc()) || pEnt->isKindOf(OdDb3dSolid::desc());
  }

  bool append(const OdDbObjectId& entId, const OdDbSelectionMethod* )
  {
    return check(entId);
  }

  bool remove(const OdDbObjectId& entId, const OdDbSelectionMethod* )
  {
    return check(entId);
  }
};

class ExtrudeFilter : public OdStaticRxObject<OdEdSSetTracker>
{
public:

  ExtrudeFilter( )
  {}

  int addDrawables(OdGsView* ) { return 0; }
  void removeDrawables(OdGsView* ) { }

  bool check(const OdDbObjectId& entId)
  {
    OdDbEntityPtr pEnt = entId.openObject();
    return true;//pEnt->isKindOf(OdDbRegion::desc()) || pEnt->isKindOf(OdDb3dSolid::desc());
  }

  bool append(const OdDbObjectId& entId, const OdDbSelectionMethod* )
  {
    return check(entId);
  }

  bool remove(const OdDbObjectId& entId, const OdDbSelectionMethod* )
  {
    return check(entId);
  }
};

void ExtrudeCommand::execute(OdEdCommandContext* pCmdCtx)
{
  try
  {
    OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
    OdDbDatabasePtr pDb = pDbCmdCtx->database();
    OdSmartPtr<OdDbUserIO> pIO = pDbCmdCtx->userIO();
    if (pIO.isNull())
      return;

    ExtrudeFilter filter;
    OdDbSelectionSetPtr pSet = pIO->select(OD_T("Select objects to extrude:"), OdEd::kSelSingleEntity, 0, OdString::kEmpty, &filter);

    if (pSet->numEntities() == 0)
    {
      pIO->putString(OD_T("Nothing selected."));
      return;
    }
    if (pSet->numEntities() != 1)
    {
      pIO->putString(OD_T("Single entity selection supported only."));
      return;
    }

    OdUInt32 nKeyword = 4;
    double dHeight = 0., dTaper = 0.;
      
  startOfEntering:
    try
    {
      dHeight = pIO->getReal(OD_T("Specify height of extrusion or [Direction/Path/Taper angle]:"), 
        OdEd::kInpDefault, 0., OD_T("Direction Path TaperAngle"));
    }
    catch (OdEdKeyword &key)
    {
      nKeyword = key.keywordIndex();
    }

    switch(nKeyword)
    {
      case 0://Direction
      {
        OdGePoint3d ptStart =  pIO->getPoint(OD_T("Specify start point of direction:"));
        OdGePoint3d ptEnd =  pIO->getPoint(OD_T("Specify end point of direction:"));

        // open selected entity
        OdDbSelectionSetIteratorPtr pIt = pSet->newIterator();
        OdDbEntityPtr pE ( pIt->objectId().safeOpenObject(OdDb::kForWrite) );

        // fill SweepOptions
        OdDbSweepOptions opt;
        opt.setTwistAngle(dTaper);
        
        OdDb3dSolidPtr pS = OdDb3dSolid::createObject();
        OdResult res = pS->createExtrudedSolid(pE, ptEnd - ptStart, opt);
        if (res != eOk)
        {
          OdString tmp;
          tmp.format(OD_T("Error : %s"), OdError(res).description().c_str());
          pIO->putString(tmp);
          return;
        }

        OdDbObjectId ownerId = pE->ownerId();
        if (ownerId && ownerId.database())
        {
          OdDbBlockTableRecordPtr pBlock = ownerId.openObject(OdDb::kForWrite);
          pBlock->appendOdDbEntity( pS );
          pE->erase();
        }
      }
      break;
      case 1://Path
      {
        OdDbSelectionSetPtr pPathSet;
        try
        {
          ExtrudePathFilter filter;
          pPathSet = pIO->select(OD_T("Select extrusion path or [Taper angle]:"), OdEd::kSelAllowEmpty|OdEd::kSelSingleEntity, 0, OD_T("TaperAngle"), &filter);
        }
        catch (OdEdKeyword &)
        {
          dTaper = pIO->getReal(OD_T("Specify angle of taper for extrusion :"), OdEd::kInpDefault, 0.);

          ExtrudePathFilter filter;
          pPathSet = pIO->select(OD_T("Select extrusion path:"), OdEd::kSelAllowEmpty|OdEd::kSelSingleEntity, 0, OdString::kEmpty, &filter);
        }

        if (pPathSet->numEntities())
        {
          OdDbSelectionSetIteratorPtr pIt = pSet->newIterator();
          OdDbObjectPtr pObj = pIt->objectId().safeOpenObject(OdDb::kForWrite);

          OdDbRegionPtr pRegion = OdDbRegion::cast(pObj);
          if (pRegion.isNull())
          {
            pIO->putString(OD_T("Only Regions supported."));
            return;
          }

          OdDb3dSolidPtr pNewSolid = OdDb3dSolid::createObject();

          OdDbSelectionSetIteratorPtr pIter = pPathSet->newIterator();
          OdDbCurvePtr pCurve = OdDbCurve::cast(pIter->objectId().safeOpenObject(OdDb::kForRead));

          OdResult res = pNewSolid->extrudeAlongPath(pRegion, pCurve, dTaper);
          if (res != eOk)
          {
            OdString tmp;
            tmp.format(OD_T("Error : %s"), OdError(res).description().c_str());
            pIO->putString(tmp);
            return;
          }

          OdDbObjectId ownerId = pRegion->ownerId();
          if (ownerId && ownerId.database())
          {
            OdDbBlockTableRecordPtr pBlock = ownerId.openObject(OdDb::kForWrite);
            pBlock->appendOdDbEntity( pNewSolid );
            pRegion->erase();
          }
        }
      }
      break;
      case 2://TaperAngle
        dTaper = pIO->getReal(OD_T("Specify angle of taper for extrusion :"), OdEd::kInpDefault, 0.);
        goto startOfEntering;
        break;
      case 4://height
      {
        OdDbSelectionSetIteratorPtr pIt = pSet->newIterator();
        OdDbObjectPtr pObj = pIt->objectId().safeOpenObject(OdDb::kForWrite);

        OdDbRegionPtr pRegion = OdDbRegion::cast(pObj);
        if (pRegion.isNull())
        {
          pIO->putString(OD_T("Only Regions supported."));
          return;
        }

        OdDb3dSolidPtr pNewSolid = OdDb3dSolid::createObject();

        OdResult res = pNewSolid->extrude(pRegion, dHeight, dTaper);
        if (res != eOk)
        {
          OdString tmp;
          tmp.format(OD_T("Error : %s"), OdError(res).description().c_str());
          pIO->putString(tmp);
          return;
        }

        OdDbObjectId ownerId = pRegion->ownerId();
        if (ownerId && ownerId.database())
        {
          OdDbBlockTableRecordPtr pBlock = ownerId.openObject(OdDb::kForWrite);
          pBlock->appendOdDbEntity( pNewSolid );
          pRegion->erase();
        }
      }
      break;
    }
  }
  // catch  all exceptions
  catch (...)
  {

  }
}
