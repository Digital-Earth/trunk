/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

// PurgeCommand.cpp: implementation of the PurgeCommand class.
//
//////////////////////////////////////////////////////////////////////

#include "OdaCommon.h"
#include "Spa_union_Command.h"

#include "DbDatabase.h"
#include "DbEntity.h"
#include "DbCommandContext.h"
#include "DbSSet.h"
#include "DbBlockTableRecord.h"
#include "DbBlockReference.h"
#include "DbHostAppServices.h"
#include "Ge/GeScale3d.h"
#include "DbErrorInvalidSysvar.h"
#include "SysVarInfo.h"
#include "StaticRxObject.h"
#include "DbUserIO.h"
#include "DbRegion.h"
#include "DbBody.h"
#include "Db3dSolid.h"
#include "DbSurface.h"

class BooleanFilter : public OdStaticRxObject<OdEdSSetTracker>
{
public:
  
  BooleanFilter( )
  {}

  int addDrawables(OdGsView* ) { return 0; }
  void removeDrawables(OdGsView* ) { }

  bool check(const OdDbObjectId& entId)
  {
    OdDbEntityPtr pEnt = entId.openObject();
    return pEnt->isKindOf(OdDbRegion::desc()) || pEnt->isKindOf(OdDb3dSolid::desc()) || pEnt->isKindOf(OdDbSurface::desc());
  }

  bool append(const OdDbObjectId& entId, const OdDbSelectionMethod* )
  {
    return check(entId);
  }

  bool remove(const OdDbObjectId& entId, const OdDbSelectionMethod* )
  {
    return check(entId);
  }
};


void UnionCommand::execute(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdDbUserIOPtr pIO = pDbCmdCtx->dbUserIO();

  BooleanFilter filter;
  OdDbSelectionSetPtr pSet = pIO->select(OD_T("Select objects:"), OdEd::kSelAllowEmpty, 0, OdString::kEmpty, &filter);
  
  if (pSet->numEntities() >= 2)
  {
    OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
    OdDbRegionPtr pMainReg;
    OdDb3dSolidPtr pMainSolid;
    OdDbSurfacePtr pMainSurf, pMainRet;
    while ( !pIter->done() )
    {
      OdDbObjectId objId  = pIter->objectId();
      OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
      if( !pEnt.isNull())
      {
        if(pEnt->isKindOf(OdDb3dSolid::desc()))
        {
          if (pMainSolid.isNull())
            pMainSolid = OdDb3dSolidPtr(pEnt);
          else
          {
            pMainSolid->booleanOper(OdDb::kBoolUnite, OdDb3dSolidPtr(pEnt));
            pEnt->erase();
          }
        }
        if(pEnt->isKindOf(OdDbRegion::desc()))
        {
          if (pMainReg.isNull())
            pMainReg = OdDbRegionPtr(pEnt);
          else
          {
            pMainReg->booleanOper(OdDb::kBoolUnite, OdDbRegionPtr(pEnt));
            pEnt->erase();
          }
        }
        if(pEnt->isKindOf(OdDbSurface::desc()))
        {
          if (pMainSurf.isNull())
            pMainSurf = OdDbSurfacePtr(pEnt);
          else
          {
            OdDbDatabase* pDatabase = pDbCmdCtx->database();
            OdDbBlockTableRecordPtr pMs = pDatabase->getModelSpaceId().safeOpenObject(OdDb::kForWrite);

            pMainSurf->booleanUnion(OdDbSurfacePtr(pEnt), pMainRet);
            pMs->appendOdDbEntity(pMainRet);
            pEnt->erase();
            pMainSurf->erase();
          }
        }
      }
      pIter->next();
    }
  }
}

void IntersectSurfCommand::execute(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdDbUserIOPtr pIO = pDbCmdCtx->dbUserIO();
  OdDbDatabase* pDatabase = pDbCmdCtx->database();
  OdDbBlockTableRecordPtr pMs = pDatabase->getModelSpaceId().safeOpenObject(OdDb::kForWrite);

  BooleanFilter filter;
  OdDbSelectionSetPtr pSet = pIO->select(OD_T("Select surface:"), OdEd::kSelAllowEmpty, 0, OdString::kEmpty, &filter);
  OdDbSelectionSetPtr pSet2 = pIO->select(OD_T("Select surfase or 3dsolid:"), OdEd::kSelAllowEmpty, 0, OdString::kEmpty, &filter);
  
  if (pSet->numEntities() < 2 && pSet2->numEntities() < 2)
  {
    OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
    OdDbSelectionSetIteratorPtr pIter2 = pSet2->newIterator();

    OdResult res = eInvalidInput;
    if ( pIter->done() || pIter2->done())
      return;

    
    OdDbObjectId objId  = pIter->objectId();
    OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
    OdDbObjectId objId2  = pIter2->objectId();
    OdDbEntityPtr pEnt2  = objId2.openObject( OdDb::kForWrite );

    if( !pEnt.isNull() && !pEnt2.isNull() && pEnt->isKindOf(OdDbSurface::desc()) && (pEnt2->isKindOf(OdDbSurface::desc()) || pEnt2->isKindOf(OdDb3dSolid::desc())))
    {
      OdDbEntityPtrArray entArr;
      if(pEnt2->isKindOf(OdDb3dSolid::desc()))
        res = OdDbSurfacePtr(pEnt)->booleanIntersect(OdDb3dSolidPtr(pEnt2), entArr);
      if(pEnt2->isKindOf(OdDbSurface::desc()))
        res = OdDbSurfacePtr(pEnt)->booleanIntersect(OdDbSurfacePtr(pEnt2), entArr);
      else
        res = OdDbSurfacePtr(pEnt)->createInterferenceObjects(entArr, pEnt2, 0);

      int size = entArr.length();
      for (int i = 0; i < size; ++i)
      {
        pMs->appendOdDbEntity(entArr[i]);
      }
    }
  }
}

void IntersectCommand::execute(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);
  OdDbUserIOPtr pIO = pDbCmdCtx->dbUserIO();

  BooleanFilter filter;
  OdDbSelectionSetPtr pSet = pIO->select(OD_T("Select objects:"), OdEd::kSelAllowEmpty, 0, OdString::kEmpty, &filter);

  if (pSet->numEntities() >= 2)
  {
    OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
    OdDbRegionPtr pMainReg;
    OdDb3dSolidPtr pMainSolid, pWorkSolid;
    OdResult res = eOk;
    while ( !pIter->done() && eOk == res)
    {
      OdDbObjectId objId  = pIter->objectId();
      OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
      if( !pEnt.isNull())
      {
        if(pEnt->isKindOf(OdDb3dSolid::desc()))
        {
          if (pMainSolid.isNull())
          {
            pWorkSolid = OdDb3dSolid::createObject();
            pWorkSolid->copyFrom(pEnt);
            pMainSolid = OdDb3dSolidPtr(pEnt);
          }
          else
            res = pWorkSolid->booleanOper(OdDb::kBoolIntersect, OdDb3dSolidPtr(pEnt));
        }
      }
      pIter->next();
    }

    if(eOk == res)
    {
      pMainSolid->copyFrom(pWorkSolid);
      pIter = pSet->newIterator();
      while ( !pIter->done())
      {
        OdDbObjectId objId  = pIter->objectId();
        OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
        if( !pEnt.isNull())
        {
          if(pEnt->isKindOf(OdDb3dSolid::desc()) && pMainSolid.get() != pEnt.get())
          {
            pEnt->erase();
          }
          if(pEnt->isKindOf(OdDbRegion::desc()))
          {
            if (pMainReg.isNull())
              pMainReg = OdDbRegionPtr(pEnt);
            else
            {
              res = pMainReg->booleanOper(OdDb::kBoolIntersect, OdDbRegionPtr(pEnt));
              pEnt->erase();
            }
          }
        }
        pIter->next();
      }
      if (eOk != res)
      {
        pMainReg->erase();
      }
    }
  }
}

namespace{
  template <class tEntPtr, class tEnt> void unionEnt(OdDbSelectionSetPtr pSet, tEntPtr & pMain, tEntPtr & pWork)
  {
    OdResult res = eOk;
    OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
    while ( !pIter->done() )
    {
      OdDbObjectId objId  = pIter->objectId();
      OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
      if( !pEnt.isNull())
      {
        if(pEnt->isKindOf(tEnt::desc()))
        {
          if (pMain.isNull())
          {
            pWork = tEnt::createObject();
            pWork->copyFrom(pEnt);
            pMain = tEntPtr(pEnt);
          }
          else
          {
            res = pWork->booleanOper(OdDb::kBoolUnite, tEntPtr(pEnt));
          }
        }
      }
      pIter->next();
    }
  }

  template <class tEntPtr> void clearEnt(OdDbSelectionSetPtr pSet, OdDbObjectId pObjId)
  {
    OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
    while ( !pIter->done() )
    {
      OdDbObjectId objId  = pIter->objectId();
      OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
      if( !pEnt.isNull())
      {
        if(pEnt->isKindOf(tEntPtr::desc()))
        {
          if (pObjId != pEnt->objectId())
          {
            pEnt->erase();
          }
        }
      }
      pIter->next();
    }
  }
}


void SubtractCommand::execute(OdEdCommandContext* pCmdCtx)
{
  OdDbCommandContextPtr pDbCmdCtx(pCmdCtx);           
  OdDbUserIOPtr pIO = pDbCmdCtx->dbUserIO();

  BooleanFilter filter;
  OdDbSelectionSetPtr pSet = pIO->select(OD_T("Select objects:"), OdEd::kSelAllowEmpty, 0, OdString::kEmpty, &filter);
  OdDbSelectionSetPtr pSet2 = pIO->select(OD_T("Select objects:"), OdEd::kSelAllowEmpty, 0, OdString::kEmpty, &filter);

  if (pSet->numEntities() >= 1 && pSet2->numEntities() >= 1)
  {
    OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
    while ( !pIter->done())
    {
      OdDbObjectId objId  = pIter->objectId();
      OdDbSelectionSetIteratorPtr pIter2 = pSet2->newIterator();
      while ( !pIter2->done())
      {
        if (objId == pIter2->objectId())
        {
          pSet2->remove(pIter2->objectId());
          break;
        }
        pIter2->next();
      }
      pIter->next();
    }
  }

  if (pSet->numEntities() >= 1 && pSet2->numEntities() >= 1)
  {
    OdResult res = eOk;

    OdDb3dSolidPtr pMainSolid, pMainSolid2, pWorkSolid, pWorkSolid2;
    unionEnt<OdDb3dSolidPtr, OdDb3dSolid>(pSet, pMainSolid, pWorkSolid);
    unionEnt<OdDb3dSolidPtr, OdDb3dSolid>(pSet2, pMainSolid2, pWorkSolid2);
    if (!pWorkSolid.isNull() && !pWorkSolid2.isNull())
    {
      res = pWorkSolid->booleanOper(OdDb::kBoolSubtract, pWorkSolid2);
      pMainSolid->copyFrom(pWorkSolid);
      clearEnt<OdDb3dSolid>(pSet, pMainSolid->objectId());
      clearEnt<OdDb3dSolid>(pSet2, pMainSolid2->objectId());
      pMainSolid2->erase();
    }

    if (eOk == res)
    {
      OdDbRegionPtr pMainReg, pMainReg2, pWorkReg, pWorkReg2;
      unionEnt<OdDbRegionPtr, OdDbRegion>(pSet, pMainReg, pWorkReg);
      unionEnt<OdDbRegionPtr, OdDbRegion>(pSet2, pMainReg2, pWorkReg2);
      if (!pMainReg.isNull() && !pMainReg2.isNull())
      {
        pWorkReg->booleanOper(OdDb::kBoolSubtract, pWorkReg2);
        pMainReg->copyFrom(pWorkReg);
        clearEnt<OdDbRegion>(pSet, pMainReg->objectId());
        clearEnt<OdDbRegion>(pSet2, pMainReg2->objectId());
        pMainReg2->erase();
      }
    }

    if (eOk == res)
    {
      OdDbDatabase* pDatabase = pDbCmdCtx->database();
      OdDbBlockTableRecordPtr pMs = pDatabase->getModelSpaceId().safeOpenObject(OdDb::kForWrite);

      OdResult res = eOk;
      OdDbSurfacePtr pRetSurf;
      OdDbSelectionSetIteratorPtr pIter = pSet->newIterator();
      while ( !pIter->done() )
      {
        OdDbObjectId objId  = pIter->objectId();
        OdDbEntityPtr pEnt  = objId.openObject( OdDb::kForWrite );
        if( !pEnt.isNull() && pEnt->isKindOf(OdDbSurface::desc()))
        {
          OdDbSelectionSetIteratorPtr pIter2 = pSet2->newIterator();
          while ( !pIter2->done() )
          {
            OdDbObjectId objId2  = pIter2->objectId();
            OdDbEntityPtr pEnt2  = objId2.openObject( OdDb::kForWrite );
            if( !pEnt2.isNull())
            {
              res = eInvalidInput;
              if(pEnt2->isKindOf(OdDbSurface::desc()) )
                res = OdDbSurfacePtr(pEnt)->booleanSubtract(OdDbSurfacePtr(pEnt2), pRetSurf);
              if(pEnt2->isKindOf(OdDb3dSolid::desc()) )
                res = OdDbSurfacePtr(pEnt)->booleanSubtract(OdDb3dSolidPtr(pEnt2), pRetSurf);

              if (eOk == res && !pRetSurf.isNull())
              {
                pMs->appendOdDbEntity(pRetSurf);
              }
            }
            pIter2->next();
          }
        }
        pIter->next();
      }
    }
  }
}
