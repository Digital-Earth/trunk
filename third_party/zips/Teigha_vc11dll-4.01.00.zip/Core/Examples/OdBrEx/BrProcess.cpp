/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

#include "Br/BrBrep.h"

#include "BrSearch.h"
#include "BrTraverse.h"

#if defined(TARGET_OS_MAC) && !defined(__MACH__)
#include <console.h>
#endif

#define STL_USING_IOSTREAM
#include "OdaSTL.h"
#define  STD(a)  std:: a

/************************************************************************/
/* Interactive Menu                                                     */
/************************************************************************/
int menu()
{
	STD(cout) << "\n\n"
	<< "   1 ==> Complete top-down traversal of Brep, ending with loop->edge\n"
	<< "   2 ==> Complete top-down traversal of Brep, ending with loop->vertex\n"
	<< "   3 ==> Brep-shell traverser only\n"
	<< "   4 ==> Brep-face traverser only\n"
	<< "   5 ==> Brep-edge traverser only\n"
	<< "   6 ==> Brep-vertex traverser only\n"
	<< "   7 ==> Query for a face number, report surface geometry\n"
	<< "   8 ==> Query for an edge number, \n"
	<< "         report adjacent Edges, Loops, and curve geometry\n"
	<< "   9 ==> Query for an SAT file vertex number;\n"
	<< "         report adjacent Edges and Loops\n"
	<< "   0  ==> exit\n"
	<< "\n Choice: ";

	int choice;
  STD(cin) >> choice;
	return choice;
}
/************************************************************************/
/* Process the specified by menu()                                      */
/************************************************************************/
void processOption(OdBrBrep& br, int testToRun)
{
	if (testToRun < 7)
	{
    /********************************************************************/
    /* Traverse the Brep                                                */
    /********************************************************************/
		traverseBrep(br, testToRun);  
	}
	else if (testToRun == 7)
	{
    /********************************************************************/
    /*  Query for a face number, report surface geometry                */
    /********************************************************************/
		int faceSeqNum;
		STD(cout) << "Enter a face number (negative to quit): ";
		STD(cin) >> faceSeqNum;
		while (faceSeqNum >= 0)
		{
			faceSearch(br, faceSeqNum);
			STD(cout).flush();
			STD(cout) << "Enter a face number (negative to quit): ";
			STD(cin) >> faceSeqNum;
		}
	}
	else if (testToRun == 8)
	{
    /********************************************************************/
    /*  Query for an edge number, report adjacent Edges, Loops, & curves*/
    /********************************************************************/
		int edgeSeqNum;
		STD(cout) << "Enter an edge number (negative to quit): ";
		STD(cin) >> edgeSeqNum;
		while (edgeSeqNum >= 0)
		{
			edgeSearch(br,edgeSeqNum);
			STD(cout) << "Enter an edge number (negative to quit): ";
			STD(cin) >> edgeSeqNum;
		}
	}
	else if (testToRun == 9)
	{
    /********************************************************************/
    /*  Query for an vertex number, report adjacent edges and loops     */
    /********************************************************************/
		int vertexSeqNum;
		STD(cout) << "Enter a vertex number (negative to quit): ";
		STD(cin) >> vertexSeqNum;
		while (vertexSeqNum >= 0)
		{
			vertexSearch(br,vertexSeqNum);
			STD(cout) << "Enter a vertex number (negative to quit): ";
			STD(cin) >> vertexSeqNum;
		}
	}
}


