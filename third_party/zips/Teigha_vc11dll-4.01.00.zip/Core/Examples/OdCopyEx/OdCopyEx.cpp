/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* Copies the specified file to the specified file in                   */
/* the specified version and type.                                      */
/*                                                                      */
/* Calling sequence:                                                    */
/*                                                                      */
/* OdCopyEx <source file> <target file> [OutVer] [OutType]              */
/*                                                                      */
/*    OutVer can be any of ACAD12, ACAD13, ACAD14, ACAD2000, ACAD2004   */
/*    ACAD2007                                                          */
/*                                                                      */
/*    OutType can be any of DWG, DXF, DXB                               */
/*                                                                      */
/************************************************************************/
#include "OdaCommon.h"

#include "DbDatabase.h"

#include "DbAudit.h"
#include "DbIdMapping.h"

#include "RxObjectImpl.h"
#include "RxDynamicModule.h"

#include "ExSystemServices.h"
#include "ExHostAppServices.h"
#include "OdFileBuf.h"
#include "Gs/Gs.h"

#define STL_USING_IOSTREAM
#include "OdaSTL.h"
#define  STD(a)  std:: a

#if defined(TARGET_OS_MAC) && !defined(__MACH__)
#include <console.h>
#endif

/************************************************************************/
/* Define a module map for statically linked modules:                   */
/************************************************************************/
#ifndef _TOOLKIT_IN_DLL_

ODRX_DECLARE_STATIC_MODULE_ENTRY_POINT(BitmapModule);
ODRX_DECLARE_STATIC_MODULE_ENTRY_POINT(OdRecomputeDimBlockModule);

ODRX_BEGIN_STATIC_MODULE_MAP()
  ODRX_DEFINE_STATIC_APPMODULE  (OdWinBitmapModuleName,     BitmapModule)
  ODRX_DEFINE_STATIC_APPLICATION(OdRecomputeDimBlockModuleName, OdRecomputeDimBlockModule)
ODRX_END_STATIC_MODULE_MAP()

#endif


/************************************************************************/
/* Define a Custom Services class.                                      */
/*                                                                      */
/* Combines the platform dependent functionality of                     */
/* ExSystemServices and ExHostAppServices                               */ 
/************************************************************************/
class MyServices : public ExSystemServices, public ExHostAppServices
{
protected:
  ODRX_USING_HEAP_OPERATORS(ExSystemServices);
  OdGsDevicePtr gsBitmapDevice(OdRxObject* /*pViewObj*/ = NULL,
                               OdDbBaseDatabase* /*pDb*/ = NULL,
                               OdUInt32 /*flags*/ = 0)
  {
    try
    {
      OdGsModulePtr pGsModule = ::odrxDynamicLinker()->loadModule(OdWinBitmapModuleName);
      return pGsModule->createBitmapDevice();
    }
    catch(const OdError&)
    {
    }
    return OdGsDevicePtr();
  }
};

/************************************************************************/
/* Main                                                                 */
/************************************************************************/
#if defined(ODA_WINDOWS)
int wmain(int argc, wchar_t* argv[])
#else
int main(int argc, char* argv[])
#endif
{
#if defined(TARGET_OS_MAC) && !defined(__MACH__)
  argc = ccommand(&argv);
#endif

#ifndef _TOOLKIT_IN_DLL_
    ODRX_INIT_STATIC_MODULE_MAP();
#endif

  int nRes = 1;
  /**********************************************************************/
  /* Define a Custom Services object                                    */
  /**********************************************************************/
  OdStaticRxObject<MyServices> svcs;
  odInitialize(&svcs);

  /**********************************************************************/
  /* Verify the argument count and display an error message as required */
  /**********************************************************************/
  if (argc < 3) 
  {
    STD(cout) << "\tusage: OdCopyEx <source file> <target file> [outver] [outtype]" << STD(endl);
    //  ACAD25, 
    STD(cout) << "\toutver can be any of ACAD9, ACAD10, ACAD12, ACAD13, ACAD14, ACAD2000, ACAD2004, ACAD2007, ACAD2010, ACAD2013" << STD(endl);
    STD(cout) << "\touttype can be any of DWG, DXF, DXB" << STD(endl);
    nRes = 1;
  }
  else
  {
    OdDb::SaveType fileType = OdDb::kDwg;
    OdDb::DwgVersion outVer = OdDb::vAC24;

    if (argc >= 4) 
    {
      OdString argv3(argv[3]);
      //if (!odStrICmp(argv[3],OD_T("ACAD25")) outver = AD_ACAD25;
      if      (!odStrICmp(argv3,OD_T("ACAD9")))     outVer = OdDb::vAC09;
      else if (!odStrICmp(argv3,OD_T("ACAD10")))    outVer = OdDb::vAC10;
      else if (!odStrICmp(argv3,OD_T("ACAD12")))    outVer = OdDb::vAC12;
      else if (!odStrICmp(argv3,OD_T("ACAD13")))    outVer = OdDb::vAC13;
      else if (!odStrICmp(argv3,OD_T("ACAD14")))    outVer = OdDb::vAC14;
      else if (!odStrICmp(argv3,OD_T("ACAD2000")))  outVer = OdDb::vAC15;
      else if (!odStrICmp(argv3,OD_T("ACAD2004")))  outVer = OdDb::vAC18;
      else if (!odStrICmp(argv3,OD_T("ACAD2007")))  outVer = OdDb::vAC21;
      else if (!odStrICmp(argv3,OD_T("ACAD2010")))  outVer = OdDb::vAC24;
      else if (!odStrICmp(argv3,OD_T("ACAD2013")))  outVer = OdDb::vAC27;
    }

    if (argc >= 5)  
    {
      OdString argv4(argv[4]);
      if      (!odStrICmp(argv4,OD_T("DWG"))) fileType = OdDb::kDwg;
      else if (!odStrICmp(argv4,OD_T("DXF"))) fileType = OdDb::kDxf;
      else if (!odStrICmp(argv4,OD_T("DXB"))) fileType = OdDb::kDxb;
    }

    /********************************************************************/
    /* Disable the progress meter                                       */
    /********************************************************************/
    svcs.disableOutput(true);

    OdDbDatabasePtr pDb;
    try 
    {
      // Create a database and load the drawing into it.
      /******************************************************************/
      /* Create a database and read <source file> into it               */
      /******************************************************************/
      OdString inFile(argv[1]);
      pDb = svcs.readFile(inFile.c_str()); 

      /******************************************************************/
      /* Create and open a write file buffer for <target file>          */
      /******************************************************************/
      OdRxObjectImpl<OdWrFileBuf> fb;
      OdString outFile(argv[2]);
      fb.open(outFile.c_str());
      
      /******************************************************************/
      /* Audit the database, and fix any errors                         */
      /******************************************************************/
      OdDbAuditInfo ainfo;
      ainfo.setFixErrors(true);
      pDb->auditDatabase(&ainfo);
    
      /******************************************************************/
      /* Write the database without generating a bitmap                 */
      /******************************************************************/
      pDb->writeFile(&fb, fileType, outVer , false /* Generate Bitmap */ );
      nRes = 0;
    }
    catch (OdError& err)
    {
      odPrintConsoleString(L"\nOdError thrown: %ls\n",err.description().c_str());
      nRes = -1;
    }
    catch (...)
    {
      STD(cout) << "\nGeneral exception thrown, exiting\n";
      nRes = -1;
    }
  }

  /**********************************************************************/
  /* Uninitialize Teigha                                                */
  /**********************************************************************/
  odUninitialize();

  if (nRes == 1)
  {
    STD(cout) << "Press ENTER to exit..." << STD(endl);
    STD(cin).get();
  }
  return nRes;
}
