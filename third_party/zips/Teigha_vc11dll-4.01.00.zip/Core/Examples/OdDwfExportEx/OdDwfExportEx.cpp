///////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance").
// All rights reserved.
//
// This software and its documentation and related materials are owned by
// the Alliance. The software may only be incorporated into application
// programs owned by members of the Alliance, subject to a signed
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable
// trade secrets of the Alliance and its suppliers. The software is also
// protected by copyright law and international treaty provisions. Application
// programs incorporating this software must include the following statement
// with their copyright notices:
//
//   This application incorporates Teigha(R) software pursuant to a license
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance.
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////

/************************************************************************/
/* This console application reads a DWG/DXF file and saves it to        */
/* a DWF file of the specified version.                                 */
/*                                                                      */
/* Calling sequence:                                                    */
/*                                                                      */
/*    OdDwfExportEx <source file> <target file> <dwfversion>            */
/*                                                                      */
/************************************************************************/


#ifdef WD_WIN_SYSTEM
#include <io.h>
#include <direct.h>
#endif

#include <time.h>
#include <sys/stat.h>
#include <math.h>
#include <stack>
#include <assert.h>

#define STL_USING_IOSTREAM
#include "OdaSTL.h"
#define  STD(a)  std:: a


#include "OdaCommon.h"
#include "DbDatabase.h"
#include "RxObjectImpl.h"
#include "ExSystemServices.h"
#include "ExHostAppServices.h"
#include "ModelerGeometry/ModelerModule.h"
#include "OdFileBuf.h"
#include "ColorMapping.h"
#include "../../Exports/DwfExport/Include/DwfExport.h"
#include "../../Exports/DwfExport/Include/3dDwfExport.h"
#include "RxDynamicModule.h"

//#ifdef   linux
#include <locale.h>
//#endif

#if defined(TARGET_OS_MAC) && !defined(__MACH__)
#include <console.h>
#endif

/************************************************************************/
/* Define a module map for statically linked modules:                   */
/************************************************************************/
#ifndef _TOOLKIT_IN_DLL_

ODRX_DECLARE_STATIC_MODULE_ENTRY_POINT(ModelerModule);
ODRX_DECLARE_STATIC_MODULE_ENTRY_POINT(OdRecomputeDimBlockModule);
ODRX_DECLARE_STATIC_MODULE_ENTRY_POINT(BitmapModule);
ODRX_DECLARE_STATIC_MODULE_ENTRY_POINT(OdRasterProcessingServicesImpl);

ODRX_BEGIN_STATIC_MODULE_MAP()
  ODRX_DEFINE_STATIC_APPLICATION(OdModelerGeometryModuleName,   ModelerModule)
  ODRX_DEFINE_STATIC_APPLICATION(OdRecomputeDimBlockModuleName, OdRecomputeDimBlockModule)
  ODRX_DEFINE_STATIC_APPMODULE(OdWinBitmapModuleName,            BitmapModule)
  ODRX_DEFINE_STATIC_APPMODULE(OdRasterProcessorModuleName,               OdRasterProcessingServicesImpl)
ODRX_END_STATIC_MODULE_MAP()

#endif

//----------------------------------------------------------------------------------

class MyServices : public ExSystemServices, public ExHostAppServices
{
protected:
  ODRX_USING_HEAP_OPERATORS(ExSystemServices);
private:

/************************************************************************/
/* Compile password support for R18 Drawings                            */
/************************************************************************/
#if defined(_MSC_VER) && !(defined(_WINRT))
bool getPassword(const OdString& dwgName, bool isXref, OdPassword& password)
{
  char buff[_MAX_PATH] = {0};
  STD(cout) << "Enter password to open drawing: " << STD(endl);
  ::CharToOemA((const char*)dwgName, buff);
  STD(cout) << "    " << buff << STD(endl);

  STD(cin).get(buff, '\n').get();

  wchar_t pwdBuff[_MAX_PATH] = {0};
  // convert to upper case unicode:
  ::OemToCharW( buff, pwdBuff );
  ::CharUpperW( pwdBuff );
  password = pwdBuff;
  return !password.isEmpty();
}
#endif
public:
  OdGsDevicePtr gsBitmapDevice(OdRxObject* /*pViewObj*/ = NULL,
                               OdDbBaseDatabase* /*pDb*/ = NULL,
                               OdUInt32 flags = 0)
  {
    OdGsModulePtr pM;
    if (GETBIT(flags, kFor2dExportRender))
    {
      if (GETBIT(flags, kFor2dExportRenderHLR))
        return OdGsDevicePtr();
      pM = ::odrxDynamicLinker()->loadModule(OdWinOpenGLModuleName);
    }
    if (pM.isNull())
      pM = ::odrxDynamicLinker()->loadModule(OdWinBitmapModuleName);
    if (pM.isNull())
      return OdGsDevicePtr();

    return pM->createBitmapDevice();
  }
};

/************************************************************************/
/* Main                                                                 */
/************************************************************************/
#if defined(ODA_WINDOWS)
int wmain(int argc, wchar_t* argv[])
#else
int main(int argc, char* argv[])
#endif
{
#if defined(TARGET_OS_MAC) && !defined(__MACH__)
  argc = ccommand(&argv);
#endif

  if (argc < 4)
  {
    STD(cout) << "usage: OdDwfExportEx <source file> <target file> <dwfversion>"
              << STD(endl)
              << "dwfversion can be any of XPS, B6, A6, C5.5, A5.5, B5.5, C4, A4, B4 3D for DWF"
              << STD(endl);
  }
  else
  {
    /********************************************************************/
    /* For correct Unicode translation, apply the current system locale.*/
    /********************************************************************/
    setlocale(LC_ALL, "");
    /********************************************************************/
    /* But use usual conversion for scanf()/sprintf()                   */
    /********************************************************************/
    setlocale(LC_NUMERIC, "C");

#ifndef _TOOLKIT_IN_DLL_
    ODRX_INIT_STATIC_MODULE_MAP();
#endif

    /********************************************************************/
    /* Create a custom Services instance.                               */
    /********************************************************************/
    OdStaticRxObject<MyServices> svcs;
    odInitialize(&svcs);


    /********************************************************************/
    /* Display the Product and Version that created the executable      */
    /********************************************************************/
    STD(cout) << "Developed using " << (const char*)svcs.product() << ", " << (const char*)svcs.versionString() << STD(endl);

    try
    {
      /******************************************************************/
      /* Create a database and load the drawing into it.                */
      /******************************************************************/
      OdDbDatabasePtr pDb = svcs.readFile(argv[1]);
      if (pDb.isNull())
      {
        STD(cout) << "Can't read source DWG " << argv[1] << STD(endl);
        return 1;
      }

      /******************************************************************/
      /* Parse the command line                                         */
      /******************************************************************/
      OdString argv3(argv[3]);
      if (!argv3.iCompare(OD_T("3D")))
      {
        Dwf3dExportParams params;
        params.pDb = pDb;
        params.sDwfFileName = argv[2];
        params.xSize = 1024; params.ySize = 768; // export device resolution
        params.background = ODRGB(255, 255, 255);
        params.pPalette = odcmAcadLightPalette();
        params.sTitle = "Model"; // section title in 3D DWF
        export3dDwf(params);
      }
      else 
      {
        /****************************************************************/
        /* Initialize the conversion parameters                         */
        /****************************************************************/
        DwExportParams params;
        params.bInkedArea = false;                                                        // MKU 1/21/2004
        params.bColorMapOptimize = false;                                                 // MKU 1/21/2004
        params.pDb = pDb;
        params.sDwfFileName = argv[2];
        params.background = ODRGB(255, 255, 255);
        params.pPalette = odcmAcadLightPalette();
        params.bEmbedAllFonts = true;

        if (!odStrICmp(argv3, OD_T("XPS")))
        {
          params.Format = DW_XPS;
          params.Version = nDwf_v60;
        }
        else if (!odStrICmp(argv3, OD_T("B6")))
        {
          params.Format = DW_UNCOMPRESSED_BINARY;
          params.Version = nDwf_v60;
        }
        else if (!odStrICmp(argv3, OD_T("A6")))
        {
          params.Format = DW_ASCII;
          params.Version = nDwf_v60;
        }
        else if (!odStrICmp(argv3, OD_T("C5.5")))
        {
          params.Format = DW_COMPRESSED_BINARY;
          params.Version = nDwf_v55;
        }
        else if (!odStrICmp(argv3, OD_T("B5.5")))
        {
          params.Format = DW_UNCOMPRESSED_BINARY;
          params.Version = nDwf_v55;
        }
        else if (!odStrICmp(argv3, OD_T("A5.5")))
        {
          params.Format = DW_ASCII;
          params.Version = nDwf_v55;
        }
        else if (!odStrICmp(argv3, OD_T("C4")))
        {
          params.Format = DW_COMPRESSED_BINARY;
          params.Version = nDwf_v42;
        }
        else if (!odStrICmp(argv3, OD_T("B4")))
        {
          params.Format = DW_UNCOMPRESSED_BINARY;
          params.Version = nDwf_v42;
        }
        else if (!odStrICmp(argv3, OD_T("A4")))
        {
          params.Format = DW_ASCII;
          params.Version = nDwf_v42;
        }
        else
        {
          STD(cout) << "Unknown <dwfversion>." << STD(endl);
          return 0;
        }
        /****************************************************************/
        /* Write the DWF file                                           */
        /****************************************************************/
        exportDwf(params);
      }
    }
    catch (OdError& err)
    {
      OdString msg = err.description();
      STD(cout) << "Teigha Error: " << (const char*)msg << STD(endl) << STD(endl);
    }
    catch (...)
    {
      STD(cout) << "Unknown Error." << STD(endl) << STD(endl);
      return 0;
    }

    odUninitialize();
  }

  return 0;
}
