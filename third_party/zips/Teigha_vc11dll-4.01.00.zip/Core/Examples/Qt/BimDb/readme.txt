Bridge to Bim functionality for TeighaViewer & Cloud Service

