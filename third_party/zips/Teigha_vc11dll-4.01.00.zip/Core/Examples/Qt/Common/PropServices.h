/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
//
// PropServices.h
//

#ifndef OD_PROP_SERVICES_H_
#define OD_PROP_SERVICES_H_

#include "TD_PackPush.h"

#include "RxObject.h"
#include "Ed/EdCommandContext.h"
#include "StringArray.h"
#include "ResBuf.h"

//------------------------------------------------------------------------
// casted from OdEdCommandContext

class OdPropSource
{
public:
  typedef enum Action_t { 
    enAction_None = 0
  , enAction_Close = 1 // Ok - (there is no other way to close modal dialog on Mac)
  , enAction_Cancel = 2
//, enAction_RecreateWidgets = 4 // (internal)
  , enAction_RefreshSource = 8 // enAction_RefreshAll
  , enAction_RefreshSourceWidgets = 8 + 4 // with recreating of widgets // enAction_ForceRefreshAll
  , enAction_RefreshAllSources = 16
  , enAction_RefreshAllSourcesWidgets = 16 + 4 // with recreating of widgets 
  } Action;

  virtual bool updateXml(OdString& sXml) = 0; // get / update
  virtual bool setPropertyValue(const OdString&, // sPath
                                const OdString&, // sValue
                                Action&) //action
  {
    return false;
  }
  virtual bool getPropertyPossibleValues(const OdString&, // sPath
                                         OdStringArray&, // values
                                         OdStringArray&) // iconPaths
  {
    return false;
  }

  static OdString extractFirst(OdString& sPath, 
                               OdChar ch = __OD_T('/'), 
                               bool bTrimSpaces = false)
  {
    OdString sFirst;
    int pos = sPath.find(ch);
    if (pos < 0)
    {
      sFirst = sPath;
      sPath.empty();
      return sFirst;
    }

    sFirst = sPath.left(pos);
    sPath = sPath.mid(++pos);
    if (bTrimSpaces)
    {
      sFirst.trimRight();
      sPath.trimLeft();
    }
    return sFirst;
  }
};

//------------------------------------------------------------------------
// returned by TConvertorToResBufPropValue for TODO and other unsupported cases
#define TD_MARKER_TO_CANCEL OD_T("*Cancel*") 
// returned by TConvertorToResBufPropValue to repeat call for all selected entities
// and skip resbuf writing (already done via code in convertor
#define TD_MARKER_FOREACH_TO_SET_DIRECTLY OD_T("*Foreach*")
#define TD_MARKER_OUT_OF_RANGE OD_T("*Out of range*")

typedef OdString TConvertorFromResBufPropValue(const OdString& sResBufValues, class OdDbStub* id);
typedef OdString TConvertorToResBufPropValue(const OdString& sPaletteValue, 
                                             // of first selected entity 
                                             // (it is not pRxDatabase because it maybe usable to get current position 
                                             // in advanced dialogs - TODO for General/PlotStyle/Other ...)
                                             OdDbStub* id, 
                                             OdString& sHintGrCode); // out - for alternative gr code - like PloteStyle
typedef bool TConvertorPossibleValues(OdStringArray& values, OdStringArray& iconPaths, 
                                      OdRxObject* pRxDatabase);

class OdControllerOfResBufPropValueConvertors
{
public:
  virtual void addConvertor(const OdString& sConvertorName, // convertor in XML patterns (...="$(convertor,...)"...)
                            TConvertorFromResBufPropValue* pConvertorFrom,
                            TConvertorToResBufPropValue* pConvertorTo,
                            TConvertorPossibleValues* pGetPossibleValues) = 0;
  virtual void removeConvertor(const OdString& sConvertorName) = 0;
  
  // for such args like scale of LINEAR convertor
  virtual OdString getConvertorAdvArg(const OdString& sName) = 0;
  virtual void setConvertorAdvArg(const OdString& sName, const OdString& sArgs) = 0;
};

//------------------------------------------------------------------------

class OdPropServices : public OdRxObject
{
public:
  ODRX_DECLARE_MEMBERS(OdPropServices);

  // return unique dialog key (sDlgKey)
  virtual OdString openDialog(const OdString& sTitle = OD_T("%ls Property Dialog"), // %ls = product name
                              void* pLayoutQObjectToAddDlg = NULL) = 0;

  // in perpendicular direction to current (default internal first layout in vertical)
  virtual bool pushLayout(const OdString& sDlgKey) = 0;
  virtual bool popLayout(const OdString& sDlgKey) = 0;
  virtual bool addSource(const OdString& sDlgKey, 
                         OdPropSource* pSource,
                         const OdString& sXmlBasePath = OdString::kEmpty,
                         const OdString& sXmlRootNodeName = OD_T("Properties"),
                         const OdChar* pcszWidgetAttribs = NULL, // use like "title=:type=palette:type=palette_simple:alignment=top:..."
                         const OdChar cDelimWidgetAttribs = __OD_T(':')) = 0;
  virtual bool setMergeFilter(const OdString& sDlgKey,
                              OdPropSource* pSource,
                              const OdString& sMergeFilter = OdString::kEmpty, // empty for all
                              const OdString& sMergeFilterAttribName =  OD_T("Filter"), // empty is already set by previous call
                              const OdString& sUnmergedBasePath = OdString::kEmpty) = 0; // already set by previous call

  virtual bool executeDialog(const OdString& sDlgKey) = 0;
  // for external update via events 
  // - is used for palettes only (pLayoutQObjectToAddDlg is not NULL)
  virtual bool refreshSources(const OdString& sDlgKey, 
                              OdPropSource* pSourceOnly = NULL, // null for all
                              bool bRecreateWidgets = false) = 0; 

  virtual bool closeDialog(const OdString& sDlgKey) = 0;

  // return index of chosen button
  virtual int messageBox(const OdChar* pszTitle, // %ls = product name (L"%ls Error")
                         const OdChar* pszText,
                         const OdChar* pszButton0 = NULL, // [text_of_button, ... ~text_of_button_in focus, ... text_of_button,] NULL(should be at end - is used as end of arguments)
                         ...) = 0;

  virtual class OdDbBaseHostAppServices* getBaseHostAppServices() = 0;
  virtual OdString tr(const char* pcszText) = 0; // translate via Qt Dictionaties (via QObject::tr(pcszText))
  virtual bool isInputStringReady(OdEdCommandContext* pCmdCtx) = 0;

  virtual OdString collectByPropXmlPatterns(const OdString& sXmlBasePath,
                                            const OdStringArray& asClassNames,
                                            const OdResBufPtr& data) = 0;
  // return error message (an empty string if OK)
  virtual OdString setValueByPropXmlPatterns(const OdStringArray& asClassNames,
                                             OdResBufPtr& data, // in /out
                                             const OdString& sPathName, const OdString& sValue,
                                             const OdString& sHintGrCode, // for alternative gr code - like PloteStyle
                                             OdPropSource::Action& action) = 0; // out

  // is used to convert value from resbuf string form to palette one and back
  virtual OdControllerOfResBufPropValueConvertors* controllerOfResBufPropValueConvertors() = 0;
  virtual void setControllerOfResBufPropValueConvertors(OdControllerOfResBufPropValueConvertors* pController) = 0;
};
#define OD_PROP_SERVICES OD_T("OdPropServices")
typedef OdSmartPtr<OdPropServices> OdPropServicesPtr;

#include "TD_PackPop.h"

#endif // OD_PROP_SERVICES_H_
