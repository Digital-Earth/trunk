Bridge to Dgn functionality for TeighaViewer & Cloud Service
