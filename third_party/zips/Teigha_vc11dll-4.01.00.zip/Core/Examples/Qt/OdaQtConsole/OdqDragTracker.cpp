/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
//
// OdqDragTracker.cpp
//

#include "OdaCommon.h"

#define STL_USING_MAP
#define STL_USING_ALGORITHM
#include "OdaSTL.h"
#include "UInt32Array.h"
#include "Ge/GePoint3d.h"
#include "Gi/GiDrawableImpl.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"
#include "DbHostAppServices.h"
#include "DbCommandContext.h"
#include "DbEntity.h"
#include "DbAbstractViewportData.h"
#include "Gs/GsModel.h"

#include "OdqDragTracker.h"
#include "OdqConsoleTab.h"

//////////////////////////////////////////////////////////////////////////

OdExGripDragPtr OdExGripDrag::createObject(OdDbStub* id, OdqDragTracker* pOwner)
{
  OdExGripDragPtr pRes = RXIMPL_CONSTR(OdExGripDrag);
  pRes->m_entPath = OdDbBaseFullSubentPath();
  pRes->m_entPath.objectIds().append(id);
  pRes->m_pOwner = pOwner;
  return pRes;
}

OdExGripDragPtr OdExGripDrag::createObject(OdDbBaseFullSubentPath entPath, OdqDragTracker* pOwner)
{
  OdExGripDragPtr pRes = RXIMPL_CONSTR(OdExGripDrag);
  pRes->m_entPath = entPath;
  pRes->m_pOwner = pOwner;
  return pRes;
}

OdExGripDrag::OdExGripDrag()
  : m_pOwner(NULL)
//, m_pClone(NULL) // defailt
{
}

OdExGripDrag::~OdExGripDrag()
{
}

static OdqGripManager::OdExGripDataSubent& getSubentGripData(OdqGripManager::OdExGripDataExt& ext,
                                                             OdDbBaseFullSubentPath entPath)
{
  for (OdUInt32 i = 0; i < ext.m_pDataSub.size(); i++)
  {
    if (ext.m_pDataSub.at(i).m_entPath == entPath)
      return ext.m_pDataSub.at(i);
  }
  ODA_FAIL();
  return ext.m_pDataSub.at(0);
}

OdDbStub* OdExGripDrag::id() const 
{ 
  return m_entPath.objectIds().last(); 
}

bool OdExGripDrag::entPath(OdDbBaseFullSubentPath *pPath) const // = NULL
{
  if (pPath)
    *pPath = m_entPath;
  return m_entPath.subentId() != OdDbSubentId();
}

bool OdExGripDrag::locateActiveGrips(OdIntArray& aIndices)
{
  const OdExGripDataPtrArray& rData = (entPath()) ? getSubentGripData(m_pOwner->m_pGripManager->m_aGripData[id()], m_entPath).m_pSubData
                                                  : m_pOwner->m_pGripManager->m_aGripData[id()].m_pDataArray;

  bool bExMethod = true;
  aIndices.clear();
  OdUInt32 i, iSize = rData.size();
  for (i = 0; i < iSize; i++)
  {
    if (rData[i]->data().isNull())
        bExMethod = false;

    if (OdDbGripOperations::kDragImageGrip == rData[i]->status())
        aIndices.push_back(i);
  }
  ODA_ASSERT(!aIndices.empty());
  return bExMethod;
}

void OdExGripDrag::cloneEntity()
{
  if (!OdDbDatabase::cast(baseDatabaseBy(id())).get())
    return;
  m_pClone = NULL;

  OdDbEntityPtr pEntity = OdDbEntity::cast(OdDbObjectId(id()).openObject());
  if (pEntity.isNull() || 0 == m_pOwner)
    return;

  if (pEntity->cloneMeForDragging())
    m_pClone = OdDbEntity::cast(pEntity->clone());

  if (m_pClone.get())
  {
    m_pClone->disableUndoRecording(true);
    m_pClone->setPropertiesFrom(pEntity.get(), false);
  }
}

static OdDbFullSubentPath toFullPath(const OdDbBaseFullSubentPath& entPath)
{
  OdDbFullSubentPath entFullPath;
  if (   !entPath.objectIds().size() 
      || OdDbDatabase::cast(baseDatabaseBy(entPath.objectIds().first())).get())
  {
    ODA_FAIL_ONCE();
    return entFullPath;
  }

  *((OdDbBaseFullSubentPath*) &entFullPath) = entPath;
  return entFullPath;
}

void OdExGripDrag::cloneEntity(const OdGePoint3d& ptMoveAt)
{
  cloneEntity();
  if (m_pClone.isNull())
    return;

  OdIntArray aIndices;
  bool bExMethod = locateActiveGrips(aIndices);

  OdGeVector3d vOffset =
    ptMoveAt - m_pOwner->m_ptBasePoint;

  if (bExMethod)
  {
    OdDbGripDataPtrArray aCloneData;
    if (entPath())
      m_pClone->getGripPointsAtSubentPath(toFullPath(m_entPath), 
                                          aCloneData,
                                          m_pOwner->m_pGripManager->activeViewUnitSize(), 
                                          m_pOwner->m_pGripManager->m_GRIPSIZE, 
                                          m_pOwner->m_pGripManager->activeViewDirection(),
                                          0);
    else
      m_pClone->getGripPoints(aCloneData,
                              m_pOwner->m_pGripManager->activeViewUnitSize(), 
                              m_pOwner->m_pGripManager->m_GRIPSIZE,
                              m_pOwner->m_pGripManager->activeViewDirection(),
                              0);

    OdDbVoidPtrArray aIds;
    OdUInt32 i, iSize = aIndices.size();
    for (i = 0; i < iSize; i++)
    {
      if (aIndices[i] < (OdInt32)aCloneData.size())
      {
        aIds.push_back(aCloneData[aIndices[i]]->appData());
      }
      else
      {
        ODA_ASSERT(0);
      }
    }

    if (entPath())
    {
      OdDbFullSubentPathArray aPaths;
      aPaths.append(toFullPath(m_entPath));
      m_pClone->moveGripPointsAtSubentPaths(aPaths, aIds, vOffset, 0);
      m_pClone->subentGripStatus(OdDb::kGripsToBeDeleted, toFullPath(m_entPath));
    }
    else
    {
      m_pClone->moveGripPointsAt(aIds, vOffset, 0);
      m_pClone->gripStatus(OdDb::kGripsToBeDeleted);
      //m_pClone->gripStatus(OdDb::kDimDataToBeDeleted);
    }
    for (i = 0; i < aCloneData.size(); ++i)
      if (aCloneData[i]->gripOpStatFunc())
        (aCloneData[i]->gripOpStatFunc())(aCloneData[i], OdDbObjectId::kNull, OdDbGripOperations::kGripEnd);
  }
  else
  {
    //OdGePoint3dArray aPts;
    //m_pClone->getGripPoints(aPts);

    //OdUInt32 i, iSize = aIndices.size();
    //for (i = 0; i < iSize; i++)
    //{
    //  if (aIndices[i] < (OdInt32)aPts.size()) 
    //    aPts[aIndices[i]] += vOffset;
    //  else
    //  {
    //    ODA_ASSERT(0);
    //  }
    //}

    m_pClone->moveGripPointsAt(aIndices, vOffset);
    m_pClone->gripStatus(OdDb::kGripsToBeDeleted);
  }

  //if (m_pOwner->m_pGsModel)
  //  m_pOwner->m_pGsModel->onModified(this, (OdGiDrawable*)0);
  //else
  //  m_pOwner->m_pDevice->invalidate();
  IqViewSystem* iVS = getIViewSystem();
  ODA_ASSERT_ONCE(iVS);
  IqView* iView = iVS->getView(m_pOwner->m_pGripManager->m_pTabConsole->getRxDatabase());
  ODA_ASSERT_ONCE(iView);
  if (iView)
  {
    //  m_pOwner->m_pGsModel->onModified(this, (OdGiDrawable*)0);
    if (!m_pClone.isNull())
    {
      // use 2d model - see OdqDragTracker::addDrawables
      OdGsModelPtr pGsModel2d = iView->getGsModel(true); // GsModel2d
      pGsModel2d->onModified(this, (OdGiDrawable*) NULL);
      //iView->getGsDevice()->invalidate();
    }
    //else
    //  //iVS->updateObject(this, m_pOwner->m_pGripManager->m_pTabConsole->getRxDatabase());
  }
}

void OdExGripDrag::moveEntity(const OdGePoint3d& ptMoveAt)
{
  OdIntArray aIndices;
  bool bExMethod = locateActiveGrips(aIndices);

  OdGeVector3d vOffset =
    ptMoveAt - m_pOwner->m_ptBasePoint;

  const OdExGripDataPtrArray& rData =
    (entPath()) ? getSubentGripData(m_pOwner->m_pGripManager->m_aGripData[id()], m_entPath).m_pSubData
                : m_pOwner->m_pGripManager->m_aGripData[id()].m_pDataArray;

  if (!OdDbDatabase::cast(baseDatabaseBy(id())).get())
  {
    ODA_FAIL_ONCE(); // TODO
    return;
  }

  OdDbEntityPtr pEntity =
    OdDbEntity::cast(OdDbObjectId(id()).openObject(OdDb::kForWrite));
  ODA_ASSERT(!pEntity.isNull());
  if (bExMethod)
  {
    OdDbVoidPtrArray aIds;
    OdUInt32 i, iSize = aIndices.size();
    for (i = 0; i < iSize; i++)
    {
      if (aIndices[i] < (OdInt32)rData.size())
        aIds.push_back(rData[aIndices[i]]->data()->appData());
      else
      {
        ODA_ASSERT(0);
      }
    }

    if (entPath())
    {
      OdDbFullSubentPathArray aPaths;
      aPaths.append(toFullPath(m_entPath));
      pEntity->moveGripPointsAtSubentPaths(aPaths, aIds, vOffset, 0);
    }
    else
      pEntity->moveGripPointsAt(aIds, vOffset, 0);
  }
  else
  {
    //OdGePoint3dArray aPts;
    //OdUInt32 i, iSize = rData.size();
    //aPts.resize(iSize);
    //for (i = 0; i < iSize; i++)
    //  aPts[i] = rData[i]->point();

    //iSize = aIndices.size();
    //for (i = 0; i < iSize; i++)
    //{
    //  if (aIndices[i] < (OdInt32)rData.size()) 
    //    aPts[aIndices[i]] += vOffset;
    //  else
    //  {
    //    ODA_ASSERT(0);
    //  }
    //}

    pEntity->moveGripPointsAt(aIndices, vOffset);
  }
}

void OdExGripDrag::notifyDragStarted()
{
  if (!OdDbDatabase::cast(baseDatabaseBy(id())).get())
    return;
  OdDbEntityPtr pEntity = OdDbEntity::cast(OdDbObjectId(id()).openObject());
  if (!pEntity.isNull())
    pEntity->dragStatus(OdDb::kDragStart);
}

void OdExGripDrag::notifyDragEnded()
{
  if (!OdDbDatabase::cast(baseDatabaseBy(id())).get())
    return;
  OdDbEntityPtr pEntity = OdDbEntity::cast(OdDbObjectId(id()).openObject());
  if (!pEntity.isNull())
    pEntity->dragStatus(OdDb::kDragEnd);
}

void OdExGripDrag::notifyDragAborted()
{
  if (!OdDbDatabase::cast(baseDatabaseBy(id())).get())
    return;
  OdDbEntityPtr pEntity = OdDbEntity::cast(OdDbObjectId(id()).openObject());
  if (!pEntity.isNull())
    pEntity->dragStatus(OdDb::kDragAbort);
}

OdUInt32 OdExGripDrag::subSetAttributes(OdGiDrawableTraits* pTraits) const
{
  if (m_pClone.isNull())
    return OdGiDrawable::kDrawableIsInvisible;

  OdUInt32 iRet = m_pClone->setAttributes(pTraits);

  OdGiSubEntityTraitsPtr pEntityTraits = OdGiSubEntityTraits::cast(pTraits);
  // TODO ODA_ASSERT_ONCE(!pEntityTraits.isNull());
  if (pEntityTraits.isNull())
    return OdGiDrawable::kDrawableNone;

  pEntityTraits->setFillType(kOdGiFillNever);

  return iRet;
}

bool OdExGripDrag::subWorldDraw(OdGiWorldDraw* pWorldDraw) const
{
  if (m_pClone.isNull())
    return true;

  return m_pClone->worldDraw(pWorldDraw);
}

void OdExGripDrag::subViewportDraw(OdGiViewportDraw* pViewportDraw) const
{
  if (m_pClone.isNull())
    return;
  
  m_pClone->viewportDraw(pViewportDraw);
}

//////////////////////////////////////////////////////////////////////////

ODRX_NO_CONS_DEFINE_MEMBERS(OdqDragTracker, OdEdPointTracker);

//static 
OdqDragTrackerPtr OdqDragTracker::createObject(OdqGripManagerPtr pGripManager,
                                               const OdGePoint3d& ptBase,
                                               bool bUseClones) // = true
{
  //OdqDragTracker* pObj = static_cast<OdqDragTracker*>(new OdRxObjectImpl<OdqDragTracker>);
  //OdqDragTrackerPtr pDragTracker = OdqDragTrackerPtr(pDragTracker, kOdRxObjAttach);
  OdqDragTrackerPtr pDragTracker = OdRxObjectImpl<OdqDragTracker>::createObject();
  pDragTracker->init(pGripManager, ptBase, bUseClones);
  return pDragTracker;
}

OdqDragTracker::OdqDragTracker()
  : m_bCanceled(true)
{
  //m_ptBasePoint = OdGePoint3d::kOrigin;
  //m_ptLastPoint = OdGePoint3d::kOrigin;
  //m_aDrags.clear();

  //m_cDbReactor.m_pOwner = this;
}

OdqDragTracker::~OdqDragTracker()
{
  uninit();
}

bool OdqDragTracker::init(OdqGripManagerPtr pGripManager,
                          const OdGePoint3d& ptBase,
                          bool bUseClones) // = true
{
  ODA_ASSERT_ONCE(!pGripManager.isNull());
  m_pGripManager = pGripManager;

//  OdDbDatabase* pDwgDb = OdDbDatabase::cast(m_pOwner->m_pTabConsole->getRxDatabase()).get();
//  if (pDgwDb)
//    pDwgDb->addReactor(&m_cDbReactor);

  OdExGripDataPtrArray aActiveKeys;
  m_pGripManager->locateGripsByStatus(OdDbGripOperations::kHotGrip, aActiveKeys);
  if (aActiveKeys.empty())
  {
    ODA_FAIL_ONCE();
    return false;
  }

  OdUInt32 i, j, iSize = aActiveKeys.size();
  for (i = 0; i < iSize; i++)
    aActiveKeys[i]->setStatus(OdDbGripOperations::kDragImageGrip);

  for (OdqGripManager::GripDataMap::const_iterator it = m_pGripManager->m_aGripData.begin();
       it != m_pGripManager->m_aGripData.end(); it++)
  {
    bool bActive = false;
    OdExGripDragPtr pDrag;
    {
      const OdExGripDataPtrArray& aData = it->second.m_pDataArray;
      iSize = aData.size();
      for (i = 0; i < iSize; i++)
      {
        if (OdDbGripOperations::kDragImageGrip == aData[i]->status())
        {
          bActive = true;
          pDrag = OdExGripDrag::createObject(it->first, this);
          break;
        }
      }
      for (i = 0; (i < it->second.m_pDataSub.size()) && !bActive; i++)
      {
        const OdExGripDataPtrArray& aData = it->second.m_pDataSub.at(i).m_pSubData;
        iSize = aData.size();
        for (j = 0; j < iSize; j++)
        {
          if (OdDbGripOperations::kDragImageGrip == aData[j]->status())
          {
            bActive = true;
            pDrag = OdExGripDrag::createObject(it->second.m_pDataSub.at(i).m_entPath, this);
            break;
          }
        }
      }
    }
    if (bActive)
    {
      ////pDrag->entityId = it->first;
      ////pDrag->m_pOwner = this;
      m_aDrags.push_back(pDrag);
    }
  }

  iSize = m_aDrags.size();
  for (i = 0; i < iSize; i++)
  {
    m_aDrags[i]->notifyDragStarted();
    if (bUseClones)
      m_aDrags[i]->cloneEntity();
  }

  // will be set via finishAt call //m_bCanceled = false; // bool bOk = true;

  //m_ptBasePoint = aActiveKeys.first()->point();
  //{
  //  // Use alternative point if needed.
  //  OdDbGripDataPtr pFirstData = aActiveKeys.first()->data();
  //  if (pFirstData.get() && pFirstData->alternateBasePoint())
  //    m_ptBasePoint = *(pFirstData->alternateBasePoint());
  //}
  //
  // usially is near by not equal //ODA_ASSERT_ONCE(ptBase == aActiveKeys.first()->point()); // test
  //m_ptBasePoint = aActiveKeys.first()->point();
  m_ptBasePoint = ptBase; 
  m_ptLastPoint = m_ptBasePoint;

  return true;
}

void OdqDragTracker::uninit()
{
  OdUInt32 i, iSize;

  // TODO maybe enough do the next under (if (m_bCanceled)) only
  //
  // should be earlier than m_pGripManager->updateEntityGrips 
  // (recreate OdExGripData via OdExGripDataImpl::createObject)
  OdExGripDataPtrArray aActiveKeys;
  m_pGripManager->locateGripsByStatus(OdDbGripOperations::kDragImageGrip, aActiveKeys);
  iSize = aActiveKeys.size();
  ODA_ASSERT_ONCE(iSize);
  for (i = 0; i < iSize; i++)
    aActiveKeys[i]->setStatus(OdDbGripOperations::kWarmGrip);

  iSize = m_aDrags.size();
  if (m_bCanceled) // (!bOk)
  {
    for (i = 0; i < iSize; i++)
      m_aDrags[i]->notifyDragAborted();
  }
  else
  {
    for (i = 0; i < iSize; i++)
    {
      m_aDrags[i]->notifyDragEnded();
      m_pGripManager->updateEntityGrips(m_aDrags[i]->id());
    }
  }

  m_aDrags.clear();

  if (!m_bCanceled) // (bOk)
    m_pGripManager->updateInvisibleGrips();

  //OdDbDatabase* pDwgDb = OdDbDatabase::cast(m_pGripManager->m_pTabConsole->getRxDatabase()).get();
  //if (pDwgDb)
  //  pDwgDb->removeReactor(&m_cDbReactor);
}

bool OdqDragTracker::finishAt(const OdGePoint3d& ptFinal)
{
  ODA_ASSERT_ONCE(   m_bCanceled  // default
                  && m_ptLastPoint.distanceTo(ptFinal) < 1.0); // test
  OdUInt32 i, iSize = m_aDrags.size();
  ODA_ASSERT_ONCE(iSize);
  if (iSize)
    m_bCanceled = false;

  for (i = 0; i < iSize; i++)
    m_aDrags[i]->moveEntity(eyeToUcsPlane(ptFinal, // m_ptLastPoint
                                          m_ptBasePoint));
  return !m_bCanceled;
}

void OdqDragTracker::setValue(const OdGePoint3d& ptValue)
{
  OdUInt32 i, iSize = m_aDrags.size();
  OdGePoint3d newPoint = eyeToUcsPlane(ptValue, m_ptBasePoint);
  for (i = 0; i < iSize; i++)
    m_aDrags[i]->cloneEntity(newPoint);
  m_ptLastPoint = newPoint;
}

int OdqDragTracker::addDrawables(OdGsView* pView)
{
  //ODA_ASSERT(pView->device()==m_pDevice->underlyingDevice().get());

  OdUInt32 i, iSize = m_aDrags.size();
  if (!iSize)
    return 0;

  OdGsModelPtr pGsModel2d = getIViewSystem()->getView(m_pGripManager->m_pTabConsole->getRxDatabase())
                                            ->getGsModel(true); // GsModel2d
  for (i = 0; i < iSize; i++)
    pView->add(m_aDrags[i].get(), pGsModel2d);
  return iSize;
}

void OdqDragTracker::removeDrawables(OdGsView* pView)
{
  OdUInt32 i, iSize = m_aDrags.size();
  for (i = 0; i < iSize; i++)
    pView->erase(m_aDrags[i].get());
}

OdGePoint3d OdqDragTracker::eyeToUcsPlane(const OdGePoint3d& pt, 
                                          const OdGePoint3d& ptBase) const
{
  // #8043
  //OdDbObjectPtr pVpObj = m_pGripManager->activeVpId().safeOpenObject();
  //OdDbAbstractViewportDataPtr pAVD(pVpObj);
  //OdGePoint3d ucsOrigin;
  //OdGeVector3d ucsXAxis, ucsYAxis;
  //pAVD->getUcs(pVpObj, ucsOrigin, ucsXAxis, ucsYAxis);
  //OdGePlane plane(ptBase, // ucsOrigin
  //                ucsXAxis, ucsYAxis);
  IqView* iView = getIViewSystem()->getView(m_pGripManager->m_pTabConsole->getRxDatabase());
  ODA_ASSERT_ONCE(iView);
  OdGePlane plane;
  if (!iView->getUcsPlane(plane))
  {
    ODA_FAIL_ONCE(); 
  }

  OdGeLine3d line(pt, m_pGripManager->activeViewDirection());
  OdGePoint3d newPoint;
  if (!plane.intersectWith(line, newPoint))
    newPoint = ptBase;
  return newPoint;
}

// TODO
//
//OdExGripDbReactor::OdExGripDbReactor()
//  : m_pOwner(0)
//{
//}
//
//void OdExGripDbReactor::objectAppended(const OdDbDatabase* , const OdDbObject*)
//{
//  // New object.
//}
//
//void OdExGripDbReactor::objectModified(const OdDbDatabase*, const OdDbObject* pDbObj)
//{
//  m_pOwner->updateEntityGrips(pDbObj->objectId());
//  m_pOwner->updateInvisibleGrips();
//}
//
//void OdExGripDbReactor::objectErased(const OdDbDatabase*, const OdDbObject* pDbObj, bool pErased)
//{
//  if (pErased)
//  {
//    m_pOwner->removeEntityGrips(pDbObj->objectId(), true);
//    m_pOwner->updateInvisibleGrips();
//  }
//}
