/////////////////////////////////////////////////////////////////////////////// 
// Copyright (C) 2002-2015, Open Design Alliance (the "Alliance"). 
// All rights reserved. 
// 
// This software and its documentation and related materials are owned by 
// the Alliance. The software may only be incorporated into application 
// programs owned by members of the Alliance, subject to a signed 
// Membership Agreement and Supplemental Software License Agreement with the
// Alliance. The structure and organization of this software are the valuable  
// trade secrets of the Alliance and its suppliers. The software is also 
// protected by copyright law and international treaty provisions. Application  
// programs incorporating this software must include the following statement 
// with their copyright notices:
//   
//   This application incorporates Teigha(R) software pursuant to a license 
//   agreement with Open Design Alliance.
//   Teigha(R) Copyright (C) 2002-2015 by Open Design Alliance. 
//   All rights reserved.
//
// By use of this software, its documentation or related materials, you 
// acknowledge and accept the above terms.
///////////////////////////////////////////////////////////////////////////////
//
// OdqGripManager.cpp
//

#include "OdaCommon.h"

#define STL_USING_MAP
#define STL_USING_ALGORITHM
#include "OdaSTL.h"
#include "UInt32Array.h"
#include "Ge/GePoint3d.h"
#include "Gi/GiDrawableImpl.h"
#include "Gi/GiWorldDraw.h"
#include "Gi/GiViewportDraw.h"
#include "DbHostAppServices.h"
#include "DbCommandContext.h"
#include "DbEntity.h"
#include "DbAbstractViewportData.h"
#include "Gs/GsModel.h"

#include "OdqGripManager.h"
#include "OdqConsoleTab.h"
#include "ExtDbModule.h"

//////////////////////////////////////////////////////////////////////////

OdExGripDataPtr OdExGripDataImpl::createObject(OdDbStub* id, OdDbGripDataPtr pData, const OdGePoint3d& pt,  OdqGripManager* pOwner)
{ 
  OdExGripDataPtr pExGripData = RXIMPL_CONSTR(OdExGripDataImpl);
  OdExGripDataImpl* pImpl = reinterpret_cast<OdExGripDataImpl*>(pExGripData.get());
  pImpl->m_entPath = OdDbBaseFullSubentPath();
  pImpl->m_entPath.objectIds().append(id);
  pImpl->m_pData = pData;
  pImpl->m_point = pt;
  pImpl->m_pOwner = pOwner;
  return pExGripData;
}

OdExGripDataPtr OdExGripDataImpl::createObject(OdDbBaseFullSubentPath entPath, OdDbGripDataPtr pData, const OdGePoint3d& pt,  OdqGripManager* pOwner)
{ 
  OdExGripDataPtr pExGripData = RXIMPL_CONSTR(OdExGripDataImpl);
  OdExGripDataImpl* pImpl = reinterpret_cast<OdExGripDataImpl*>(pExGripData.get());
  pImpl->m_entPath = entPath;
  pImpl->m_pData = pData;
  pImpl->m_point = pt;
  pImpl->m_pOwner = pOwner;
  return pExGripData;
}

OdExGripDataImpl::OdExGripDataImpl()
  : m_pOwner(NULL)
//, m_status(OdDbGripOperations::kWarmGrip)
//, m_bInvisible(false)
//, m_bShared(false)
//, m_point(OdGePoint3d::kOrigin)
{
}

OdExGripDataImpl::~OdExGripDataImpl()
{
  if (m_pData.get() && m_pData->alternateBasePoint())
  {
    delete m_pData->alternateBasePoint();
    m_pData->setAlternateBasePoint(NULL);
  }
}

bool OdExGripDataImpl::computeDragPoint(OdGePoint3d& ptOverride) const
{
  OdGePoint3d ptBase = point();
  if (  !data().isNull() 
      && data()->alternateBasePoint() != NULL)
  {
    ptBase = *(data()->alternateBasePoint());
  }

  bool bOverride = false;
  ptOverride = ptBase;

  if (  status() == OdDbGripOperations::kDragImageGrip
      && !data().isNull()
      && data()->drawAtDragImageGripPoint())
  {
    ptOverride = ptBase + (m_pOwner->m_ptLastPoint - m_pOwner->m_ptBasePoint);
    bOverride = true;
  }

  return bOverride;
}

OdUInt32 OdExGripDataImpl::subSetAttributes(OdGiDrawableTraits* pTraits) const
{
  if (isInvisible())
    return kDrawableIsInvisible;

  OdGiSubEntityTraitsPtr pEntityTraits = OdGiSubEntityTraits::cast(pTraits);
  if (!pEntityTraits.get())
    return kDrawableNone;

  switch (status())
  {
  case OdDbGripOperations::kWarmGrip:
    pEntityTraits->setTrueColor(m_pOwner->m_GRIPCOLOR);
    break;
  case OdDbGripOperations::kHotGrip:
  case OdDbGripOperations::kDragImageGrip:
    pEntityTraits->setTrueColor(m_pOwner->m_GRIPHOT);
    break;
  case OdDbGripOperations::kHoverGrip:
    pEntityTraits->setTrueColor(m_pOwner->m_GRIPHOVER);
    break;
  }

  pEntityTraits->setMaterial(NULL);
  pEntityTraits->setLineWeight(OdDb::kLnWt000);
  return kDrawableRegenDraw;
}

bool OdExGripDataImpl::subWorldDraw(OdGiWorldDraw* pWorldDraw) const
{
  double dGripSize = m_pOwner->m_GRIPSIZE;
  if (!pWorldDraw->context() || !pWorldDraw->context()->database())
    dGripSize = m_pOwner->m_GRIPSIZE;
  //else
    // Here is the design flaw:
    // ARX help says that grip size passed in callback below should be
    // calculated individually for each viewport.

  if (!data().isNull() && data()->worldDraw())
  {
    OdGePoint3d ptComputed;
    OdGePoint3d* pDrawAtDrag = NULL;
    if (computeDragPoint(ptComputed))
      pDrawAtDrag = &ptComputed;

    return ((*data()->worldDraw())(
             (OdDbGripData*) data().get(), pWorldDraw, entityId(),  status(), pDrawAtDrag, dGripSize));
  }

  return false;
}

void OdExGripDataImpl::subViewportDraw(OdGiViewportDraw* pViewportDraw) const
{
  OdGePoint3d ptComputed;
  OdGePoint3d* pDrawAtDrag = 0;
  if (computeDragPoint(ptComputed))
    pDrawAtDrag = &ptComputed;

  bool bDefault = true;
  if (!data().isNull() && data()->viewportDraw() != NULL)
  {
    (*data()->viewportDraw())(
      (OdDbGripData*)data().get(), pViewportDraw, entityId(), status(), pDrawAtDrag, m_pOwner->m_GRIPSIZE);
    bDefault = false;
  }

  if (!bDefault)
    return;
  
  //if (!m_pOwner->m_pGsModel || m_pOwner->m_pGsModel->renderType() < OdGsModel::kDirect) 
  //{
  //  // move grip near to compensate z-buffer problem
  //  // Commented since renderTypes implemented, so no need to translate objects for kDirect renderType
  //  OdGeVector3d vpDirection(pViewportDraw->viewport().viewDir());
  //  OdGePoint3d vpOrigin(pViewportDraw->viewport().getCameraLocation());
  //  double ptLength = (ptComputed - vpOrigin).dotProduct(vpDirection);
  //  ptComputed -= vpDirection * ptLength;
  //}

  double dGripSize;
  {
    OdGePoint2d ptDim;
    pViewportDraw->viewport().getNumPixelsInUnitSquare(point(), ptDim);
    OdGeVector3d v(m_pOwner->m_GRIPSIZE / ptDim.x, 0.0, 0.0);
    v.transformBy(pViewportDraw->viewport().getWorldToEyeTransform());
    //if (pViewportDraw->viewport().isPerspective())
    //{
    //  OdGePoint3d perspFix(v.length(), 0.0, OdGePoint3d(ptComputed).transformBy(pViewportDraw->viewport().getWorldToEyeTransform()).z);
    //  pViewportDraw->viewport().doInversePerspective(perspFix);
    //  v.x = perspFix.x;
    //  v.y = v.z = 0.0;
    //}
    dGripSize = v.length();
  }

  OdGePoint3d ptOnScreen = ptComputed; //+ 1E10 * pViewportDraw->viewport().viewDir();
  ptOnScreen.transformBy(pViewportDraw->viewport().getWorldToEyeTransform());

  pViewportDraw->subEntityTraits().setFillType(kOdGiFillAlways);

  //ptOnScreen.z = 0.;

  OdGePoint3d aPoly[4];
  aPoly[0].set(ptOnScreen.x - dGripSize, ptOnScreen.y - dGripSize, ptOnScreen.z);
  aPoly[1].set(ptOnScreen.x + dGripSize, ptOnScreen.y - dGripSize, ptOnScreen.z);
  aPoly[2].set(ptOnScreen.x + dGripSize, ptOnScreen.y + dGripSize, ptOnScreen.z);
  aPoly[3].set(ptOnScreen.x - dGripSize, ptOnScreen.y + dGripSize, ptOnScreen.z);
  pViewportDraw->geometry().polygonEye(4, aPoly);
}

//////////////////////////////////////////////////////////////////////////

ODRX_NO_CONS_DEFINE_MEMBERS(OdqGripManager, OdEdPointTracker);

//static 
OdqGripManagerPtr OdqGripManager::createObject(OdqConsoleTab& tabConsole)
{
  //OdqGripManager* pObj = static_cast<OdqGripManager*>(new OdRxObjectImpl<OdqGripManager>);
  //OdqGripManagerPtr pGripManager = OdqGripManagerPtr(pGripManager, kOdRxObjAttach);
  OdqGripManagerPtr pGripManager = OdRxObjectImpl<OdqGripManager>::createObject();
  pGripManager->init(tabConsole);
  return pGripManager;
}

OdqGripManager::OdqGripManager()
  : m_pTabConsole(NULL)
  , m_GRIPSIZE(5)
  , m_GRIPOBJLIMIT(100)
  , m_bDisabled(true)
{
  m_GRIPCOLOR.setColorIndex(160);
  m_GRIPHOVER.setColorIndex(3);
  m_GRIPHOT.setColorIndex(1);

  //m_pDevice = 0;
  //m_pCmdCtx = 0;
  //m_aGripData.clear();

  //m_aHoverGrips.clear();

  //m_ptBasePoint = OdGePoint3d::kOrigin;
  //m_ptLastPoint = OdGePoint3d::kOrigin;
  //m_aDrags.clear();

  //m_cDbReactor.m_pOwner = this;
}

OdqGripManager::~OdqGripManager()
{
  endHover();
  uninit();
}

void OdqGripManager::init(OdqConsoleTab& tabConsole)
{
  m_pTabConsole = &tabConsole;
  
  OdDbHostAppServices* pAppSvcs = NULL;
  OdDbDatabase* pDwgDb = OdDbDatabase::cast(tabConsole.getRxDatabase()).get();
  if (pDwgDb)
    pAppSvcs = pDwgDb->appServices();
  if (!pAppSvcs)
  {
    // TODO (after the same variables will be added to DgRegVarDefs.h) :
    //
    // get GRIP constants via OdDgHostAppServices
    //                 or via valueToString of OdSysVarPE
    // OdSysVarPEPtr pSysVarPE = OdSysVarPE::cast(tabConsole.getRxDatabase());
    // ... = pSysVarPE->valueToString(...);
    //
    //pAppSvcs = OdDbHostAppServices::cast(getIApp()->getBaseHostAppServices()).get();
    // temporary harcode colors for DGN :
    m_GRIPCOLOR.setColorIndex(1);  // blue
    m_GRIPHOVER.setColorIndex(2); // green
    m_GRIPHOT.setColorIndex(3); // red

  }
  if (pAppSvcs)
  {
    m_GRIPSIZE = pAppSvcs->getGRIPSIZE();
    m_GRIPOBJLIMIT = pAppSvcs->getGRIPOBJLIMIT();
    m_GRIPCOLOR.setColorIndex(pAppSvcs->getGRIPCOLOR());
    m_GRIPHOVER.setColorIndex(pAppSvcs->getGRIPHOVER());
    m_GRIPHOT.setColorIndex(pAppSvcs->getGRIPHOT());
  }

  disable(false);
}

void OdqGripManager::uninit()
{
  disable(true);
  //m_pCmdCtx = 0;
  //m_pDevice = 0;
}

bool OdqGripManager::isDisabled() const
{
  return m_bDisabled;
}

void OdqGripManager::disable(bool bDisable)
{
  if (m_bDisabled == bDisable)
    return;

  m_bDisabled = bDisable;
  //if (!m_pCmdCtx)
  // return;
  //OdDbDatabase* pDwgDb = OdDbDatabase::cast(m_pOwner->m_pTabConsole->getRxDatabase()).get();
  //if (!pDwgDb)
  // return;
  //if (bDisable)
  //  pDwgDb->removeReactor(&m_cDbReactor);
  //else
  //  pDwgDb->addReactor(&m_cDbReactor);
}

bool OdqGripManager::checkGripSetAt(int x, int y, bool& bMultiplyMode)
{
  bMultiplyMode = false;

  endHover();
  OdExGripDataPtrArray aKeys;
  locateGripsAt(x, y, aKeys);

  if (aKeys.empty())
    return false;

  OdqConsoleTab::OdEdBaseIoStateKey keyState = m_pTabConsole->getKeyState();
  if (keyState & OdEdBaseIO::kShiftIsDown)
  {
    bMultiplyMode = true;

    // Modify Grip  status().
    OdDbGripOperations::DrawType eNewStatus = OdDbGripOperations::kHotGrip;
    OdUInt32 i, iSize = aKeys.size();
    for (i = 0; i < iSize; i++)
    {
      if (OdDbGripOperations::kHotGrip == aKeys[i]->status())
      {
        eNewStatus = OdDbGripOperations::kWarmGrip;
        break;
      }
    }

    for (i = 0; i < iSize; i++)
    {
      OdDbGripOperations::DrawType eCurStatus = eNewStatus;
      OdExGripDataPtr pGrip = aKeys[i];
      if (!pGrip->data().isNull())
      {
        if (pGrip->data()->triggerGrip())
          eCurStatus = OdDbGripOperations::kWarmGrip;
        else
        {
          if (pGrip->data()->hotGripFunc() != NULL)
          {
            int iFlags = OdDbGripOperations::kMultiHotGrip;
            if (pGrip->isShared())
              iFlags |= OdDbGripOperations::kSharedGrip;

            OdResult eRet = (*pGrip->data()->hotGripFunc())(pGrip->data(), pGrip->entityId(), iFlags);
            if (eRet == eGripOpGripHotToWarm)
              eCurStatus = OdDbGripOperations::kWarmGrip;
          }
        }
      }
      aKeys[i]-> setStatus(eCurStatus);
    }

    return true;
  }

  // Launch Grip Edit.
  bool bMakeHot = true;
  {
    for (GripDataMap::const_iterator it = m_aGripData.begin();
         it != m_aGripData.end() && bMakeHot; it++)
    {
      const OdExGripDataPtrArray& aData = it->second.m_pDataArray;

      OdUInt32 i, iSize = aData.size();
      for (i = 0; i < iSize; i++)
      {
        if (OdDbGripOperations::kHotGrip == aData[i]->status())
        {
          bMakeHot = false;
          break;
        }
      }
      for (i = 0; (i < it->second.m_pDataSub.size()) && bMakeHot; i++)
      {
        const OdExGripDataPtrArray& aData = it->second.m_pDataSub.at(i).m_pSubData;
        OdUInt32 j, iSize = aData.size();
        for (j = 0; j < iSize; j++)
        {
          if (OdDbGripOperations::kHotGrip == aData[j]->status())
          {
            bMakeHot = false;
            break;
          }
        }
      }
    }
  }

  bool bGetNew = false;
  OdDbObjectId idEntityToUpdate;
  if (bMakeHot)
  {
    OdUInt32 i, iSize = aKeys.size();
    for (i = 0; i < iSize; i++)
    {
      OdExGripDataPtr pGrip = aKeys[i];

      OdDbGripOperations::DrawType eNew = OdDbGripOperations::kHotGrip;

      if (!pGrip->data().isNull() &&
        0 != pGrip->data()->hotGripFunc())
      {
        int iFlags = 0;
        if (pGrip->isShared())
          iFlags |= OdDbGripOperations::kSharedGrip;

        if (pGrip->data()->triggerGrip())
        {
          if (false == pGrip->isShared())
          {
            OdResult eRet =
              (*pGrip->data()->hotGripFunc())(pGrip->data(), pGrip->entityId(), iFlags);
            switch (eRet)
            {
            case eOk :
            case eGripOpGripHotToWarm :
              {
                eNew = OdDbGripOperations::kWarmGrip;
                break;
              }
            case eGripOpGetNewGripPoints :
              {
                bGetNew = true;
                idEntityToUpdate = pGrip->entityId();
                break;
              }
            }
          }
        }
        else
        {
          OdResult eRet =
            (*pGrip->data()->hotGripFunc())(pGrip->data(), pGrip->entityId(), iFlags);
          if (false == pGrip->isShared())
          {
            switch (eRet)
            {
            case eGripOpGripHotToWarm :
              eNew = OdDbGripOperations::kWarmGrip;
              break;
            case eGripOpGetNewGripPoints :
              bGetNew = true;
              idEntityToUpdate = pGrip->entityId();
              break;
            }
          }
        }
      }

      pGrip->setStatus(eNew);
    }
  }

  if (bGetNew)
  {
    updateEntityGrips(idEntityToUpdate);
    return true;
  }

  return true;
}

// TODO
//bool OdqGripManager::checkMenu()
//{
//  OdExGripDataPtrArray aActiveKeys;
//  locateGripsByStatus(OdDbGripOperations::kHotGrip, aActiveKeys);
//  if (aActiveKeys.empty())
//  {
//    // Valid situation.
//    // If trigger grip performed entity modification and returned eGripHotToWarm
//    // then nothing is to be done cause entity modification will cause reactor to regen grips.
//    return false;
//  }
//
//  if (handleMappedRtClk(aActiveKeys, x, y))
//    return true;
//
//  return false;
//}

bool OdqGripManager::checkHoverAt(int x, int y)
{
  OdExGripDataPtrArray aKeys;
  endHover();
  locateGripsAt(x, y, aKeys);
  if (aKeys.empty())
    return false;

  m_aHoverGrips = aKeys;

  OdUInt32 i, iSize = m_aHoverGrips.size();
  for (i = 0; i < iSize; i++)
  {
    OdExGripDataPtr pGrip = m_aHoverGrips[i];
    if (pGrip->status() != OdDbGripOperations::kWarmGrip)
      continue;

    pGrip->setStatus(OdDbGripOperations::kHoverGrip);

    if (!pGrip->data().isNull())
    {
      if (0 != pGrip->data()->hoverFunc())
      {
        int iFlags = 0;
        if (pGrip->isShared())
          iFlags = OdDbGripOperations::kSharedGrip;
        //OdResult eRet =
        (*pGrip->data()->hoverFunc())(pGrip->data(), pGrip->entityId(), iFlags);
      }
    }

    //if (m_pGsModel)
    //  m_pGsModel->onModified(pGrip.get(), (OdGiDrawable*) NULL);
    //else
    //  m_pDevice->invalidate();
    IqViewSystem* iVS = getIViewSystem();
    if (iVS)
    {
      iVS->highlightGripPoint(false, pGrip);
      iVS->highlightGripPoint(true, pGrip);
    }
  }

  return true;
}

bool OdqGripManager::endHover()
{
  if (m_aHoverGrips.empty())
    return false;

  OdUInt32 i, iSize = m_aHoverGrips.size();
  for (i = 0; i < iSize; i++)
  {
    OdExGripDataPtr pGrip = m_aHoverGrips[i];
    if (pGrip->status() == OdDbGripOperations::kHoverGrip)
    {
      pGrip->setStatus(OdDbGripOperations::kWarmGrip);

      //if (m_pGsModel)
      //  m_pGsModel->onModified(pGrip.get(), (OdGiDrawable*)0);
      //else
      //  m_pDevice->invalidate();
      IqViewSystem* iVS = getIViewSystem();
      if (iVS)
      {
        iVS->highlightGripPoint(false, pGrip);
        iVS->highlightGripPoint(true, pGrip);
      }
    }
  }
  m_aHoverGrips.clear();
  return true;
}

static OdSelectionSetIteratorPtr searchObjectSSetIterator(OdSelectionSetPtr pSSet, OdDbStub* id)
{
  for (OdSelectionSetIteratorPtr pIter = pSSet->newIterator();
    !pIter->done(); pIter->next())
  {
    if (pIter->id() == id)
      return pIter;
  }
  return OdSelectionSetIteratorPtr();
}

void OdqGripManager::selectionSetChanged()
{
  OdSelectionSet* pSSet = m_pTabConsole->workingSelectionSet();
  ODA_ASSERT_ONCE(pSSet);

  bool bRestoreOld = false;
  if (pSSet->numEntities() > (unsigned) m_GRIPOBJLIMIT)
    disable(true);
  else
  {
    if (m_bDisabled)
      bRestoreOld = true;
    disable(false);
  }

  // Old Entities.
  {
    OdDbStubPtrArray aOld;
    GripDataMap::iterator it = m_aGripData.begin();
    while (it != m_aGripData.end())
    {
      if (m_bDisabled)
        aOld.push_back(it->first);
      else
      {
        if (!pSSet->isMember(it->first))
          aOld.push_back(it->first);
        else
        {
          // Remove if subentities changed
          bool bRemoved = false;
          OdUInt32 se;
          for (se = 0; se < it->second.m_pDataSub.size(); se++)
          {
            if (!pSSet->isMember(it->second.m_pDataSub[se].m_entPath))
            {
              aOld.push_back(it->first);
              bRemoved = true;
              break;
            }
          }
          // Remove if new paths added also (workaround. tehnically new pathes must be added on second step)
          if (!bRemoved)
          {
            OdSelectionSetIteratorPtr ssIt = searchObjectSSetIterator(pSSet, it->first);
            for (se = 0; se < ssIt->subentCount(); se++)
            {
              OdDbBaseFullSubentPath tmpPath;
              ssIt->getSubentity(se, tmpPath);
              OdUInt32 searchPath = 0;
              bool bFound = false;
              for (; searchPath < it->second.m_pDataSub.size(); searchPath++)
              {
                if (it->second.m_pDataSub.at(searchPath).m_entPath == tmpPath)
                {
                  bFound = true;
                  break;
                }
              }
              if (!bFound)
              {
                aOld.push_back(it->first);
                break;
              }
            }
          }
        }
      }
      it++;
    }

    OdUInt32 i, 
             iSize = aOld.size();
    for (i = 0; i < iSize; i++)
      removeEntityGrips(aOld[i], true);
  }

  // New Entities.
  {
    OdDbStubPtrArray aNew;
    for (OdSelectionSetIteratorPtr pIter = pSSet->newIterator();
         !pIter->done(); pIter->next())
    {
      if (!m_bDisabled && m_aGripData.end() == m_aGripData.find(pIter->id()))
          aNew.push_back(pIter->id());
    }
    OdUInt32 i, iSize = aNew.size();
    for (i = 0; i < iSize; i++)
      updateEntityGrips(aNew[i]);
  }

  updateInvisibleGrips();
}

void OdqGripManager::updateAllGrips()
{
  if (m_bDisabled)
    return;
  OdSelectionSet* pSSet = m_pTabConsole->workingSelectionSet();
  ODA_ASSERT_ONCE(pSSet);

  OdRxObject* pRxDatabase = m_pTabConsole->getRxDatabase().get();
  OdRxModule* pExtDb = getExtDbModule(pRxDatabase).get();

  OdDbStubPtrArray idsToRemove;
  for (OdSelectionSetIteratorPtr pIter = pSSet->newIterator();
       !pIter->done(); pIter->next())
  {
    OdDbStub* id = pIter->id();
    ODA_ASSERT_ONCE(id);
    if (!id)
      continue;

    bool bErased = true;
    if (!pExtDb)
      bErased = OdDbObjectId(id).isErased();
    else
      bErased = OdExtDbModule_cast(pExtDb)->isErased(id);

    if (bErased)
    {
      removeEntityGrips(id, true);
      idsToRemove.push_back(id);
      continue;
    }

    updateEntityGrips(id);
  }
  if (!idsToRemove.isEmpty())
  {
    // clear in SSet
    for (unsigned index = 0; index < idsToRemove.size(); index++)
      pSSet->remove(idsToRemove[index]);
  }

  updateInvisibleGrips();
}

void OdqGripManager::updateEntityGrips(OdDbStub* id)
{
  if (m_bDisabled)
    return;
  removeEntityGrips(id, false);

  OdSelectionSetPtr pSSet = workingSelectionSet();
  if (pSSet.isNull() || !pSSet->isMember(id))
    return;

  OdRxObject* pRxDatabase = m_pTabConsole->getRxDatabase().get();
  OdRxModule* pExtDb = getExtDbModule(pRxDatabase).get();
  OdDbEntityPtr pEntity;
  if (!pExtDb)
  {
    pEntity = OdDbEntity::cast(OdDbObjectId(id).openObject());
    ODA_ASSERT_ONCE(!pEntity.isNull());
    if (pEntity.isNull())
      return;
  }

  OdSelectionSetIteratorPtr pObjIt = searchObjectSSetIterator(pSSet, id);
  OdExGripDataPtrArray aExt;
  OdDbGripDataPtrArray aPts;

  if (pObjIt->subentCount() > 0)
  {
    for (OdUInt32 se = 0; se < pObjIt->subentCount(); se++)
    {
      OdDbFullSubentPath subEntPath;
      pObjIt->getSubentity(se, subEntPath);
      aPts.clear();
      if (   (   !pEntity.isNull() 
              && pEntity->getGripPointsAtSubentPath(subEntPath, 
                                                    aPts, 
                                                    activeViewUnitSize(), 
                                                    m_GRIPSIZE, 
                                                    activeViewDirection(),
                                                    0) == eOk)
          || (   pExtDb 
              && OdExtDbModule_cast(pExtDb)->getGripPointsAtSubentPath(subEntPath, 
                                                                       aPts, 
                                                                       activeViewUnitSize(), 
                                                                       m_GRIPSIZE, 
                                                                       activeViewDirection(),
                                                                       0)))
      {
        OdUInt32 prevSize = aExt.size();
        aExt.resize(prevSize + aPts.size());
        for (OdUInt32 i = 0; i < aPts.size(); i++)
        {
          aExt[i + prevSize] = OdExGripDataImpl::createObject(
            subEntPath, aPts[i], aPts[i]->gripPoint(), this);
        }
      }
    }
  }
  else
  {
    if (   (   !pEntity.isNull() 
            && pEntity->getGripPoints(aPts, 
                                      activeViewUnitSize(), 
                                      m_GRIPSIZE, 
                                      activeViewDirection(), 
                                      0) == eOk)
        || (   pExtDb 
            && OdExtDbModule_cast(pExtDb)->getGripPoints(id,
                                                         aPts, 
                                                         activeViewUnitSize(), 
                                                         m_GRIPSIZE, 
                                                         activeViewDirection())))
    {
      aExt.resize(aPts.size());
      OdUInt32 i, iSize = aExt.size();
      for (i = 0; i < iSize; i++)
      {
        aExt[i] = OdExGripDataImpl::createObject(id, 
                                                 aPts[i],
                                                 aPts[i]->gripPoint(),
                                                 this);
      }
    }
    else
    {
      OdGePoint3dArray aOldPts;
      bool bRes = (   (   !pEntity.isNull() 
                       && pEntity->getGripPoints(aOldPts) == eOk)
                   || (   pExtDb 
                       && OdExtDbModule_cast(pExtDb)->getGripPoints(id, aOldPts, 
                                                                    &m_pTabConsole->getCmdContext())));
      if (!bRes)
      {
        if (!pEntity.isNull())
        {
          ::odrxDynamicLinker()->loadModule(OdGripPointsModuleName);
          OdResult res = pEntity->getGripPoints(aOldPts);
          ODA_ASSERT_ONCE(res == eOk || res == eNotImplementedYet || res == eInvalidExtents);
          bRes = (res == eOk);
        }
        // TODO
        //else if (pExtDb)
        //{
        //  ::odrxDynamicLinker()->loadModule(OD_T("TG_GripPoints"));
        //  bRes = OdExtDbModule_cast(pExtDb)->getGripPoints(id, aOldPts);
        //}
      }
      if (bRes)
      {
        aExt.resize(aOldPts.size());
        OdUInt32 i, iSize = aExt.size();
        for (i = 0; i < iSize; i++)
        {
          aExt[i] = OdExGripDataImpl::createObject(id, 
                                                   0, 
                                                   aOldPts[i], 
                                                   this);
        }
      }
    }
  }

  bool bModel = true;
  OdDbDatabase* pDwgDb = OdDbDatabase::cast(pRxDatabase).get();
  if (pDwgDb)
    bModel = pDwgDb->getTILEMODE();
  if (!aExt.empty())
  {
    OdUInt32 i, iSize = aExt.size();
    OdExGripDataExt dExt;
    for (i = 0; i < iSize; i++)
    {
      OdDbBaseFullSubentPath entPath;
      if (aExt[i]->entPath(&entPath))
      {
        bool bFound = false;
        for (OdUInt32 j = 0; j < dExt.m_pDataSub.size(); j++)
        {
          if (dExt.m_pDataSub[j].m_entPath == entPath)
          {
            bFound = true;
            dExt.m_pDataSub[j].m_pSubData.append(aExt[i]);
            break;
          }
        }
        if (!bFound)
        {
          OdExGripDataSubent se;
          se.m_entPath = entPath;
          se.m_pSubData.append(aExt[i]);
          dExt.m_pDataSub.append(se);
        }
      }
      else
        dExt.m_pDataArray.append(aExt[i]);
    }

    //dExt.m_pDataArray = aExt;
    m_aGripData.insert(std::make_pair(id, dExt));

    for (i = 0; i < iSize; i++)
      showGrip(aExt[i], bModel);
  }
}

OdUInt32 OdqGripManager::numGripPoints()
{
  return m_aGripData.size();
}

OdUInt32 OdqGripManager::numGripPoints(enum OdDbGripOperations::DrawType eStatus)
{
  if (!m_aGripData.size())
    return 0;
  OdExGripDataPtrArray aResult;
  locateGripsByStatus(eStatus, aResult);
  return aResult.size();
}

void OdqGripManager::removeEntityGrips(OdDbStub* id, bool bFireDone)
{
  GripDataMap::iterator it = m_aGripData.find(id);
  if (it != m_aGripData.end())
  {
    bool bModel = true; // default for DGN
    OdDbEntityPtr pEntity;
    OdDbDatabase* pDwgDb = OdDbDatabase::cast(m_pTabConsole->getRxDatabase()).get();
    if (pDwgDb)
    {
      bModel = pDwgDb->getTILEMODE();
      pEntity = OdDbEntity::cast(OdDbObjectId(id).openObject());
    }

    if (pEntity.get())
      pEntity->gripStatus(OdDb::kGripsToBeDeleted);
    //else // TODO

    OdUInt32 i, iSize = it->second.m_pDataArray.size();
    for (i = 0; i < iSize; i++)
    {
      OdExGripDataPtr pData = it->second.m_pDataArray[i];
      hideGrip(pData, bModel);
      if (!it->second.m_pDataArray[i]->data().isNull() && it->second.m_pDataArray[i]->data()->gripOpStatFunc())
        (*it->second.m_pDataArray[i]->data()->gripOpStatFunc())(it->second.m_pDataArray[i]->data(), id, OdDbGripOperations::kGripEnd);
      it->second.m_pDataArray[i] = 0;
    }
    for (i = 0; i < it->second.m_pDataSub.size(); i++)
    {
      for (OdUInt32 j = 0; j < it->second.m_pDataSub.at(i).m_pSubData.size(); j++)
      {
        OdExGripDataPtr pData = it->second.m_pDataSub.at(i).m_pSubData[j];
        hideGrip(pData, bModel);
        it->second.m_pDataSub.at(i).m_pSubData[j] = 0;
      }
    }

    if (bFireDone)
    {
      if (pEntity.get())
        pEntity->gripStatus(OdDb::kGripsDone);
      //else // TODO
    }

    m_aGripData.erase(it);
  }
}

void OdqGripManager::locateGripsAt(int x, int y, OdExGripDataPtrArray& aResult)
{
  aResult.clear();

  double dX = x;
  double dY = y;

  OdGePoint3d ptFirst;
  for (GripDataMap::const_iterator it = m_aGripData.begin();
       it != m_aGripData.end(); it++)
  {
    for (OdUInt32 se = 0; se < it->second.m_pDataSub.size() + 1; se++)
    {
      const OdExGripDataPtrArray& aData = (se == 0) ? it->second.m_pDataArray 
                                                    : it->second.m_pDataSub[se - 1].m_pSubData;
      OdUInt32 i, iSize = aData.size();
      for (i = 0; i < iSize; i++)
      {
        const OdGePoint3d& ptCurrent = aData[i]->point();

        if (aResult.empty())
        {
          // First grip is obtained by comparing
          // grip point device position with cursor position.
          OdGePoint3d ptDC = ptCurrent;
          ptDC.transformBy(activeGsView()->worldToDeviceMatrix());

          double dDeltaX = ::fabs(dX - ptDC.x);
          double dDeltaY = ::fabs(dY - ptDC.y);
          bool bOk = (dDeltaX <= m_GRIPSIZE) && (dDeltaY <= m_GRIPSIZE);
          if (bOk)
          {
            ptFirst = ptCurrent;
            aResult.push_back(aData[i]);
          }
        }
        else
        {
          // Other grips are obtained by comparing world coordinates.
          // The approach here is quite raw.
          if (ptCurrent.isEqualTo(ptFirst, 1E-4))
          {
            aResult.push_back(aData[i]);
          }
        }
      } // end for
    } // end for
  } // end for
}

void OdqGripManager::locateGripsByStatus(OdDbGripOperations::DrawType eStatus, OdExGripDataPtrArray& aResult)
{
  aResult.clear();

  for (GripDataMap::const_iterator it = m_aGripData.begin();
       it != m_aGripData.end(); it++)
  {
    for (OdUInt32 se = 0; se < it->second.m_pDataSub.size() + 1; se++)
    {
      const OdExGripDataPtrArray& aData = (se == 0) ? it->second.m_pDataArray : it->second.m_pDataSub[se - 1].m_pSubData;
      OdUInt32 i, iSize = aData.size();
      for (i = 0; i < iSize; i++)
      {
        if (eStatus == aData[i]->status())
          aResult.push_back(aData[i]);
      }
    }
  }
}

struct SortGripsAlongXAxis
{
  bool operator()(const OdExGripDataPtr& grA, const OdExGripDataPtr& grB)
  {
    return OdPositive(grA->point().x, grB->point().x);
  }
};

void OdqGripManager::updateInvisibleGrips()
{
  OdExGripDataPtrArray aOverall;
  for (GripDataMap::const_iterator it = m_aGripData.begin();
       it != m_aGripData.end(); it++)
  {
    aOverall.insert(aOverall.end(), it->second.m_pDataArray.begin(), it->second.m_pDataArray.end());
    for (OdUInt32 i = 0; i < it->second.m_pDataSub.size(); i++)
      aOverall.insert(aOverall.end(), it->second.m_pDataSub[i].m_pSubData.begin(), it->second.m_pDataSub[i].m_pSubData.end());
  }

  OdUInt32 i, iSize = aOverall.size();
  for (i = 0; i < iSize; i++)
  {
    aOverall[i]->setInvisible(false);
    aOverall[i]->setShared(false);
  }

  // Not the best approach for sorting.
  // Just for demonstration.
  std::sort(aOverall.begin(), aOverall.end(), SortGripsAlongXAxis());

  iSize = aOverall.size();
  for (i = 0; i < iSize; i++)
  {
    if (aOverall[i]->isShared())
      continue;

    OdUInt32Array aEq;
    aEq.push_back(i);

    OdGePoint3d ptIni = aOverall[i]->point();

    OdUInt32 iNext = i + 1;
    while (iNext < iSize)
    {
      OdGePoint3d ptCur = aOverall[iNext]->point();

      if (OdEqual(ptIni.x, ptCur.x, 1E-6))
      {
        if (ptIni.isEqualTo(ptCur, 1E-6))
          aEq.push_back(iNext);
        iNext++;
      }
      else
        break;
    }

    if (aEq.size() >= 2)
    {
      OdUInt32 iVisible = 0;
      OdUInt32 j, jSize = aEq.size();
      for (j = 0; j < jSize; j++)
      {
        OdExGripDataPtr pGrip = aOverall[aEq[j]];

        bool bOk = true;
        if (!pGrip->data().isNull())
        {
          if (pGrip->data()->skipWhenShared())
            bOk = false;
        }
        else
        {
          bOk = false;
        }

        if (bOk)
        {
          iVisible = j;
          break;
        }
      }

      for (j = 0; j < jSize; j++)
      {
        OdExGripDataPtr pGrip = aOverall[aEq[j]];

        pGrip->setShared(true);
        pGrip->setInvisible(j != iVisible);
      }
    }
  }
}

void OdqGripManager::showGrip(OdExGripDataPtr pGrip, 
                              bool) // bModel
{
  IqViewSystem* iVS = getIViewSystem();
  if (iVS)
    iVS->highlightGripPoint(true, pGrip);
}

void OdqGripManager::hideGrip(OdExGripDataPtr pGrip, 
                              bool) // bModel
{
  IqViewSystem* iVS = getIViewSystem();
  if (iVS)
    iVS->highlightGripPoint(false, pGrip);
}

void OdqGripManager::setValue(const OdGePoint3d& ptValue)
{
  //m_ptLastPoint = ptValue;
}

int OdqGripManager::addDrawables(OdGsView* pView)
{
  return 0;
}

void OdqGripManager::removeDrawables(OdGsView* pView)
{
}

OdSelectionSetPtr OdqGripManager::workingSelectionSet()
{
  if (!m_pTabConsole)
  {
    ODA_FAIL_ONCE();
    return OdSelectionSetPtr();
  }

  return m_pTabConsole->workingSelectionSet();
}

OdGsView* OdqGripManager::activeGsView() const
{
  //OdGsView* pView = m_pDevice->activeView();
  OdGsView* pView = getIViewSystem()->getView(m_pTabConsole->getRxDatabase())->getActiveGsView();
  ODA_ASSERT_ONCE(pView);
  return pView;
}

double OdqGripManager::activeViewUnitSize() const
{
  OdGsView* pView = activeGsView();

  // Do not have access to getNumPixelsInUnitSquare here.
  double dRes = 1.0;
  if (pView)  
  {
    OdGePoint2d ptDim; // getNumPixelsInUnitSquare
    OdGePoint2d ll, ur;
    pView->getViewport(ll, ur);
    OdGsDCRect scrRect;
    pView->getViewport(scrRect);
    ptDim.x = fabs(double(scrRect.m_max.x - scrRect.m_min.x) / pView->fieldWidth()  * (ur.x-ll.x));
    ptDim.y = fabs(double(scrRect.m_max.y - scrRect.m_min.y) / pView->fieldHeight() * (ur.y-ll.y));

    OdGeVector3d v(m_GRIPSIZE / ptDim.x, 0, 0);
    v.transformBy(pView->viewingMatrix());
    dRes = v.length() / m_GRIPSIZE;
  }
  return dRes;
}

OdGeVector3d OdqGripManager::activeViewDirection() const
{
  OdGsView* pView = activeGsView();
  return (pView->position() - pView->target()).normal();
}

// Menu animation flags
//#ifndef TPM_VERPOSANIMATION
//static const UINT TPM_VERPOSANIMATION = 0x1000L;
//#endif
//#ifndef TPM_NOANIMATION
//static const UINT TPM_NOANIMATION = 0x4000L;
//#endif
//
//
//bool OdqGripManager::handleMappedRtClk(OdExGripDataPtrArray &aActiveKeys, int x, int y)
//{
//  OdUInt32 iSize = aActiveKeys.size();
//  int rtClkIndex = -1;
//  for (OdUInt32 i = 0; i < iSize; i++)
//  {
//    if (!aActiveKeys[i]->data().isNull() && 0 != aActiveKeys[i]->data()->rtClk()
//      && aActiveKeys[i]->data()->mapGripHotToRtClk() && !aActiveKeys[i]->isShared())
//    {
//      rtClkIndex = i;
//      break;
//    }
//  }
//  if (rtClkIndex != -1)
//  {
//    OdDbStubPtrArray ents;
//    OdDbGripDataArray hotGrips;
//    for (OdUInt32 i = 0; i < iSize; i++)
//    {
//      hotGrips.append(*aActiveKeys[i]->data());
//      if (!ents.contains(aActiveKeys[i]->id()))
//        ents.append(aActiveKeys[i]->id());
//    }
//    OdString menuName;
//    ODHMENU menu = 0;
//    ContextMenuItemIndexPtr cb = 0;
//    OdResult eRet = (*aActiveKeys[rtClkIndex]->data()->rtClk())(hotGrips, ents, menuName, menu, cb);
//    if (eRet == eOk && menu != 0 && cb != 0)
//    {
//      HWND wnd = ::GetActiveWindow();
//      POINT pt = {x, y};
//      ::ClientToScreen(wnd, &pt);
//      (*cb)(::TrackPopupMenu((HMENU)menu, 
//        TPM_LEFTALIGN|TPM_TOPALIGN|TPM_NONOTIFY|TPM_RETURNCMD|TPM_LEFTBUTTON|TPM_NOANIMATION, pt.x, pt.y, 0, wnd, 0));
//      ::DestroyMenu((HMENU)menu);
//      for (OdUInt32 i = 0; i < iSize; i++)
//        aActiveKeys[i]->setStatus(OdDbGripOperations::kWarmGrip);
//      updateEntityGrips(aActiveKeys[rtClkIndex]->id());
//      return true;
//    }
//  }
//  return false;
//}
//
