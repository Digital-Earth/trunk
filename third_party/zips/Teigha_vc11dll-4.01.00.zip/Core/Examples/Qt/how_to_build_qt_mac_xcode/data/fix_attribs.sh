#! /bin/bash
ScriptDir="${0%/*}"
sudo -S chmod -R a+rwx $ScriptDir/TeighaFileConverter.app
#sudo -S chmod -R a+rwx $ScriptDir/OdaQtApp.app
sudo -S chmod -R a+rwx $ScriptDir/TeighaViewer.app
