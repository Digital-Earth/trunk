//
//      FILE:   NamespaceDoc.cs.
//
//    AUTHOR:   Grant Frisken
//
// COPYRIGHT:   Copyright 2004 
//              Infralution
//              6 Bruce St 
//              Mitcham Australia
//
using System;
namespace Infralution.Controls.VirtualTree
{

#if DEBUG

	/// <summary>
	/// Defines the classes that implement the Infralution Virtual Tree control.
	/// </summary>
	public sealed class NamespaceDoc
	{
	}

#endif

}
