//
//      FILE:   NamespaceDoc.cs.
//
//    AUTHOR:   Grant Frisken
//
// COPYRIGHT:   Copyright 2004 
//              Infralution
//              6 Bruce St 
//              Mitcham Australia
//
using System;
namespace Infralution.Controls
{

#if DEBUG

	/// <summary>
	/// Defines the base control classes and associated utilities used by Infralution Software.
	/// </summary>
	public sealed class NamespaceDoc
	{
	}

#endif

}
