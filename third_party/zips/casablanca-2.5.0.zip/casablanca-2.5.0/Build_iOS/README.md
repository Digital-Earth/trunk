Please consult the codeplex documentation for iOS compilation:

[](https://casablanca.codeplex.com/wikipage?title=Setup%20and%20Build%20on%20IOS)
