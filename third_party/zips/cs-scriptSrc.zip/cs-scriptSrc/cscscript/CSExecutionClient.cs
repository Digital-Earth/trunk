#region Licence...
//-----------------------------------------------------------------------------
// Date:	17/10/04	Time: 2:33p 
// Module:	CSExecutionClient.cs
// Classes:	CSExecutionClient
//			AppInfo
//
// This module contains the definition of the CSExecutionClient class. Which implements 
// compiling C# code and executing 'Main' method of compiled assembly
//
// Written by Oleg Shilo (oshilo@gmail.com)
// Copyright (c) 2004-2008. All rights reserved.
//
// Redistribution and use of this code in source and binary forms, without 
// modification, are permitted provided that the following conditions are met:
// 1. Redistributions of source code must retain the above copyright notice, 
//	this list of conditions and the following disclaimer. 
// 2. Neither the name of an author nor the names of the contributors may be used 
//	to endorse or promote products derived from this software without specific 
//	prior written permission.
// 3. This code may be used in compiled form in any way you desire. This
//	  file may be redistributed unmodified by any means PROVIDING it is 
//	not sold for profit without the authors written consent, and 
//	providing that this notice and the authors name is included. 
//
// Redistribution and use of this code in source and binary forms, with modification, 
// are permitted provided that all above conditions are met and software is used 
// or sold for profit.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//	Caution: Bugs are expected!
//----------------------------------------------
#endregion

using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Reflection;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;
using System.Collections;

namespace csscript
{
	delegate void PrintDelegate(string msg);

	/// <summary>
	/// Wrapper class that runs CSExecutor within console application context.
	/// </summary>
	class CSExecutionClient
	{
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		internal static extern bool SetEnvironmentVariable(string lpName, string lpValue);

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		static void Main(string[] args)
		{
			//System.Diagnostics.Debug.Assert(false);
			try
			{
				SetEnvironmentVariable("CSScriptRuntime", System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString());
			}
			catch { } //SetEnvironmentVariable will always throw an exception on Mono

			CSExecutor exec = new CSExecutor();

			if (AppDomain.CurrentDomain.FriendlyName != "ExecutionDomain") // AppDomain.IsDefaultAppDomain is more appropriate but it is not available in .NET 1.1
			{
				string configFile = exec.GetCustomAppConfig(args);
				if (configFile != "")
				{
					AppDomainSetup setup = AppDomain.CurrentDomain.SetupInformation;
					setup.ConfigurationFile = configFile;

					AppDomain appDomain = AppDomain.CreateDomain("ExecutionDomain", null, setup);
					appDomain.ExecuteAssembly(Assembly.GetExecutingAssembly().Location, null, args);
					return;
				}
			}
			AppInfo.appName = new FileInfo(Application.ExecutablePath).Name;
			exec.Execute(args, new PrintDelegate(Print), null);
		}
		/// <summary>
		/// Implementation of displaying application messages.
		/// </summary>
		static void Print(string msg)
		{
			Console.WriteLine(msg);
		}
	}
	/// <summary>
	/// Repository for application specific data
	/// </summary>
	class AppInfo
	{
		public static string appName = "cscscript";
		public static bool appConsole = true;
		public static string appLogo
		{
			get { return "C# Script execution engine. Version " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString() + ".\nCopyright (C) 2004-2008 Oleg Shilo.\n"; }
		}
		public static string appLogoShort
		{
			get { return "C# Script execution engine. Version " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString() + ".\n"; }
		}
		//#pragma warning disable 414
		public static string appParams = "[/nl]:";
		//#pragma warning restore 414
		public static string appParamsHelp = "nl   - No logo mode: No banner will be shown at execution time.\n";
	}
}
