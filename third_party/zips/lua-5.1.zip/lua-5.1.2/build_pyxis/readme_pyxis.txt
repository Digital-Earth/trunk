
Lua 5.1.2

Built by Marc Lepage on 2007-07-05

By running etc/luavs.bat and copying the built files into dir build_pyxis.

However, the luavs.bat from this dir (copied from 5.1.1) was used as the
5.1.2 version links the exe to MSVCR80.DLL which seems an undesirable
dependency.
