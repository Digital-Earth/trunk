#!/bin/sh
exec mono ./CgExamples.exe "$@"
