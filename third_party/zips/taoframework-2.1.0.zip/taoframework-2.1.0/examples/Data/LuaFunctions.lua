io.write("Running ", _VERSION, "\n")
a = my_function(1, 2, 3, "abc", "def")
io.write("my_function() returned ", a, "\n")