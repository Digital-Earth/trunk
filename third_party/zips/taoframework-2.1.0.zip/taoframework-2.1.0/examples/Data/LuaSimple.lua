-- Simple example to test Lua

print "Hello, World!"