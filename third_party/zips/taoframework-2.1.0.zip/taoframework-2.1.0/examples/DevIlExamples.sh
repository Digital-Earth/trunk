#!/bin/sh
exec mono ./DevIlExamples.exe "$@"
