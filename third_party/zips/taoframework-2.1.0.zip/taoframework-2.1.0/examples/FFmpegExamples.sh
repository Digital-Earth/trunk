#!/bin/sh
exec mono ./FFmpegExamples.exe "$@"
