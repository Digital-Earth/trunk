#!/bin/sh
exec mono ./FreeGlutExamples.exe "$@"
