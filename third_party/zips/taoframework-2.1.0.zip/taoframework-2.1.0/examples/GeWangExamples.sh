#!/bin/sh
exec mono ./GeWangExamples.exe "$@"
