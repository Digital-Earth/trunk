#!/bin/sh
exec mono ./GlfwExamples.exe "$@"
