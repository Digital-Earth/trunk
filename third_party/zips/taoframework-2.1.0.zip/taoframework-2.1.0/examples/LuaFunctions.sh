#!/bin/sh
exec mono ./LuaFunctions.exe "$@"
