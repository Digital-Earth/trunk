#!/bin/sh
exec mono ./LuaSimple.exe "$@"
