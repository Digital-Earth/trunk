#!/bin/sh
exec mono ./NateRobins.exe "$@"
