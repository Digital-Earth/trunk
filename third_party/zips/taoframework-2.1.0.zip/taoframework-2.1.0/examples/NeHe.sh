#!/bin/sh
exec mono ./NeHe.exe "$@"
