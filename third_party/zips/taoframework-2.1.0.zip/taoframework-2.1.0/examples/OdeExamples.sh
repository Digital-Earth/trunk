#!/bin/sh
exec mono ./OdeExamples.exe "$@"
