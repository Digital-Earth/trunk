#!/bin/sh
exec mono ./OpenAlExamples.exe "$@"
