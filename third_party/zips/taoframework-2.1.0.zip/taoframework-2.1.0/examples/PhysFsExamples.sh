#!/bin/sh
exec mono ./PhysFsExamples.exe "$@"
