#!/bin/sh
exec mono ./Redbook.exe "$@"
