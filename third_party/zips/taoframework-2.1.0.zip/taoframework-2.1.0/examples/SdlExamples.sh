#!/bin/sh
exec mono ./SdlExamples.exe "$@"
