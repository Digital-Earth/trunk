#!/bin/sh
nant mono-2.0 package-debug
